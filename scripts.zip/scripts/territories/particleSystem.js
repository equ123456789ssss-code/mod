import { world } from "@minecraft/server";
import { TerritoryManager } from "./territoryManager.js";
import { Database } from "../core/database.js";

const PARTICLES = {
    friendly: "minecraft:happy_villager",
    hostile: "minecraft:angry_villager",
    neutral: "minecraft:end_rod",
    corner: "minecraft:end_rod"
};

function spawnParticleSafe(dimension, particle, position, count = 1) {
    if (!dimension || !particle || !position) return;
    try {
        dimension.spawnParticle(particle, { x: position.x, y: position.y, z: position.z, count });
    } catch (e) {
        // Silenciar: plataforma puede no soportar todas las partículas
    }
}

function getPlayerClanTag(player) {
    if (!player) return null;
    const tag = player.getTags().find(t => t && t.startsWith("clan:"));
    return tag ? tag.split(":")[1] : null;
}

function areClansAllied(clanA, clanB) {
    if (!clanA || !clanB) return false;
    try {
        const a = Database.getClanData(clanA);
        const b = Database.getClanData(clanB);
        if (a && Array.isArray(a.allies) && a.allies.includes(clanB)) return true;
        if (b && Array.isArray(b.allies) && b.allies.includes(clanA)) return true;
    } catch (e) {
        // ignore
    }
    return false;
}

function pickParticleForRelation(player, ownerClanTag) {
    const viewerClan = getPlayerClanTag(player);
    // Jugador sin clan -> ver rojo (hostil)
    if (!viewerClan) return { particle: PARTICLES.hostile, corner: PARTICLES.corner };

    // Si es su propio clan
    if (ownerClanTag && viewerClan === ownerClanTag) return { particle: PARTICLES.friendly, corner: PARTICLES.corner };

    // Si hay alianza (campo `allies` en datos de clan)
    if (ownerClanTag && areClansAllied(ownerClanTag, viewerClan)) return { particle: PARTICLES.friendly, corner: PARTICLES.corner };

    // Por defecto: hostil/externo
    return { particle: PARTICLES.hostile, corner: PARTICLES.corner };
}

function chunkCenterFromParsed(parsed) {
    return { x: parsed.x * 16 + 8, z: parsed.z * 16 + 8, dimensionId: parsed.dimensionId };
}

export function spawnChunkOutlineForPlayer(player, chunkId, opts = {}) {
    if (!player || !chunkId) return;
    const parsed = TerritoryManager.parseChunkId(chunkId);
    if (!parsed) return;
    if (player.dimension.id !== parsed.dimensionId) return;

    const center = chunkCenterFromParsed(parsed);
    const dx = player.location.x - center.x;
    const dz = player.location.z - center.z;
    const maxDist = opts.maxDistance || 128;
    if ((dx * dx + dz * dz) > (maxDist * maxDist)) return;

    const ownerClanTag = opts.clanTag || TerritoryManager.getChunkOwner(chunkId) || null;
    const picked = pickParticleForRelation(player, ownerClanTag);
    const particle = (picked && picked.particle) ? picked.particle : PARTICLES.neutral;
    // Usar el mismo tipo de partícula para esquinas para mantener color consistente
    const cornerParticle = particle;

    const height = (opts.heightOffset || 1.4) + player.location.y;

    // Chunk boundaries (assume 16x16)
    const left = parsed.x * 16;
    const right = left + 15;
    const top = parsed.z * 16;
    const bottom = top + 15;

    const pointsPerEdge = Math.max(6, Math.floor((opts.detail || 12) / 2));

    // Top edge
    for (let i = 0; i <= pointsPerEdge; i++) {
        const t = i / pointsPerEdge;
        const x = left + t * (right - left);
        const z = top;
        spawnParticleSafe(player.dimension, particle, { x, y: height, z }, 1);
        spawnParticleSafe(player.dimension, particle, { x, y: height + 0.6, z }, 1);
    }
    // Right edge
    for (let i = 0; i <= pointsPerEdge; i++) {
        const t = i / pointsPerEdge;
        const x = right;
        const z = top + t * (bottom - top);
        spawnParticleSafe(player.dimension, particle, { x, y: height, z }, 1);
        spawnParticleSafe(player.dimension, particle, { x, y: height + 0.6, z }, 1);
    }
    // Bottom edge
    for (let i = 0; i <= pointsPerEdge; i++) {
        const t = i / pointsPerEdge;
        const x = right - t * (right - left);
        const z = bottom;
        spawnParticleSafe(player.dimension, particle, { x, y: height, z }, 1);
        spawnParticleSafe(player.dimension, particle, { x, y: height + 0.6, z }, 1);
    }
    // Left edge
    for (let i = 0; i <= pointsPerEdge; i++) {
        const t = i / pointsPerEdge;
        const x = left;
        const z = bottom - t * (bottom - top);
        spawnParticleSafe(player.dimension, particle, { x, y: height, z }, 1);
        spawnParticleSafe(player.dimension, particle, { x, y: height + 0.6, z }, 1);
    }

    // Corners (más densas)
    const corners = [
        { x: left, z: top },
        { x: right, z: top },
        { x: right, z: bottom },
        { x: left, z: bottom }
    ];
    for (const c of corners) {
        spawnParticleSafe(player.dimension, cornerParticle, { x: c.x + 0.5, y: height + 0.4, z: c.z + 0.5 }, 4);
    }
}

export function spawnClanClaimsAroundPlayer(player, clanTag, opts = {}) {
    if (!player || !clanTag) return;
    const claims = TerritoryManager.getClanClaims(clanTag) || [];
    if (claims.length === 0) return;
    const maxToShow = opts.maxToShow || 12;
    let shown = 0;
    for (const chunkId of claims) {
        if (shown >= maxToShow) break;
        const parsed = TerritoryManager.parseChunkId(chunkId);
        if (!parsed) continue;
        if (player.dimension.id !== parsed.dimensionId) continue;
        spawnChunkOutlineForPlayer(player, chunkId, { clanTag, maxDistance: opts.maxDistance || 96, detail: opts.detail || 12 });
        shown++;
    }
}

export function spawnNearbyClaimsForPlayer(player, radiusChunks = 3, opts = {}) {
    if (!player) return 0;
    const dimensionId = player.dimension.id;
    const playerChunkX = Math.floor(player.location.x / 16);
    const playerChunkZ = Math.floor(player.location.z / 16);
    const maxToShow = opts.maxToShow || 12;
    let shown = 0;
    const seen = new Set();

    outer: for (let dx = -radiusChunks; dx <= radiusChunks; dx++) {
        for (let dz = -radiusChunks; dz <= radiusChunks; dz++) {
            if (shown >= maxToShow) break outer;
            const nx = playerChunkX + dx;
            const nz = playerChunkZ + dz;
            const chunkId = `${dimensionId}_${nx}_${nz}`;
            if (seen.has(chunkId)) continue;
            const owner = TerritoryManager.getChunkOwner(chunkId);
            if (!owner) continue;
            seen.add(chunkId);
            spawnChunkOutlineForPlayer(player, chunkId, { clanTag: owner, maxDistance: opts.maxDistance || 96, detail: opts.detail || 12 });
            shown++;
        }
    }

    return shown;
}

export default { spawnChunkOutlineForPlayer, spawnClanClaimsAroundPlayer, spawnNearbyClaimsForPlayer };
