import { world, system } from "@minecraft/server";
import { TerritoryManager } from "./territoryManager.js";
import { spawnClanClaimsAroundPlayer, spawnNearbyClaimsForPlayer } from "./particleSystem.js";
import { Database } from "../core/database.js";
import { ClanManager } from "../clans/clanManager.js";

const claimMarkerEnabled = new Set();
const MARKER_INTERVAL_TICKS = 60;
const proximityCache = new Map();
const PROXIMITY_RADIUS_CHUNKS = 3;
const PROXIMITY_COOLDOWN_MS = 10000; // ms

function chunkIdToCenter(chunkId) {
    const parts = String(chunkId).split("_");
    if (parts.length < 3) return null;
    const dim = parts[0];
    const x = parseInt(parts[1], 10);
    const z = parseInt(parts[2], 10);
    return { dimensionId: dim, x: x * 16 + 8, z: z * 16 + 8 };
}

function spawnParticleSafe(dimension, particle, position, count = 12) {
    if (!dimension || !particle || !position) return;
    try {
        dimension.spawnParticle(particle, { x: position.x, y: position.y, z: position.z, count });
    } catch (e) {
        // Ignorar si la partícula no se puede mostrar en esta plataforma.
    }
}

export function spawnClaimEffect(player, chunkId) {
    const center = chunkIdToCenter(chunkId);
    if (!player || !center || player.dimension.id !== center.dimensionId) return;
    const position = { x: center.x, y: player.location.y + 1.2, z: center.z };
    spawnParticleSafe(player.dimension, "minecraft:happy_villager", position, 18);
    spawnParticleSafe(player.dimension, "minecraft:end_rod", { x: position.x, y: position.y + 0.5, z: position.z }, 12);
}

export function spawnMultiClaimEffect(player, chunkIds = []) {
    if (!Array.isArray(chunkIds) || chunkIds.length === 0) return;
    const maxEffects = 8;
    let shown = 0;
    for (const chunkId of chunkIds) {
        if (shown >= maxEffects) break;
        spawnClaimEffect(player, chunkId);
        shown++;
    }
}

export function spawnBaseSetEffect(player, location) {
    if (!player || !location) return;
    const position = { x: location.x, y: location.y + 1.5, z: location.z };
    spawnParticleSafe(player.dimension, "minecraft:end_rod", position, 24);
    spawnParticleSafe(player.dimension, "minecraft:happy_villager", { x: position.x, y: position.y + 0.5, z: position.z }, 16);
}

export function spawnBaseRadiusEffect(player, baseLocation, radius = 20) {
    if (!player || !baseLocation || radius <= 0) return;
    if (baseLocation.dimension && player.dimension.id !== baseLocation.dimension) return;
    const y = baseLocation.y + 0.5;
    const points = 18;
    const step = (Math.PI * 2) / points;
    for (let i = 0; i < points; i++) {
        const angle = i * step;
        const point = {
            x: baseLocation.x + Math.cos(angle) * radius,
            y,
            z: baseLocation.z + Math.sin(angle) * radius
        };
        spawnParticleSafe(player.dimension, "minecraft:end_rod", point, 6);
    }
    spawnParticleSafe(player.dimension, "minecraft:happy_villager", { x: baseLocation.x, y: baseLocation.y + 1.4, z: baseLocation.z }, 10);
}

export function spawnToggleEffect(player) {
    if (!player) return;
    const position = { x: player.location.x, y: player.location.y + 1.5, z: player.location.z };
    spawnParticleSafe(player.dimension, "minecraft:heart", position, 14);
}

function spawnChunkMarkerForPlayer(player, clanTag) {
    // Delegar a particleSystem: si el jugador tiene clan, mostrar sus reclamos;
    // si no tiene clan, mostrar reclamos cercanos (serán renderizados como hostiles)
    try {
        if (clanTag) {
            spawnClanClaimsAroundPlayer(player, clanTag, { maxToShow: 12, maxDistance: 96, detail: 12 });
        } else {
            spawnNearbyClaimsForPlayer(player, PROXIMITY_RADIUS_CHUNKS, { maxToShow: 12, maxDistance: 96, detail: 12 });
        }
    } catch (e) {
        // si falla, no romper el loop principal
    }
}

function updateClaimMarkers() {
    for (const playerName of Array.from(claimMarkerEnabled)) {
        const player = world.getPlayers().find(p => p.name === playerName);
        if (!player) {
            claimMarkerEnabled.delete(playerName);
            continue;
        }
        const clanTagRaw = player.getTags().find(t => t.startsWith("clan:"));
        const tag = clanTagRaw ? clanTagRaw.split(":")[1] : null;
        if (!tag) {
            player.onScreenDisplay.setActionBar("§7No perteneces a ningún clan.");
        } else {
            // Mostrar HUD con reclamos restantes
            try {
                const claimCount = TerritoryManager.getClanClaimCount(tag);
                const claimLimit = ClanManager.getClaimLimit(tag);
                const remaining = Math.max(0, (claimLimit || 0) - (claimCount || 0));
                player.onScreenDisplay.setActionBar(`§7Reclamos restantes: §e${remaining}`);
            } catch (e) {
                // silenciar errores de HUD
            }
        }
        // Mostrar marcadores para el clan del jugador (si existe) o mostrar claims cercanos en rojo si no tiene clan
        spawnChunkMarkerForPlayer(player, tag);
    }

    // Proximity-trigger: mostrar contornos a jugadores que se acercan a reclamos (si no tienen marcadores activados)
    try {
        for (const player of world.getPlayers()) {
            if (claimMarkerEnabled.has(player.name)) continue;
            const chunkId = TerritoryManager.getChunkId(player.location, player.dimension.id);
            const last = proximityCache.get(player.name) || {};
            if (last.chunkId === chunkId && (Date.now() - (last.lastAt || 0) < PROXIMITY_COOLDOWN_MS)) continue;
            const shown = spawnNearbyClaimsForPlayer(player, PROXIMITY_RADIUS_CHUNKS, { maxToShow: 8, maxDistance: 96, detail: 8 });
            if (shown && shown > 0) {
                proximityCache.set(player.name, { chunkId, lastAt: Date.now() });
            }
        }
    } catch (e) {}
}

function schedule() {
    if (typeof system.runInterval === "function") {
        system.runInterval(updateClaimMarkers, MARKER_INTERVAL_TICKS);
    } else {
        system.runTimeout(() => { updateClaimMarkers(); schedule(); }, MARKER_INTERVAL_TICKS);
    }
}

export function toggleClaimMarkers(player) {
    if (!player) return false;
    if (claimMarkerEnabled.has(player.name)) {
        claimMarkerEnabled.delete(player.name);
        player.onScreenDisplay.setActionBar("§cMarcadores de territorio desactivados.");
        try { Database.set(`nexus_claim_markers_${player.name}`, false); } catch(e) {}
        return false;
    }
    claimMarkerEnabled.add(player.name);
    player.onScreenDisplay.setActionBar("§aMarcadores de territorio activados.");
    try { Database.set(`nexus_claim_markers_${player.name}`, true); } catch(e) {}
    return true;
}

export function isClaimMarkerEnabled(player) {
    if (!player) return false;
    if (claimMarkerEnabled.has(player.name)) return true;
    try {
        const val = Database.get(`nexus_claim_markers_${player.name}`, false);
        return !!val;
    } catch (e) {
        return false;
    }
}

export function loadClaimMarkerPreference(player) {
    if (!player) return false;
    try {
        const enabled = Database.get(`nexus_claim_markers_${player.name}`, false);
        if (enabled) claimMarkerEnabled.add(player.name);
        return enabled;
    } catch (e) {
        return false;
    }
}

schedule();

// Cargar preferencias guardadas para jugadores ya en línea
try {
    for (const p of world.getPlayers()) {
        try {
            const enabled = Database.get(`nexus_claim_markers_${p.name}`, false);
            if (enabled) claimMarkerEnabled.add(p.name);
        } catch (e) {}
    }
} catch (e) {}
