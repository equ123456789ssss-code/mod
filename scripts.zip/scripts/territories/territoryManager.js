import { Database } from "../core/database.js";

export const claimCache = new Map();

export const TerritoryManager = {
    getChunkId(location, dimensionId) {
        return `${dimensionId}_${Math.floor(location.x / 16)}_${Math.floor(location.z / 16)}`;
    },
    initCache() {
        // CORRECCIÓN: Ahora lee los chunks desde cada clan de forma segura para evitar desbordamiento de memoria
        const clanTags = Database.getAllClans();
        for (const tag of clanTags) {
            const clanData = Database.getClanData(tag);
            if (clanData && clanData.claims) {
                for (const chunkId of clanData.claims) {
                    claimCache.set(chunkId, tag);
                }
            }
        }
    },
    getChunkOwner(chunkId) {
        return claimCache.get(chunkId) || null;
    },
    parseChunkId(chunkId) {
        if (!chunkId) return null;
        const parts = String(chunkId).split("_");
        if (parts.length < 3) return null;
        return { dimensionId: parts[0], x: parseInt(parts[1], 10), z: parseInt(parts[2], 10) };
    },
    getClanClaims(clanTag) {
        const clan = Database.getClanData(clanTag);
        return clan && Array.isArray(clan.claims) ? clan.claims.slice() : [];
    },
    claimChunk(chunkId, clanTag) {
        if (this.getChunkOwner(chunkId)) return "already_claimed";

        const clan = Database.getClanData(clanTag);
        if (!clan) return "error";

        if (!clan.claims) clan.claims = [];
        const limit = clan.claimLimit || 10;
        if (clan.claims.length >= limit) return "limit_reached";

        // Los datos se guardan directo en la estructura del clan
        clan.claims.push(chunkId);
        Database.saveClanData(clanTag, clan);
        claimCache.set(chunkId, clanTag);
        
        return "success";
    },
    claimRadius(centerChunkId, clanTag, radius = 1) {
        const parsed = this.parseChunkId(centerChunkId);
        if (!parsed) return { success: false, reason: "invalid_center" };
        const clan = Database.getClanData(clanTag);
        if (!clan) return { success: false, reason: "no_clan" };
        if (!clan.claims) clan.claims = [];

        const results = { claimed: [], skipped: [] };
        for (let dx = -radius; dx <= radius; dx++) {
            for (let dz = -radius; dz <= radius; dz++) {
                const nx = parsed.x + dx;
                const nz = parsed.z + dz;
                const chunkId = `${parsed.dimensionId}_${nx}_${nz}`;
                if (this.getChunkOwner(chunkId)) {
                    results.skipped.push({ chunkId, reason: "already_claimed" });
                    continue;
                }

                if (clan.claims.length >= (clan.claimLimit || 10)) {
                    results.skipped.push({ chunkId, reason: "limit_reached" });
                    continue;
                }

                clan.claims.push(chunkId);
                claimCache.set(chunkId, clanTag);
                results.claimed.push(chunkId);
            }
        }

        Database.saveClanData(clanTag, clan);
        return { success: true, results };
    },
    // Reclama hasta N chunks alrededor del centro, buscando en capas concéntricas.
    claimUpTo(centerChunkId, clanTag, maxChunks = 10) {
        const parsed = this.parseChunkId(centerChunkId);
        if (!parsed) return { success: false, reason: "invalid_center" };
        const clan = Database.getClanData(clanTag);
        if (!clan) return { success: false, reason: "no_clan" };
        if (!clan.claims) clan.claims = [];

        const limit = clan.claimLimit || 10;
        const available = Math.max(0, limit - clan.claims.length);
        const toClaim = Math.min(maxChunks, available);
        if (toClaim <= 0) return { success: false, reason: "limit_reached" };

        const claimed = [];
        const skipped = [];

        let layer = 0;
        while (claimed.length < toClaim && layer <= 50) {
            for (let dx = -layer; dx <= layer && claimed.length < toClaim; dx++) {
                for (let dz = -layer; dz <= layer && claimed.length < toClaim; dz++) {
                    // skip inner layers already processed
                    if (Math.max(Math.abs(dx), Math.abs(dz)) !== layer) continue;
                    const nx = parsed.x + dx;
                    const nz = parsed.z + dz;
                    const chunkId = `${parsed.dimensionId}_${nx}_${nz}`;
                    if (this.getChunkOwner(chunkId)) {
                        skipped.push({ chunkId, reason: "already_claimed" });
                        continue;
                    }
                    // double-check limit
                    if (clan.claims.length + claimed.length >= limit) {
                        skipped.push({ chunkId, reason: "limit_reached" });
                        continue;
                    }
                    clan.claims.push(chunkId);
                    claimCache.set(chunkId, clanTag);
                    claimed.push(chunkId);
                }
            }
            layer++;
        }

        Database.saveClanData(clanTag, clan);
        return { success: true, results: { claimed, skipped } };
    },
    getClanClaimCount(clanTag) {
        const clan = Database.getClanData(clanTag);
        return clan && Array.isArray(clan.claims) ? clan.claims.length : 0;
    },
    setBaseLocation(clanTag, location) {
        const clan = Database.getClanData(clanTag);
        if (!clan) return false;
        clan.base = {
            x: Math.floor(location.x),
            y: Math.floor(location.y),
            z: Math.floor(location.z),
            dimension: location.dimension ? location.dimension.id || location.dimension : null,
            radius: clan.base?.radius || 20
        };
        Database.saveClanData(clanTag, clan);
        return true;
    },
    getBaseLocation(clanTag) {
        const clan = Database.getClanData(clanTag);
        if (!clan) return null;
        return clan.base || null;
    },
    unclaimChunk(chunkId, clanTag) {
        if (this.getChunkOwner(chunkId) !== clanTag) return false;

        const clan = Database.getClanData(clanTag);
        if (!clan || !clan.claims) return false;

        clan.claims = clan.claims.filter(id => id !== chunkId);
        Database.saveClanData(clanTag, clan);
        claimCache.delete(chunkId);
        
        return true;
    }, // <--- ¡AQUÍ ESTÁ LA COMA QUE FALTABA!

    // Fuerza el reclamo de un chunk para un clan (admin). Remueve al propietario anterior.
    forceClaimChunk(chunkId, clanTag) {
        if (!chunkId || !clanTag) return false;
        const clan = Database.getClanData(clanTag);
        if (!clan) return false;

        // Remover de propietario anterior
        const prev = this.getChunkOwner(chunkId);
        if (prev) {
            const prevClan = Database.getClanData(prev);
            if (prevClan && Array.isArray(prevClan.claims)) {
                prevClan.claims = prevClan.claims.filter(c => c !== chunkId);
                Database.saveClanData(prev, prevClan);
            }
        }

        if (!clan.claims) clan.claims = [];
        if (!clan.claims.includes(chunkId)) clan.claims.push(chunkId);
        claimCache.set(chunkId, clanTag);
        Database.saveClanData(clanTag, clan);
        return true;
    },

    // Fuerza el unclaim de un chunk (admin)
    forceUnclaimChunk(chunkId) {
        if (!chunkId) return false;
        const owner = this.getChunkOwner(chunkId);
        if (!owner) return false;
        const clan = Database.getClanData(owner);
        if (clan && Array.isArray(clan.claims)) {
            clan.claims = clan.claims.filter(c => c !== chunkId);
            Database.saveClanData(owner, clan);
        }
        claimCache.delete(chunkId);
        return true;
    }
}