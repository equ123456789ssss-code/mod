import { world, system } from "@minecraft/server";
import { TerritoryManager } from "./territoryManager.js";
import { ClanManager } from "../clans/clanManager.js";
import { Logger } from "../core/logger.js";
import { Database } from "../core/database.js";
import { ClanBaseManager } from "../core/clanDatabase.js";

// Base protection now usa ClanBaseManager para evitar lógica duplicada.

const PROTECTED_BLOCKS = [
    "minecraft:chest", "minecraft:barrel", "minecraft:shulker_box", "minecraft:ender_chest",
    "minecraft:furnace", "minecraft:blast_furnace", "minecraft:smoker", "minecraft:hopper",
    "minecraft:dispenser", "minecraft:dropper",
    "minecraft:wooden_door", "minecraft:iron_door", "minecraft:trapdoor", 
    "minecraft:lever", "minecraft:stone_button", "minecraft:wooden_button"
];

function isProtected(player, blockLocation, dimensionId) {
    const chunkId = TerritoryManager.getChunkId(blockLocation, dimensionId);
    const ownerClan = TerritoryManager.getChunkOwner(chunkId);
    const baseClan = ClanBaseManager.getClaimAtPosition({
        x: blockLocation.x,
        y: blockLocation.y,
        z: blockLocation.z,
        dimension: dimensionId
    });
    if (!ownerClan || ClanManager.getPlayerClanTag(player.name) === ownerClan) return false;
    if (baseClan && ClanManager.getPlayerClanTag(player.name) !== baseClan) return true;
    return true;
}

world.beforeEvents.playerBreakBlock.subscribe((event) => {
    // CORRECCIÓN: Se usa event.player.dimension.id
    if (isProtected(event.player, event.block.location, event.player.dimension.id)) {
        event.cancel = true;
        system.run(() => event.player.onScreenDisplay.setActionBar("§cTerritorio enemigo."));
    }
});

world.beforeEvents.itemUseOn.subscribe((event) => {
    // En este evento, el jugador se llama 'event.source' en lugar de 'event.player'
    if (event.source && event.source.typeId === "minecraft:player") {
        if (isProtected(event.source, event.block.location, event.source.dimension.id)) {
            event.cancel = true;
            system.run(() => event.source.onScreenDisplay.setActionBar("§cTerritorio enemigo."));
        }
    }
}); // <-- Aquí estaba el "});" duplicado que causaba el error en la consola. Ya fue eliminado.

world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    if (PROTECTED_BLOCKS.some(block => event.block.typeId.includes(block.replace("minecraft:", "")))) {
        // CORRECCIÓN: Se usa event.player.dimension.id
        if (isProtected(event.player, event.block.location, event.player.dimension.id)) {
            event.cancel = true;
            
            const chunkId = TerritoryManager.getChunkId(event.block.location, event.player.dimension.id);
            const ownerClan = TerritoryManager.getChunkOwner(chunkId);
            
            system.run(() => {
                event.player.onScreenDisplay.setActionBar("§cEste bloque pertenece a otro clan.");
                Logger.logEvent("robo", `${event.player.name} intentó usar un bloque en territorio de [${ownerClan}] en X:${Math.floor(event.block.location.x)} Z:${Math.floor(event.block.location.z)}`);
                // Notificar al líder vía buzón si está configurado
                try {
                    const clanData = Database.getClanData(ownerClan);
                    if (clanData && clanData.leader) {
                        const logMsg = `§l§c⚠️ ALERTA DE INTRUSIÓN\n§fEl jugador §e${event.player.name} §fintentó interactuar con §7${event.block.typeId} §fen tu base.`;
                        Database.addMessageToInbox(clanData.leader, "SISTEMA (Seguridad)", logMsg);

                        const leaderPlayer = world.getPlayers().find(p => p.name === clanData.leader);
                        if (leaderPlayer) {
                            leaderPlayer.sendMessage(`§c[Nexus] ¡Alerta! ${event.player.name} intentó forzar un bloque en tu base.`);
                        }
                    }
                } catch (e) {}
            });
        }
    }
});