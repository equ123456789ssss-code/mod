import { world, system } from "@minecraft/server";
import { ClanManager } from "../clans/clanManager.js";
import { GroupManager } from "../core/groupManager.js";
import { FamiliarManager } from "../familiars/familiarManager.js";

function normalizeClanTag(tag) {
    if (!tag) return null;
    return String(tag).trim().toUpperCase() || null;
}

export const TeamDamageSystem = {
    areAllies(entityA, entityB) {
        if (!entityA || !entityB || entityA.typeId !== "minecraft:player" || entityB.typeId !== "minecraft:player") return false;

        const clanA = normalizeClanTag(ClanManager.getPlayerClanTag(entityA.name));
        const clanB = normalizeClanTag(ClanManager.getPlayerClanTag(entityB.name));
        if (clanA && clanB && clanA === clanB) return true;

        if (clanA && clanB) {
            try {
                const alliesA = ClanManager.getAllies(clanA) || [];
                if (Array.isArray(alliesA) && alliesA.map(a => normalizeClanTag(a)).includes(clanB)) return true;
            } catch (e) {}
        }

        const partyA = GroupManager.getParty(entityA.name);
        const partyB = GroupManager.getParty(entityB.name);
        if (partyA && partyB && partyA === partyB) return true;

        return false;
    },

    resolveDamager(damagingEntity) {
        if (!damagingEntity) return null;
        if (damagingEntity.typeId === "minecraft:player") return damagingEntity;

        const players = world.getPlayers ? world.getPlayers() : [];
        const findPlayerByName = (name) => typeof name === "string" ? players.find(p => p.name.toLowerCase() === name.toLowerCase()) || null : null;
        const resolveEntityPlayer = (entity) => {
            if (!entity) return null;
            if (entity.typeId === "minecraft:player") return entity;
            if (typeof entity.name === "string") return findPlayerByName(entity.name);
            if (typeof entity.owner === "string") return findPlayerByName(entity.owner);
            return null;
        };

        try {
            const tameable = damagingEntity.getComponent && damagingEntity.getComponent("minecraft:tameable");
            if (tameable && tameable.tamedToPlayerId) {
                return players.find(p => p.id === tameable.tamedToPlayerId) || null;
            }
        } catch (e) {}

        const candidates = [];
        if (typeof damagingEntity.owner === "string") candidates.push(damagingEntity.owner);
        else if (damagingEntity.owner && typeof damagingEntity.owner === "object") candidates.push(damagingEntity.owner);
        if (typeof damagingEntity.attacker === "string") candidates.push(damagingEntity.attacker);
        else if (damagingEntity.attacker && typeof damagingEntity.attacker === "object") candidates.push(damagingEntity.attacker);
        if (typeof damagingEntity.shooter === "string") candidates.push(damagingEntity.shooter);
        else if (damagingEntity.shooter && typeof damagingEntity.shooter === "object") candidates.push(damagingEntity.shooter);
        if (typeof damagingEntity.source === "string") candidates.push(damagingEntity.source);
        else if (damagingEntity.source && typeof damagingEntity.source === "object") candidates.push(damagingEntity.source);
        if (typeof damagingEntity.projectileOwner === "string") candidates.push(damagingEntity.projectileOwner);
        else if (damagingEntity.projectileOwner && typeof damagingEntity.projectileOwner === "object") candidates.push(damagingEntity.projectileOwner);

        for (const candidate of candidates) {
            try {
                const resolved = resolveEntityPlayer(candidate);
                if (resolved) return resolved;
            } catch (e) {}
        }

        try {
            const ownerName = FamiliarManager.getOwnerByEntityId(damagingEntity.id);
            if (ownerName) return findPlayerByName(ownerName);
        } catch (e) {}

        return null;
    }
};

world.afterEvents.entityHurt.subscribe((event) => {
    const victim = event.hurtEntity;
    if (victim.typeId !== "minecraft:player") return;

    // Resolver atacante normal (jugador o propietario de familiar)
    let damagerPlayer = TeamDamageSystem.resolveDamager(event.damageSource.damagingEntity);

    // Fallback: si no se resolvió, intentar detectar si la entidad atacante es un familiar registrado
    if (!damagerPlayer) {
        try {
            const damEnt = event.damageSource && event.damageSource.damagingEntity ? event.damageSource.damagingEntity : null;
            const entId = damEnt && (damEnt.id || damEnt.__unique_id || damEnt.__id) ? (damEnt.id || damEnt.__unique_id || damEnt.__id) : null;
            const ownerName = entId ? FamiliarManager.getOwnerByEntityId(entId) : null;
            if (ownerName) {
                damagerPlayer = world.getPlayers().find(p => p.name === ownerName) || null;
            }
        } catch (e) {}
    }

    if (!damagerPlayer || victim.name === damagerPlayer.name) return;

    if (TeamDamageSystem.areAllies(victim, damagerPlayer)) {
        system.run(() => {
            const healthComp = victim.getComponent("minecraft:health");
            if (healthComp) {
                // CORRECCIÓN: effectiveMax respeta los corazones extra de pociones/manzanas doradas
                healthComp.setCurrentValue(Math.min(healthComp.currentValue + event.damage, healthComp.effectiveMax));
                try { damagerPlayer.onScreenDisplay.setActionBar("§c¡Estás golpeando a un aliado!"); } catch (e) {}
            }
        });
    }
});