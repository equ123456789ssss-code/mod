export const Config = {
    CLAN_MIN_TAG_LENGTH: 2,
    CLAN_MAX_TAG_LENGTH: 4,
    CLAN_MAX_MEMBERS: 15,
    CLAN_CLAIM_LIMIT: 10,
    CHAT_COOLDOWN_MS: 1500,
    CHAT_WARNING_THRESHOLD: 2,
    CHAT_MUTE_DURATION_MS: 15000,
    BOOKMARK_LIMIT: 20,
    UI_HEADER: "§l§9Nexus §8| §fSistema Social",
    UI_DIVIDER: "§7-----------------------------"
};
