# Pendientes y tareas — NexusSocia Add-on

## Estado actual

- El menú de clanes y la UI de guerra ya están conectados.
- El comando `!guerra` abre la UI de guerras.
- El sistema de alianzas existe y se usa para solicitar ayuda aliada en guerras.
- `WarManager` ya puede crear solicitudes de guerra y solicitudes de ayuda (`ally`).
- La UI permite aceptar/rechazar solicitudes y ver guerras activas.
- Se agregó soporte para aliados fuera de la guerra y notificaciones básicas.

## Tareas pendientes reales


1) Validación y pulido de UI
   - Validar entradas de formularios en `scripts/ui/warForms.js` y `scripts/ui/clanForms.js`.
   - Asegurar que no se acepte un clan inválido, nulo o repetido.
   - Mejorar mensajes y botones para distinguir entre guerra y ayuda aliada.
   - Archivos: `scripts/ui/warForms.js`, `scripts/ui/clanForms.js`
   - Prioridad: alta

2) Integración de solicitudes en notificaciones/inbox
   - Asegurar que líderes de clanes reciban aviso claro cuando hay solicitudes de guerra, ayuda o alianzas.
   - Se integró el envío de invitaciones de alianza en `scripts/ui/inboxMenu.js` para persistir mensajes incluso si el líder está offline.
   - Archivos: `scripts/ui/inboxMenu.js`, `scripts/ui/clanForms.js`, `scripts/war/warManager.js`
   - Prioridad: media

3) Revisión de anti-exploit y friendly-fire
   - Confirmar que los familiares no dañen a aliados en `scripts/teams/teamDamageSystem.js`.
   - Revisar si existe lógica de daño directo en familiares y evitar modificación de HP si ya se corrigió.
   - Archivos: `scripts/teams/teamDamageSystem.js`, `scripts/familiars/familiarManager.js`
   - Prioridad: media-alta

4) Ajustes de flujo de guerra aliada
   - Validar que la solicitud `ally` solo se pueda crear si el clan es aliado y el clan solicitante participa en la guerra.
   - Confirmar que aceptar ayuda agrega el clan al arreglo `war.clans` correctamente.
   - Asegurar que el menú de guerra muestre participantes y aliados actuales.
   - Corregir detección de guerras activas entre clanes cuando hay aliados ya dentro de la guerra.
   - Archivos: `scripts/war/warManager.js`, `scripts/ui/warForms.js`
   - Prioridad: alta

   - Probar en juego los casos:
     - declarar guerra a un clan
     - rechazar solicitud de guerra
     - pedir ayuda a un aliado
     - aceptar / rechazar ayuda aliada
     - ver guerras activas desde el menú
   - Archivos: todo el sistema UI y comandos
   - Prioridad: crítica

6) Documentación mínima de comandos
   - Añadir nota simple para `!guerra`, `!clan`, `!inbox`, y comandos de familiares.
   - Archivos: `README.md` o `scripts/PENDING_TASKS.md`
   - Prioridad: baja

## Tareas ya consideradas completadas

- Persistencia y limpieza de familiares.
- Comandos `!soltar`, `!llamar`, `!listar`, `!modo_guardia`.
- Base del `WarManager` y UI de guerra.
- TTL/backups en `scripts/core/database.js`.

## Siguientes pasos sugeridos

1) Revisión y pulido de `scripts/ui/warForms.js`.
2) Probar el flujo de ayuda aliada en juego.
3) Añadir notificaciones en inbox si falta.
4) Reforzar validación de inputs y anti-spam.
