import { world, system } from "@minecraft/server";
import { Database } from "../core/database.js";

const STORAGE_KEY = "nexus_familiars_v1";

export const FamiliarManager = {
    _entityToOwner: new Map(), // entityId -> { owner, entityType, ts }
    _ownerToEntities: new Map(), // ownerName -> Set(entityId)
    _maxPerPlayer: 3,
    _followIntervalMs: 1000,
    _teleportThreshold: 10,
    _defendDamage: 4,
    _attackRadius: 6,
    _attackDamage: 3,
    _attackCooldownMs: 2000,
    _lastAttackMap: new Map(),
    _guardMode: new Map(), // ownerName -> boolean

    init() {
        try {
            const raw = Database.get(STORAGE_KEY, {});
            if (raw && typeof raw === "object") {
                for (const k of Object.keys(raw)) {
                    const meta = raw[k];
                    if (!meta || !meta.owner) continue;
                    const id = String(k);
                    this._entityToOwner.set(id, { owner: meta.owner, entityType: meta.entityType || null, ts: meta.ts || Date.now() });
                    if (!this._ownerToEntities.has(meta.owner)) this._ownerToEntities.set(meta.owner, new Set());
                    this._ownerToEntities.get(meta.owner).add(id);
                }
            }
        } catch (e) {
            // cargar fallida no es crítico
        }

        // Limpiar familiares huérfanos al arrancar
        try {
            this.cleanupOrphanedFamiliars();
        } catch (e) {}

        // Suscribirse a varios eventos de muerte/desaparición para limpiar familiares
        try {
            const eventNames = ['entityDie', 'entityRemoved', 'entityRemove', 'entityDespawn', 'entityDespawned', 'entityDestroyed'];
            const handler = (ev) => {
                try {
                    const ent = ev.deadEntity || ev.entity || ev.hurtEntity || ev.entityKilled || ev.entityRemoved || ev.removedEntity || ev.removed || null;
                    if (!ent) return;
                    const id = this._getEntityId(ent);
                    if (!id) return;
                    const sid = String(id);
                    if (this._entityToOwner.has(sid)) {
                        const owner = this.getOwnerByEntityId(sid);
                        this.unregisterFamiliar(sid);
                        try {
                            const p = world.getPlayers().find(pl => pl.name === owner);
                            if (p) p.sendMessage("§e[Nexus] Tu familiar ha muerto/desaparecido y ha sido liberado.");
                        } catch (e) {}
                    }
                } catch (e) {}
            };

            for (const name of eventNames) {
                const evObj = (world.afterEvents && world.afterEvents[name]) ? world.afterEvents[name] : (world.events && world.events[name]) ? world.events[name] : null;
                if (evObj && typeof evObj.subscribe === 'function') {
                    try { evObj.subscribe(handler); } catch (e) {}
                }
            }
        } catch (e) {}

        // Periodic cleanup: verificar si las entidades registradas siguen existiendo
        try {
            if (typeof system.runInterval === 'function') {
                system.runInterval(() => {
                    try {
                        const exists = new Set();
                        if (typeof world.getEntities === 'function') {
                            try {
                                for (const en of world.getEntities()) {
                                    const id = this._getEntityId(en);
                                    if (id) exists.add(String(id));
                                }
                            } catch (e) {}
                        }

                        for (const id of Array.from(this._entityToOwner.keys())) {
                            if (!exists.has(String(id))) {
                                const owner = this.getOwnerByEntityId(id);
                                this.unregisterFamiliar(id);
                                try {
                                    const p = world.getPlayers().find(pl => pl.name === owner);
                                    if (p) p.sendMessage("§e[Nexus] Uno de tus familiares fue liberado (no encontrado).");
                                } catch (e) {}
                            }
                        }
                    } catch (e) {}
                }, 10000);
            }
        } catch (e) {}

        // Loop de comportamiento: hacer que los familiares sigan al jugador, reaccionen a ataques y ataquen amenazas
        try {
            if (typeof system.runInterval === 'function') {
                system.runInterval(() => {
                    try {
                        for (const [id, meta] of this._entityToOwner.entries()) {
                            try {
                                const ownerName = meta.owner;
                                const player = world.getPlayers().find(p => p.name === ownerName);
                                if (!player) continue;
                                const ent = this._findEntityById(id);
                                if (!ent) continue;
                                if (!ent.location || !player.location) continue;

                                const dx = ent.location.x - player.location.x;
                                const dz = ent.location.z - player.location.z;
                                const dist2 = dx * dx + dz * dz;
                                if (dist2 > this._teleportThreshold * this._teleportThreshold) {
                                    try {
                                        const tx = player.location.x + (Math.random() * 2 - 1) * 2;
                                        const ty = Math.max(1, player.location.y);
                                        const tz = player.location.z + (Math.random() * 2 - 1) * 2;
                                        if (typeof ent.teleport === 'function') {
                                            ent.teleport({ x: tx, y: ty, z: tz });
                                        }
                                    } catch (e) {}
                                }
                                // Buscar amenazas cercanas y atacar si corresponde
                                try {
                                    const now = Date.now();
                                    const last = this._lastAttackMap.get(id) || 0;
                                    if (now - last >= this._attackCooldownMs) {
                                        const dim = ent.dimension || (player && player.dimension) || world.getDimension("overworld");
                                        if (dim && typeof dim.getEntities === 'function') {
                                            let threat = null;
                                            let bestDist = Number.POSITIVE_INFINITY;
                                            try {
                                                for (const cand of dim.getEntities()) {
                                                    try {
                                                        if (!cand || !cand.location || !cand.typeId) continue;
                                                        if (String(cand.typeId).startsWith("minecraft:player")) continue;
                                                        const cid = cand.id || cand.__unique_id || cand.__id || null;
                                                        if (cid && String(cid) === String(id)) continue;
                                                        // debe tener componente de salud
                                                        let hp = null;
                                                        try { hp = cand.getComponent && cand.getComponent("minecraft:health"); } catch (ee) { hp = null; }
                                                        if (!hp) continue;

                                                        const ddx = cand.location.x - ent.location.x;
                                                        const ddz = cand.location.z - ent.location.z;
                                                        const d2 = ddx * ddx + ddz * ddz;
                                                        if (d2 <= this._attackRadius * this._attackRadius && d2 < bestDist) {
                                                            threat = cand;
                                                            bestDist = d2;
                                                        }
                                                    } catch (ee) { continue; }
                                                }
                                            } catch (ee) {}

                                            if (threat) {
                                                try {
                                                    // Teleport cercano para que el familiar intercepte la amenaza, sin dañar directamente.
                                                    const tx = threat.location.x + (Math.random() * 2 - 1) * 0.6;
                                                    const ty = Math.max(1, threat.location.y);
                                                    const tz = threat.location.z + (Math.random() * 2 - 1) * 0.6;
                                                    if (typeof ent.teleport === 'function') ent.teleport({ x: tx, y: ty, z: tz });
                                                } catch (e) {}

                                                try {
                                                    if (player && player.onScreenDisplay && typeof player.onScreenDisplay.setActionBar === 'function') {
                                                        player.onScreenDisplay.setActionBar("§a[Nexus] Tu familiar está confrontando una amenaza.");
                                                    }
                                                } catch (e) {}

                                                this._lastAttackMap.set(id, now);
                                            }
                                        }
                                    }
                                } catch (e) {}
                            } catch (e) {}
                        }
                    } catch (e) {}
                }, this._followIntervalMs);
            }
        } catch (e) {}

        // Suscripción a eventos de daño para que los familiares reaccionen defendiendo al jugador
        try {
            const hurtEvent = (world.afterEvents && world.afterEvents.entityHurt)
                ? world.afterEvents.entityHurt
                : (world.events && world.events.entityHurt) ? world.events.entityHurt : null;
            if (hurtEvent && typeof hurtEvent.subscribe === 'function') {
                hurtEvent.subscribe((ev) => {
                    try {
                        const victim = ev.hurtEntity || ev.entity || ev.victim || null;
                        if (!victim || victim.typeId !== "minecraft:player") return;
                        const ownerName = victim.name;
                        const damager = ev.damageSource && ev.damageSource.damagingEntity;
                        if (!damager) return;
                        if (damager.typeId === "minecraft:player") return;

                        const familiars = this.getFamiliarsForPlayer(ownerName);
                        if (!familiars || familiars.length === 0) return;
                        if (!this.isGuardMode(ownerName)) return;

                        for (const fid of familiars) {
                            try {
                                const fEnt = this._findEntityById(fid);
                                if (!fEnt || !damager.location) continue;
                                try {
                                    const tx = damager.location.x + (Math.random() * 2 - 1) * 1.2;
                                    const ty = Math.max(1, damager.location.y);
                                    const tz = damager.location.z + (Math.random() * 2 - 1) * 1.2;
                                    if (typeof fEnt.teleport === 'function') fEnt.teleport({ x: tx, y: ty, z: tz });
                                } catch (e) {}

                                try {
                                    if (typeof victim.onScreenDisplay?.setActionBar === 'function') {
                                        victim.onScreenDisplay.setActionBar("§a[Nexus] Tus familiares están defendiendo.");
                                    }
                                } catch (e) {}
                            } catch (e) {}
                        }
                    } catch (e) {}
                });
            }
        } catch (e) {}
    },

    save() {
        try {
            const out = {};
            for (const [id, meta] of this._entityToOwner.entries()) {
                out[String(id)] = { owner: meta.owner, entityType: meta.entityType || null, ts: meta.ts || Date.now() };
            }
            Database.set(STORAGE_KEY, out);
        } catch (e) {
            // silenciar
        }
    },

    _normalizeEntityId(entityId) {
        if (entityId === undefined || entityId === null) return null;
        return String(entityId);
    },

    _getEntityId(entity) {
        if (!entity || typeof entity !== "object") return null;
        return entity.id || entity.__unique_id || entity.__id || null;
    },

    _entityHasHealth(entity) {
        if (!entity) return false;
        try {
            return !!(entity.getComponent && entity.getComponent("minecraft:health"));
        } catch (e) {
            return false;
        }
    },

    cleanupOrphanedFamiliars() {
        const alive = new Set();
        try {
            if (typeof world.getEntities === "function") {
                for (const entity of world.getEntities()) {
                    const id = this._getEntityId(entity);
                    if (id) alive.add(String(id));
                }
            }
        } catch (e) {}

        for (const id of Array.from(this._entityToOwner.keys())) {
            if (!alive.has(String(id))) {
                const owner = this.getOwnerByEntityId(id);
                this.unregisterFamiliar(id);
                try {
                    const player = world.getPlayers().find(pl => pl.name === owner);
                    if (player) player.sendMessage("§e[Nexus] Uno de tus familiares fue liberado (no pudo ser localizado).");
                } catch (e) {}
            }
        }
    },

    callFamiliarById(entityId, ownerName) {
        const id = this._normalizeEntityId(entityId);
        if (!id) return false;
        const owner = this.getOwnerByEntityId(id);
        if (!owner || (ownerName && owner !== ownerName)) return false;
        const player = world.getPlayers().find(p => p.name === owner);
        if (!player) return false;
        const entity = this._findEntityById(id);
        if (!entity) {
            this.unregisterFamiliar(id);
            return false;
        }
        try {
            const target = {
                x: player.location.x + (Math.random() * 2 - 1) * 1.5,
                y: Math.max(1, player.location.y),
                z: player.location.z + (Math.random() * 2 - 1) * 1.5
            };
            if (typeof entity.teleport === "function") entity.teleport(target);
            return true;
        } catch (e) {
            return false;
        }
    },

    releaseFamiliarByEntityId(entityId, ownerName) {
        const id = this._normalizeEntityId(entityId);
        if (!id) return false;
        const owner = this.getOwnerByEntityId(id);
        if (!owner || (ownerName && owner !== ownerName)) return false;
        return this.unregisterFamiliar(id);
    },

    callFamiliarsToPlayer(ownerName) {
        const player = world.getPlayers().find(p => p.name === ownerName);
        if (!player) return { success: false, called: 0, total: 0 };
        const familiars = this.getFamiliarsForPlayer(ownerName);
        let called = 0;
        for (const id of familiars) {
            const entity = this._findEntityById(id);
            if (!entity) {
                this.unregisterFamiliar(id);
                continue;
            }
            try {
                const target = {
                    x: player.location.x + (Math.random() * 2 - 1) * 1.5,
                    y: Math.max(1, player.location.y),
                    z: player.location.z + (Math.random() * 2 - 1) * 1.5
                };
                if (typeof entity.teleport === "function") entity.teleport(target);
                called++;
            } catch (e) {}
        }
        return { success: called > 0, called, total: familiars.length };
    },

    releaseFamiliarsForPlayer(ownerName) {
        const familiars = this.getFamiliarsForPlayer(ownerName);
        if (!familiars || familiars.length === 0) return false;
        for (const id of familiars) {
            this.unregisterFamiliar(id);
        }
        return true;
    },

    listFamiliarStatus(ownerName) {
        const result = [];
        const ids = this.getFamiliarsForPlayer(ownerName);
        for (const id of ids) {
            const meta = this._entityToOwner.get(id);
            const alive = !!this._findEntityById(id);
            result.push({
                entityId: id,
                entityType: meta ? meta.entityType || "unknown" : "unknown",
                alive
            });
        }
        return {
            guardMode: this.isGuardMode(ownerName),
            familiars: result
        };
    },

    isGuardMode(ownerName) {
        if (!ownerName) return true;
        const key = String(ownerName);
        if (!this._guardMode.has(key)) return true;
        return !!this._guardMode.get(key);
    },

    toggleGuardMode(ownerName) {
        if (!ownerName) return false;
        const key = String(ownerName);
        const next = !this.isGuardMode(key);
        this._guardMode.set(key, next);
        return next;
    },

    setGuardMode(ownerName, enabled) {
        if (!ownerName) return false;
        const key = String(ownerName);
        const next = !!enabled;
        this._guardMode.set(key, next);
        return next;
    },

    registerFamiliar(ownerName, entityId, entityType) {
        if (!ownerName || !entityId) return false;
        const owner = String(ownerName);
        const id = this._normalizeEntityId(entityId);
        if (!id) return false;
        const entity = this._findEntityById(id);
        if (!entity || !this._entityHasHealth(entity)) return false;
        let set = this._ownerToEntities.get(owner);
        if (!set) { set = new Set(); this._ownerToEntities.set(owner, set); }
        if (set.has(id)) return false; // ya registrado
        if (set.size >= this._maxPerPlayer) return false;

        this._entityToOwner.set(id, { owner, entityType: entityType || null, ts: Date.now() });
        set.add(id);
        this.save();
        return true;
    },

    unregisterFamiliar(entityId) {
        const id = String(entityId);
        const meta = this._entityToOwner.get(id);
        if (!meta) return false;
        const owner = meta.owner;
        this._entityToOwner.delete(id);
        const set = this._ownerToEntities.get(owner);
        if (set) {
            set.delete(id);
            if (set.size === 0) this._ownerToEntities.delete(owner);
        }
        this.save();
        return true;
    },

    getOwnerByEntityId(entityId) {
        if (!entityId) return null;
        const meta = this._entityToOwner.get(String(entityId));
        return meta ? meta.owner : null;
    },

    getFamiliarsForPlayer(playerName) {
        if (!playerName) return [];
        const set = this._ownerToEntities.get(String(playerName));
        return set ? Array.from(set) : [];
    },

    _findEntityById(entityId) {
        if (!entityId) return null;
        const sid = String(entityId);
        try {
            if (typeof world.getEntities === 'function') {
                for (const e of world.getEntities()) {
                    const id = e.id || e.__unique_id || e.__id || null;
                    if (id && String(id) === sid) return e;
                }
            }
        } catch (e) {}
        return null;
    },

    recruitNearest(player, radius = 6) {
        if (!player) return "Jugador inválido.";
        try {
            const dim = player.dimension;
            let entities = [];
            if (dim && typeof dim.getEntities === "function") {
                entities = dim.getEntities();
            } else if (typeof world.getEntities === "function") {
                entities = world.getEntities();
            } else {
                return "No es posible acceder a entidades en esta versión del servidor.";
            }

            let best = null;
            let bestDist = Number.POSITIVE_INFINITY;
            for (const e of entities) {
                try {
                    if (!e || !e.typeId) continue;
                    if (String(e.typeId).startsWith("minecraft:player")) continue;
                    if (!e.location) continue;
                    // filtrar por entidades vivas con componente de salud
                    let healthComp = null;
                    try { healthComp = e.getComponent && e.getComponent("minecraft:health"); } catch (ee) { healthComp = null; }
                    if (!healthComp) continue;

                    const dx = e.location.x - player.location.x;
                    const dz = e.location.z - player.location.z;
                    const dist2 = dx * dx + dz * dz;
                    if (dist2 <= radius * radius && dist2 < bestDist) {
                        best = e;
                        bestDist = dist2;
                    }
                } catch (ee) { continue; }
            }

            if (!best) return "No se encontró ningún mob válido cerca.";
            const eid = best.id || best.__unique_id || best.__id || null;
            if (!eid) return "No se pudo identificar la entidad seleccionada.";

            const ok = this.registerFamiliar(player.name, String(eid), best.typeId || null);
            if (ok) return { success: true, entityId: String(eid), entityType: best.typeId || null };
            return "No se pudo reclutar (ya es familiar o límite alcanzado).";
        } catch (e) {
            return "Error al intentar reclutar familiar.";
        }
    }
};

export default FamiliarManager;
