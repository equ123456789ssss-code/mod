export const Messages = {
    prefix: "§8[§bNexus§8]§r ",

    error(text) {
        return `${this.prefix}§c${text}`;
    },

    success(text) {
        return `${this.prefix}§a${text}`;
    },

    info(text) {
        return `${this.prefix}§f${text}`;
    },

    warning(text) {
        return `${this.prefix}§e${text}`;
    }
};
