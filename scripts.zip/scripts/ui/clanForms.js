import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { ClanManager } from "../clans/clanManager.js";
import { ClanInvites } from "../clans/clanInvites.js";
import { TerritoryManager } from "../territories/territoryManager.js";
import { showWarMenu, showWarHistory } from "./warForms.js";
import { WarManager } from "../war/warManager.js";
import { toggleClaimMarkers, isClaimMarkerEnabled, spawnClaimEffect, spawnMultiClaimEffect, spawnBaseSetEffect, spawnBaseRadiusEffect, spawnToggleEffect } from "../territories/claimMarkers.js";
import { ClanRoles } from "../clans/clanRoles.js";
import { Database } from "../core/database.js";
import { world, system } from "@minecraft/server";

const lastClaimActions = new Map();

function normalizeClanTag(tag) {
    if (!tag && tag !== 0) return null;
    const s = String(tag).trim();
    if (!s) return null;
    return s.toUpperCase();
}

function normalizeClanIcon(icon) {
    if (!icon && icon !== 0) return "⚔️";
    const s = String(icon).trim();
    if (!s) return "⚔️";
    return s.length > 8 ? s.substring(0, 8) : s;
}

function normalizeClanPassword(password) {
    if (password === undefined || password === null) return null;
    const s = String(password).trim();
    return s.length ? s : null;
}

function safeGetMemberRole(playerName, clan) {
    if (!playerName || !clan || !clan.members) return null;
    try {
        const m = clan.members[playerName] || clan.members[String(playerName).toLowerCase()] || clan.members[String(playerName).toUpperCase()];
        return m && m.role ? m.role : null;
    } catch (e) {
        return null;
    }
}

function notifyClanMembers(clanTag, text) {
    if (!clanTag || !text) return;
    try {
        const clan = ClanManager.getClan(clanTag);
        if (!clan) return;
        let members = [];
        if (Array.isArray(clan.members)) members = clan.members.slice();
        else if (clan.members && typeof clan.members === 'object') members = Object.keys(clan.members);

        for (const name of members) {
            try {
                const p = world.getPlayers().find(pl => pl.name === name);
                if (p) p.sendMessage(text);
            } catch (e) {}
        }
    } catch (e) {}
}

export function showMainClanMenu(player) {
    const clanTag = ClanManager.getPlayerClanTag(player.name);
    if (!clanTag) showNoClanMenu(player);
    else showActiveClanMenu(player, clanTag);
}

function showNoClanMenu(player) {
    new ActionFormData()
        .title("§l§9Nexus §8| §fClanes")
        .body("No perteneces a ningún clan.")
        .button("§l§2Crear un Clan")
        .button("§l§cCerrar")
        .show(player).then(r => {
            if (!r.canceled && r.selection === 0) showCreateClanForm(player);
        }).catch(() => {});
}

function showCreateClanForm(player) {
    new ModalFormData()
        .title("§l§9Crear Nuevo Clan")
        .textField("Etiqueta (Tag) [Máx 4]:", "Ej: WAR")
        .textField("Nombre completo:", "Ej: Warriors")
        .textField("Contraseña (Opcional):", "Ej: 1234")
        .textField("Icono del clan (Opcional):", "Ej: ⚔️")
        .show(player).then(r => {
            if (r.canceled) return;
            const [tag, name, password, icon] = r.formValues;
            const normalized = normalizeClanTag(tag);
            if (!normalized || normalized.length < 2 || normalized.length > 4 || !/^[A-Z0-9]+$/.test(normalized)) return player.sendMessage("§c[Nexus] §7Tag inválido. Usa 2-4 caracteres alfanuméricos.");
            const clanName = String(name || "").trim();
            if (!clanName) return player.sendMessage("§c[Nexus] §7Nombre del clan inválido.");

            const clanPassword = normalizeClanPassword(password);
            if (clanPassword && (clanPassword.length < 4 || clanPassword.length > 16)) return player.sendMessage("§c[Nexus] §7Contraseña inválida. Usa 4-16 caracteres.");
            const clanIcon = normalizeClanIcon(icon);
            
            system.run(() => {
                if (ClanManager.createClan(normalized, clanName, player.name, clanPassword, clanIcon)) {
                    player.sendMessage(`§a[Nexus] §7Clan §b[${normalized}] §7creado.`);
                } else {
                    player.sendMessage("§c[Nexus] §7Ese Tag ya está en uso o ya perteneces a un clan.");
                }
            });
        });
}

function showActiveClanMenu(player, tag) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return;

    const role = safeGetMemberRole(player.name, clan);
    const isLeader = role === "leader" || role === "coleader";

    const pendingWarRequests = isLeader ? WarManager.getPendingRequestsForClan(tag).length : 0;
    const outgoingWarRequests = isLeader ? WarManager.getOutgoingRequestsForClan(tag).length : 0;
    const activeWars = WarManager.getWarsForClan(tag).length;

    const memberCount = clan.members ? Object.keys(clan.members).length : 0;
    const displayTag = normalizeClanTag(tag) || tag;
    const clanIcon = clan.icon || "⚔️";
    const form = new ActionFormData()
        .title(`§l§9Clan ${clanIcon} §8[§b${displayTag}§8]`)
        .body(`§7Icono: §f${clanIcon}\n§7Nombre: §f${clan.name}\n§7Rango: §a${role || 'Desconocido'}\n§7Miembros: §e${memberCount}/15\n§7Solicitudes entrantes: §e${pendingWarRequests}\n§7Solicitudes salientes: §e${outgoingWarRequests}\n§7Guerras activas: §e${activeWars}`)
    if (isLeader) {
        form.button("§l§2Invitar Jugador");
        form.button("§l§dAjustes de Clan");
        form.button("§l§6Gestión de Territorio");
        form.button("§l§eConfigurar Límite de Reclamos");
        form.button("§l§eRestaurar Backup del Clan");
        form.button("§l§4Gestión de Alianzas");
        form.button(`§l§3Solicitudes Entrantes ${pendingWarRequests ? `(${pendingWarRequests})` : ""}`);
        form.button(`§l§6Solicitudes Salientes ${outgoingWarRequests ? `(${outgoingWarRequests})` : ""}`);
        form.button("§l§5Gestión de Guerras");
    }
    form.button("§l§5Ver Guerras");
    form.button("§l§bHistorial de Guerras");
    form.button("§l§cAbandonar Clan");

    form.show(player).then((response) => {
        if (response.canceled) return;

        if (isLeader) {
            if (response.selection === 0) return showInviteForm(player, tag);
            if (response.selection === 1) return showClanSettings(player, tag);
            if (response.selection === 2) return showTerritoryMenu(player, tag);
            if (response.selection === 3) return showSetClaimLimitForm(player, tag);
            if (response.selection === 4) return showRestoreClanBackup(player, tag);
            if (response.selection === 5) return showAllianceMenu(player, tag);
            if (response.selection === 6) return showWarRequests(player, tag);
            if (response.selection === 7) return showOutgoingWarRequests(player, tag);
            if (response.selection === 8) return showWarMenu(player, tag);
            if (response.selection === 9) return showWarHistory(player, tag);
            if (response.selection === 10) return showLeaveConfirm(player);
            if (response.selection === 11) return showLeaveConfirm(player);
        } else {
            if (response.selection === 0) return showWarMenu(player, tag);
            if (response.selection === 1) return showWarHistory(player, tag);
            if (response.selection === 2) return showLeaveConfirm(player);
        }
    });
}

function showClanSettings(player, tag) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return showActiveClanMenu(player, tag);

    const currentIcon = clan.icon || "⚔️";
    const passwordStatus = clan.password ? "Configurada" : "No establecida";

    new ActionFormData()
        .title(`§l§dAjustes de Clan - ${tag}`)
        .body(`§7Icono actual: §f${currentIcon}\n§7Contraseña: §f${passwordStatus}`)
        .button("§lCambiar Icono")
        .button(clan.password ? "§lCambiar/Eliminar Contraseña" : "§lEstablecer Contraseña")
        .button("§cVolver")
        .show(player).then(res => {
            if (res.canceled || res.selection === 2) return showActiveClanMenu(player, tag);
            if (res.selection === 0) return showSetClanIconForm(player, tag);
            if (res.selection === 1) return showSetClanPasswordForm(player, tag);
        });
}

function showSetClanIconForm(player, tag) {
    const clan = ClanManager.getClan(tag);
    const currentIcon = clan?.icon || "⚔️";

    new ModalFormData()
        .title("§l§dIcono del Clan")
        .textField("Nuevo icono del clan:", currentIcon)
        .show(player).then(res => {
            if (res.canceled) return showClanSettings(player, tag);
            const value = normalizeClanIcon(res.formValues[0]);
            if (ClanManager.setClanIcon(tag, value)) {
                player.sendMessage(`§a[Nexus] Icono del clan actualizado a ${value}.`);
            } else {
                player.sendMessage("§c[Nexus] No se pudo actualizar el icono.");
            }
            showClanSettings(player, tag);
        });
}

function showSetClanPasswordForm(player, tag) {
    const clan = ClanManager.getClan(tag);
    const description = clan?.password ? "Nueva contraseña (deja vacío para quitarla):" : "Contraseña del clan (opcional):";

    new ModalFormData()
        .title("§l§dContraseña del Clan")
        .textField(description, "")
        .show(player).then(res => {
            if (res.canceled) return showClanSettings(player, tag);
            const value = normalizeClanPassword(res.formValues[0]);
            if (value && (value.length < 4 || value.length > 16)) {
                player.sendMessage("§c[Nexus] Contraseña inválida. Usa 4-16 caracteres.");
                return showClanSettings(player, tag);
            }

            if (ClanManager.setClanPassword(tag, value)) {
                const msg = value ? "Contraseña del clan actualizada." : "Contraseña del clan eliminada.";
                player.sendMessage(`§a[Nexus] ${msg}`);
            } else {
                player.sendMessage("§c[Nexus] No se pudo actualizar la contraseña.");
            }
            showClanSettings(player, tag);
        });
}

function showAllianceMenu(player, tag) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return;

    const allies = Array.isArray(clan.allies) ? clan.allies : [];
    const form = new ActionFormData()
        .title(`§l§4Gestión de Alianzas - ${tag}`)
        .body(`Aliados actuales: §e${allies.length}`);

    form.button("§l§2Proponer Alianza");
    form.button("§l§3Ver Aliados");
    form.button("§cVolver");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 2) return showActiveClanMenu(player, tag);
        if (res.selection === 0) return showProposeAlliance(player, tag);
        if (res.selection === 1) return showAlliesList(player, tag);
    });
}

function showProposeAlliance(player, tag) {
    const allClans = Database.getAllClans ? Database.getAllClans() : [];
    const others = (allClans || []).filter(c => String(c).toUpperCase() !== String(tag).toUpperCase());
    if (!others || others.length === 0) return player.sendMessage("§c[Nexus] No hay otros clanes registrados.");

    const form = new ActionFormData().title("§l§2Proponer Alianza").body("Selecciona el clan a invitar:");
    others.forEach(c => form.button(String(c)));
    form.button("§cCancelar");
    form.show(player).then(res => {
        if (res.canceled) return showAllianceMenu(player, tag);
        if (res.selection >= others.length) return showAllianceMenu(player, tag);
        const target = String(others[res.selection]);
        const targetData = ClanManager.getClan(target);
        if (!targetData || !targetData.leader) return player.sendMessage("§c[Nexus] Clan objetivo inválido.");

        // Enviar invitación al líder del clan objetivo
        try {
            const leaderName = targetData.leader;
        const inviteText = `§a[Nexus] Has recibido una invitación de alianza de §b${tag}§7.\nClan: ${tag}`;
        const online = world.getPlayers().find(p => p.name === leaderName);
        if (online) {
            online.sendMessage(inviteText);
        }
        Database.addMessageToInbox(leaderName, tag, inviteText, "alliance_invite", { fromClan: tag });
        player.sendMessage(`§a[Nexus] Invitación enviada a ${target}.`);
        } catch (e) {
            player.sendMessage("§c[Nexus] Error al enviar la invitación.");
        }

        return showAllianceMenu(player, tag);
    });
}

function showAlliesList(player, tag) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return showAllianceMenu(player, tag);
    const allies = Array.isArray(clan.allies) ? clan.allies : [];
    if (allies.length === 0) return player.sendMessage("§7Tu clan no tiene alianzas actualmente.");

    const form = new ActionFormData().title("§l§3Aliados del Clan").body("Selecciona una alianza para gestionar:");
    allies.forEach(a => form.button(String(a)));
    form.button("§cVolver");
    form.show(player).then(res => {
        if (res.canceled || res.selection === allies.length) return showAllianceMenu(player, tag);
        const selected = allies[res.selection];
        // Confirmar ruptura
        new MessageFormData()
            .title("§l§cRomper Alianza")
            .body(`¿Deseas romper la alianza con ${selected}?`)
            .button1("§aSí, romper")
            .button2("§cCancelar")
            .show(player).then(resp => {
                if (resp.canceled || resp.selection === 1) return showAllianceMenu(player, tag);
                const ok = ClanManager.removeAlliance(tag, selected);
                if (ok) {
                    player.sendMessage(`§e[Nexus] Alianza con ${selected} removida.`);
                    const other = ClanManager.getClan(selected);
                    if (other && other.leader) {
                        try {
                            const otherOnline = world.getPlayers().find(p => p.name === other.leader);
                            if (otherOnline) otherOnline.sendMessage(`§c[Nexus] Tu clan §b${selected} §7ha perdido la alianza con §c${tag}§7.`);
                        } catch (e) {}
                    }
                    // Notificar a todos los miembros de ambos clanes
                    try {
                        const notifyText = `§c[Nexus] §7La alianza entre §e${tag} §7y §e${selected} §7ha sido rota.`;
                        notifyClanMembers(tag, notifyText);
                        notifyClanMembers(selected, notifyText);
                    } catch (e) {}
                } else {
                    player.sendMessage("§c[Nexus] No se pudo remover la alianza.");
                }
                return showAllianceMenu(player, tag);
            });
    });
}

function showSetClaimLimitForm(player, tag) {
    const current = ClanManager.getClaimLimit(tag);
    new ModalFormData()
        .title("Configurar Límite de Reclamos")
        .textField("Máximo chunks permitidos para el clan:", String(current))
        .show(player).then(r => {
            if (r.canceled) return showActiveClanMenu(player, tag);
            const value = parseInt(r.formValues[0], 10);
            if (isNaN(value) || value < 0) return player.sendMessage("§c[Nexus] Límite inválido.");
            if (ClanManager.setClaimLimit(tag, value)) {
                player.sendMessage(`§a[Nexus] Límite actualizado a ${value} chunks.`);
            } else {
                player.sendMessage("§c[Nexus] No se pudo actualizar el límite.");
            }
            showActiveClanMenu(player, tag);
        });
}

function showMemberList(player, tag) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return;

    const myRole = safeGetMemberRole(player.name, clan);
    const isLeaderOrCo = myRole === "leader" || myRole === "coleader";
    const membersList = clan.members ? Object.keys(clan.members) : [];
    
    const form = new ActionFormData()
        .title("§l§3Miembros del Clan")
        .body(`Selecciona un jugador para ver detalles${isLeaderOrCo ? " o gestionarlo" : ""}.`);

    for (const member of membersList) {
        const mrole = clan.members && clan.members[member] && clan.members[member].role ? clan.members[member].role : 'member';
        form.button(`${member}\n§8Rango: §7${mrole}`);
    }

    form.show(player).then((response) => {
        if (response.canceled) return;
        const selectedMember = membersList[response.selection];
        
            if (isLeaderOrCo && selectedMember !== player.name) {
            const currentRole = clan.members && clan.members[selectedMember] && clan.members[selectedMember].role ? clan.members[selectedMember].role : 'member';
            showMemberManagement(player, selectedMember, tag, currentRole);
        } else {
            player.sendMessage(`§e[Nexus] §7Viendo perfil de §f${selectedMember}§7.`);
        }
    });
}

function showMemberManagement(player, targetName, tag, currentRole) {
    new ActionFormData()
        .title("§l§cGestión de Miembro")
        .body(`§7Jugador: §f${targetName}\n§7Rango Actual: §a${currentRole}`)
        .button("§l§2Ascender (Sublíder)")
        .button("§l§eDegradar (Miembro)")
        .button("§l§4Expulsar del Clan")
        .show(player).then((r) => {
            if (r.canceled) return;
            system.run(() => {
                if (r.selection === 0 && ClanRoles.setRole(player.name, targetName, "coleader")) {
                    player.sendMessage(`§a[Nexus] §7${targetName} ha sido ascendido.`);
                } else if (r.selection === 1 && ClanRoles.setRole(player.name, targetName, "member")) {
                    player.sendMessage(`§e[Nexus] §7${targetName} ha sido degradado.`);
                } else if (r.selection === 2) {
                    ClanManager.removeMember(targetName);
                    player.sendMessage(`§c[Nexus] §7${targetName} ha sido expulsado.`);
                    world.sendMessage(`§8[§b${tag}§8] §7${targetName} §7fue expulsado.`);
                }
            });
        });
}

function showTerritoryMenu(player, tag) {
    const chunkId = TerritoryManager.getChunkId(player.location, player.dimension.id);
    const owner = TerritoryManager.getChunkOwner(chunkId);
    
    let statusText = owner === tag ? "§2Protegido por tu Clan" : (owner ? `§cOcupado por [${owner}]` : "§aLibre");

    const claimCount = TerritoryManager.getClanClaimCount(tag);
    const claimLimit = ClanManager.getClaimLimit(tag);
    const remaining = claimLimit - claimCount;

    const form = new ActionFormData()
        .title("§l§6Territorio")
        .body(`§7Chunk:\n§f${chunkId}\n\n§7Estado: ${statusText}\n§7Reclamos: §e${claimCount}§7/§a${claimLimit} §8(Disponibles: §b${remaining}§8)`);

    if (!owner) {
        // Si no quedan espacios, mostramos opción deshabilitada en texto
        if (remaining <= 0) {
            form.button("§c§lLímite alcanzado");
            form.button("§cCerrar");
        } else {
            form.button("§l§2Reclamar Zona");
            form.button("§l§2Reclamar Radio");
            form.button("§l§2Reclamar hasta N");
        }
    }
    else if (owner === tag) {
        form.button("§l§cLiberar Zona");
        form.button("§l§eVer Reclamos del Clan");
        form.button("§l§6Establecer Base Aquí");
        form.button("§l§3Teletransportarse a la Base");
        form.button("§l§3Mostrar Radio de Base");
        form.button("§l§eDeshacer último reclamo");
        const markerLabel = isClaimMarkerEnabled(player) ? "§cOcultar Marcadores" : "§aMostrar Marcadores";
        form.button(markerLabel);
        form.button("§l§cLiberar Todo");
    }
    else form.button("§l§8Zona Enemiga");

    form.show(player).then((r) => {
        if (r.canceled) return;
        system.run(() => {
                if (!owner && remaining <= 0) {
                    return player.sendMessage("§c[Nexus] §7No te quedan reclamos disponibles.");
                }
                        if (!owner && r.selection === 0) {
                    confirmTerritoryClaim(player, chunkId, tag, "chunk");
                } else if (!owner && r.selection === 1) {
                    showClaimRadiusForm(player, tag, chunkId);
                } else if (owner === tag && r.selection === 0) {
                    TerritoryManager.unclaimChunk(chunkId, tag);
                    player.sendMessage("§e[Nexus] §7Territorio liberado.");
                } else if (!owner && r.selection === 2) {
                    // Mostrar selector para reclamar hasta N
                    showClaimUpToForm(player, tag, chunkId);
                } else if (owner === tag && r.selection === 1) {
                    // Ver reclamos (paginado)
                    showClanClaims(player, tag, 0);
                } else if (owner === tag && r.selection === 2) {
                    // Set base
                    TerritoryManager.setBaseLocation(tag, player.location);
                    player.sendMessage("§a[Nexus] §7Base establecida en tu ubicación actual.");
                    spawnBaseSetEffect(player, player.location);
                    const base = TerritoryManager.getBaseLocation(tag);
                    if (base) spawnBaseRadiusEffect(player, base, base.radius || 20);
                } else if (owner === tag && r.selection === 3) {
                    // Teleport to base
                    const base = TerritoryManager.getBaseLocation(tag);
                    if (!base) return player.sendMessage("§c[Nexus] §7Tu clan no tiene base establecida.");
                    try {
                        // saltamos validaciones y usamos comando de tp
                        const coords = `${base.x} ${base.y || player.location.y} ${base.z}`;
                        // el campo dimension queda ignorado en TP por simplicidad
                        player.runCommandAsync(`tp ${player.name} ${coords}`);
                    } catch (e) {
                        player.sendMessage("§c[Nexus] §7No se pudo teletransportar.");
                    }
                } else if (owner === tag && r.selection === 4) {
                    const base = TerritoryManager.getBaseLocation(tag);
                    if (!base) return player.sendMessage("§c[Nexus] §7Tu clan no tiene base establecida.");
                    spawnBaseRadiusEffect(player, base, base.radius || 20);
                } else if (owner === tag && r.selection === 5) {
                    undoLastClaim(player, tag);
                } else if (owner === tag && r.selection === 6) {
                    // Toggle markers
                    try { toggleClaimMarkers(player); spawnToggleEffect(player); } catch (e) {}
                    return showTerritoryMenu(player, tag);
                } else if (owner === tag && r.selection === 7) {
                    // Unclaim all
                    const claims = TerritoryManager.getClanClaims(tag);
                    if (claims && claims.length > 0) {
                        claims.forEach(c => TerritoryManager.unclaimChunk(c, tag));
                    }
                    player.sendMessage("§e[Nexus] §7Todos los territorios han sido liberados.");
            }
        });
    });
}

function showClaimRadiusForm(player, tag, centerChunkId) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return player.sendMessage("§c[Nexus] Error al obtener datos del clan.");
    const remaining = (clan.claimLimit || 10) - (clan.claims ? clan.claims.length : 0);
    if (remaining <= 0) return player.sendMessage("§c[Nexus] No te quedan reclamos disponibles.");

    const options = [1, 2, 3, 4, 5].filter(r => r > 0);
    const form = new ActionFormData()
        .title("Reclamar Radio de Chunk")
        .body(`Disponibles: ${remaining}. Selecciona el radio de reclamación alrededor del chunk:`);

    options.forEach(r => {
        const totalChunks = (2 * r + 1) * (2 * r + 1);
        form.button(`Radio ${r} (${totalChunks} chunks)`);
    });
    form.button("§cCancelar");

    form.show(player).then(res => {
        if (res.canceled) return showTerritoryMenu(player, tag);
        const sel = res.selection;
        if (sel < options.length) {
            const radius = options[sel];
            showClaimConfirmation(player, tag, `Reclamar radio ${radius} alrededor de este chunk?`, () => {
                const out = TerritoryManager.claimRadius(centerChunkId, tag, radius);
                if (out.success) {
                    const claimed = out.results.claimed.length;
                    const skipped = out.results.skipped.length;
                    if (claimed > 0) {
                        player.sendMessage(`§a[Nexus] §7Chunks reclamados: ${claimed} (omitidos: ${skipped})`);
                        spawnMultiClaimEffect(player, out.results.claimed);
                        recordLastClaim(player, tag, out.results.claimed);
                    } else {
                        player.sendMessage(`§e[Nexus] §7No se reclamó ningún chunk. (omitidos: ${skipped})`);
                    }
                } else {
                    player.sendMessage("§c[Nexus] §7No se pudo reclamar el radio.");
                }
                return showTerritoryMenu(player, tag);
            });
        } else {
            return showTerritoryMenu(player, tag);
        }
    });
}

function showInviteForm(player, tag) {
    const players = world.getPlayers().filter(p => !ClanManager.getPlayerClanTag(p.name));
    if (players.length === 0) return player.sendMessage("§c[Nexus] §7No hay jugadores disponibles.");

    const names = players.map(p => p.name);
    new ModalFormData().title("§l§9Invitar Jugador").dropdown("Selecciona:", names).show(player).then(r => {
        if (r.canceled) return;
        const target = players.find(p => p.name === names[r.formValues[0]]);
        if (target) {
            ClanInvites.sendInvite(target.name, tag);
            const inviteText = `§l⚔️ INVITACIÓN AL CLAN\n§fHas sido invitado al clan §b[${tag}]§f.\n\n§7Escribe !aceptar o /aceptar para unirte. Si el clan tiene contraseña, usa !aceptar ${tag} <contraseña> o /aceptar ${tag} <contraseña>.`;
            Database.addMessageToInbox(target.name, "SISTEMA (Clan)", inviteText, "clan_invite", { clanTag: tag });
            player.sendMessage(`§a[Nexus] §7Invitación enviada a ${target.name}.`);
            target.sendMessage(`§a[Nexus] §7Has sido invitado a §b[${tag}]§7. Usa !aceptar ${tag} <contraseña> o /aceptar ${tag} <contraseña> si aplica.`);
}

function showClanClaims(player, tag, page = 0) {
    const claims = TerritoryManager.getClanClaims(tag);
    if (!claims || claims.length === 0) return player.sendMessage("§7Tu clan no tiene reclamos.");

    const pageSize = 8;
    const totalPages = Math.ceil(claims.length / pageSize);
    const start = page * pageSize;
    const slice = claims.slice(start, start + pageSize);

    const form = new ActionFormData()
        .title(`Reclamos de ${tag} - Página ${page + 1}/${totalPages}`)
        .body(`Mostrando ${slice.length} de ${claims.length} chunks`);

    slice.forEach(c => form.button(c));
    if (page > 0) form.button("§l« Anterior");
    if (page < totalPages - 1) form.button("§lSiguiente »");
    form.button("§cVolver");

    form.show(player).then(res => {
        if (res.canceled) return showTerritoryMenu(player, tag);
        const sel = res.selection;
        if (sel < slice.length) {
            player.sendMessage(`§7Chunk: ${slice[sel]}`);
            return showClanClaims(player, tag, page);
        }
        // botones de paginación/volver
        const offset = slice.length;
        if (page > 0 && sel === offset) return showClanClaims(player, tag, page - 1);
        if (page < totalPages - 1 && sel === offset + (page > 0 ? 1 : 0)) return showClanClaims(player, tag, page + 1);
        return showTerritoryMenu(player, tag);
    });
}

function showClaimUpToForm(player, tag, centerChunkId) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return player.sendMessage("§c[Nexus] Error al obtener datos del clan.");
    const remaining = (clan.claimLimit || 10) - (clan.claims ? clan.claims.length : 0);
    if (remaining <= 0) return player.sendMessage("§c[Nexus] No te quedan reclamos disponibles.");

    // Opciones comunes: 1,5,10,20,30 pero limitadas por 'remaining'
    const options = [1, 5, 10, 20, 30].filter(n => n <= remaining);
    // Asegurar al menos la opción 1
    if (options.length === 0) options.push(1);

    const form = new ActionFormData()
        .title("Reclamar hasta N Chunks")
        .body(`Disponibles: ${remaining}. Selecciona cuántos chunks intentar reclamar alrededor de tu posición:`);

    options.forEach(n => form.button(`Reclamar ${n} chunks`));
    form.button("§cCancelar");

    form.show(player).then(res => {
        if (res.canceled) return showTerritoryMenu(player, tag);
        const sel = res.selection;
        if (sel < options.length) {
            const n = options[sel];
            showClaimConfirmation(player, tag, `Reclamar hasta ${n} chunks alrededor del chunk actual?`, () => {
                const out = TerritoryManager.claimUpTo(centerChunkId, tag, n);
                if (out.success) {
                    if (out.results.claimed.length > 0) {
                        player.sendMessage(`§a[Nexus] Chunks reclamados: ${out.results.claimed.length} (omitidos: ${out.results.skipped.length}).`);
                        spawnMultiClaimEffect(player, out.results.claimed);
                        recordLastClaim(player, tag, out.results.claimed);
                    } else {
                        player.sendMessage(`§e[Nexus] §7No se reclamó ningún chunk. (omitidos: ${out.results.skipped.length})`);
                    }
                } else if (out.reason === "limit_reached") {
                    player.sendMessage("§c[Nexus] Límite de reclamos alcanzado.");
                } else {
                    player.sendMessage("§c[Nexus] No se pudo completar la acción.");
                }
                return showTerritoryMenu(player, tag);
            });
        } else {
            return showTerritoryMenu(player, tag);
        }
    });
}

function recordLastClaim(player, tag, chunks) {
    if (!player || !Array.isArray(chunks) || chunks.length === 0) return;
    lastClaimActions.set(player.name, { clanTag: tag, chunks: chunks.slice(), timestamp: Date.now() });
}

function clearLastClaim(player) {
    if (!player) return;
    lastClaimActions.delete(player.name);
}

function undoLastClaim(player, tag) {
    const record = lastClaimActions.get(player.name);
    if (!record || record.clanTag !== tag || !record.chunks || record.chunks.length === 0) {
        player.sendMessage("§c[Nexus] No tienes reclamos recientes para deshacer.");
        return showTerritoryMenu(player, tag);
    }
    const undone = [];
    for (const chunkId of record.chunks) {
        if (TerritoryManager.unclaimChunk(chunkId, tag)) undone.push(chunkId);
    }
    if (undone.length === 0) {
        player.sendMessage("§c[Nexus] No se pudo deshacer el último reclamo.");
    } else {
        player.sendMessage(`§a[Nexus] Se deshicieron ${undone.length} chunk(s).`);
        spawnMultiClaimEffect(player, undone);
    }
    clearLastClaim(player);
    return showTerritoryMenu(player, tag);
}

function confirmTerritoryClaim(player, chunkId, tag, type = "chunk") {
    const actionText = type === "chunk" ? "reclamar este chunk" : `reclamar acción ${type}`;
    showClaimConfirmation(player, tag, `¿Deseas ${actionText}?`, () => {
        const res = TerritoryManager.claimChunk(chunkId, tag);
        if (res === "success") {
            player.sendMessage("§a[Nexus] §7Territorio asegurado.");
            spawnClaimEffect(player, chunkId);
            recordLastClaim(player, tag, [chunkId]);
        } else if (res === "limit_reached") {
            player.sendMessage(`§c[Nexus] §7Límite de territorios alcanzado. (${TerritoryManager.getClanClaimCount(tag)}/${ClanManager.getClaimLimit(tag)})`);
        } else {
            player.sendMessage("§c[Nexus] §7No se pudo reclamar el chunk.");
        }
        return showTerritoryMenu(player, tag);
    });
}

function showClaimConfirmation(player, tag, message, onConfirm) {
    new MessageFormData()
        .title("§l§6Confirmar Reclamo")
        .body(message)
        .button1("§aSí")
        .button2("§cNo")
        .show(player)
        .then(r => {
            if (r.canceled || r.selection === 1) return showTerritoryMenu(player, tag);
            onConfirm();
        });
}

function showRestoreClanBackup(player, tag) {
    new MessageFormData()
        .title("§l§eRestaurar Backup del Clan")
        .body("Esto restaurará la última copia guardada de los datos del clan. Esto puede sobrescribir miembros, reclamos y configuración. ¿Continuar?")
        .button1("§aSí, restaurar")
        .button2("§cCancelar")
        .show(player).then(r => {
            if (r.canceled || r.selection === 1) return showActiveClanMenu(player, tag);
            try {
                const key = `nexus_clan_${String(tag).toUpperCase()}`;
                const ok = Database.restoreLastBackup(key);
                if (ok) {
                    // refrescar caches
                    try { ClanManager.initCache(); } catch (e) {}
                    try { TerritoryManager.initCache(); } catch (e) {}
                    player.sendMessage("§a[Nexus] Backup restaurado correctamente. Datos recargados.");
                } else {
                    player.sendMessage("§c[Nexus] No se encontró backup previo para restaurar.");
                }
            } catch (e) {
                player.sendMessage("§c[Nexus] Error al intentar restaurar el backup.");
            }
            return showActiveClanMenu(player, tag);
        });
}

function showLeaveConfirm(player) {
    new MessageFormData()
        .title("§l§c¿Abandonar Clan?")
        .body("Perderás todos los beneficios.\n¿Estás seguro?")
        .button1("Sí, Abandonar").button2("Cancelar")
        .show(player).then(r => {
            if (r.canceled || r.selection === 0) return;
            system.run(() => {
                const res = ClanManager.removeMember(player.name);
                if (res === "is_leader") player.sendMessage("§c[Nexus] §7Eres líder. Transfiere el rol antes de salir.");
                else if (res) player.sendMessage("§e[Nexus] §7Has abandonado el clan.");
            });
        });
}

export function showClanDirectory(player, page = 0) {
    const allTags = Database.getAllClans ? Database.getAllClans() : [];
    if (!allTags || allTags.length === 0) return player.sendMessage("§e[Nexus] No hay clanes registrados.");

    const pageSize = 6;
    const totalPages = Math.max(1, Math.ceil(allTags.length / pageSize));
    page = Math.max(0, Math.min(page, totalPages - 1));
    const start = page * pageSize;
    const slice = allTags.slice(start, start + pageSize);

    const form = new ActionFormData()
        .title(`§l§9Directorio de Clanes §8- Página ${page + 1}/${totalPages}`)
        .body("Selecciona un clan para ver detalles:");

    slice.forEach(tag => {
        const clan = ClanManager.getClan(tag) || {};
        const icon = clan.icon || "⚔️";
        const isPrivate = clan.password ? true : false;
        const name = clan.name || "(Sin nombre)";
        const label = `${icon} [${tag}] ${isPrivate ? "§cPrivado" : "§aPúblico"}\n§7${name}`;
        form.button(label);
    });

    if (page > 0) form.button("§l« Anterior");
    if (page < totalPages - 1) form.button("§lSiguiente »");
    form.button("§cVolver");

    form.show(player).then(res => {
        if (res.canceled) return;
        const sel = res.selection;
        if (sel < slice.length) return showClanPreview(player, slice[sel], page);

        // botones de paginación y volver
        const offset = slice.length;
        if (page > 0 && sel === offset) return showClanDirectory(player, page - 1);
        if (page < totalPages - 1 && sel === offset + (page > 0 ? 1 : 0)) return showClanDirectory(player, page + 1);
        return showMainClanMenu(player);
    }).catch(() => {});
}

function showClanPreview(player, tag, returnPage = 0) {
    const clan = ClanManager.getClan(tag);
    if (!clan) return player.sendMessage("§c[Nexus] Clan no encontrado.");

    const memberCount = clan.members ? Object.keys(clan.members).length : 0;
    const isPrivate = clan.password ? true : false;
    const icon = clan.icon || "⚔️";

    const form = new ActionFormData()
        .title(`${icon} §l§9${clan.name || tag} §8[${tag}]`)
        .body(`§7Tag: §f${tag}\n§7Nombre: §f${clan.name || ''}\n§7Miembros: §e${memberCount}/15\n§7Tipo: ${isPrivate ? 'Privado' : 'Público'}\n§7Líder: §f${clan.leader || 'Desconocido'}`);

    form.button(isPrivate ? "§l§eSolicitar Unirse" : "§l§2Unirse al Clan");
    form.button("§l§5Ver Miembros");
    form.button("§cVolver");

    form.show(player).then(res => {
        if (res.canceled) return showClanDirectory(player, returnPage);
        if (res.selection === 0) {
            if (isPrivate) {
                // Enviar solicitud al líder (buzón)
                try {
                    Database.addMessageToInbox(clan.leader, player.name, `§a${player.name} solicita unirse al clan ${tag}`, "join_request", { from: player.name });
                    player.sendMessage("§a[Nexus] Solicitud enviada al líder del clan.");
                } catch (e) {
                    player.sendMessage("§c[Nexus] No se pudo enviar la solicitud.");
                }
                return showClanDirectory(player, returnPage);
            } else {
                // Intentar unir directamente
                system.run(() => {
                    const ok = ClanManager.addMember(player.name, tag);
                    if (ok) player.sendMessage(`§a[Nexus] Te has unido al clan §b${tag}§a.`);
                    else player.sendMessage("§c[Nexus] No se pudo unir al clan (quizá lleno o ya perteneces a otro).");
                    return showMainClanMenu(player);
                });
            }
        } else if (res.selection === 1) {
            return showMemberList(player, tag);
        } else {
            return showClanDirectory(player, returnPage);
        }
    }).catch(() => {});
}
