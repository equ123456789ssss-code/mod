import { world } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { UI_STYLE } from "./uiConfig.js";
import { showMainHub } from "./mainHub.js";
import { PrivateChat } from "../chats/privateChat.js";
import { showInboxMenu } from "./inboxMenu.js";
import { showPendingInvites } from "./pendingInvites.js";
import { showPrivacyMenu } from "./privacyMenu.js";
import { showHistoryMenu } from "./historyMenu.js";
import { showGroupMenu } from "./groupMenu.js";
import { showClanDirectory } from "./clanForms.js";
import { showAdminTerritoryPanel } from "./adminPanel.js";
import { showWarAdminPanel } from "./warAdminPanel.js";
import { showNotificationSettings } from "./notificationSettings.js";
import { Database } from "../core/database.js";
import { safeRunCommand } from "../utils/commandHelper.js";
import { toggleAllyMarker, isAllyMarkerEnabled } from "../utils/allyMarker.js";
import { showAllyRadar } from "./allyRadar.js";
import { ClanChat } from "../chats/clanChat.js";
import { GroupManager } from "../core/groupManager.js";

export function showSocialHub(player) {
    // Calculamos mensajes no leídos para el botón
    const inbox = Database.getInbox(player.name);
    const unreadCount = inbox.filter(m => !m.read).length;
    const inboxText = unreadCount > 0 
        ? `§l📥 Buzón (§e${unreadCount} nuevos§f)` 
        : "§l📥 Buzón de Entrada";

    const markerEnabled = isAllyMarkerEnabled(player);
    const markerText = markerEnabled
        ? "§c✳️ Desactivar Marcadores"
        : "§a✳️ Marcar Aliados";

    const form = new ActionFormData()
        .title(`§l✉️ NEXUS SOCIAL`)
        .body(`${UI_STYLE.color.dim}Inbox y Comunicaciones\n${UI_STYLE.divider}`)
        .button(inboxText, "textures/ui/mail_unopened")          // 0
        .button("§l🔔 Invitaciones", "textures/ui/alert")        // 1
        .button("§l👤 Mensaje Privado", "textures/ui/generic_person") // 2
        .button("§l👥 Grupo", "textures/ui/friendsIcon")
        .button("§l🛡️ Chat de Clan", "textures/ui/icon_recipe_equipment")
        .button("§l🔎 Explorar Clanes", "textures/ui/icon_recipe_equipment")
        .button("§l⚔️ Chat de Equipo", "textures/ui/friendsIcon")
        .button("§l🗺️ Radar de Aliados", "textures/ui/compass")
        .button(markerText, "textures/ui/map")
        .button("§l📜 Historial", "textures/ui/book")
        .button("§l🔒 Bloqueados", "textures/ui/lock")
        .button("§l🔔 Ajustes de Notificación", "textures/ui/alert")
        .button("§l🔧 Admin Territorio", "textures/ui/settings");
    const isAdmin = typeof player.getTags === "function" && Array.isArray(player.getTags()) && player.getTags().includes("nexus_admin");
    if (isAdmin) {
        form.button("§l⚔️ Admin Guerras", "textures/ui/sword");
    }
    form.button("§c« VOLVER AL HUB", "textures/ui/cancel");

    const actions = [
        () => showInboxMenu(player),
        () => showPendingInvites(player),
        () => openPrivateChat(player),
        () => showGroupMenu(player),
        () => openGroupChat(player, "Clan"),
        () => showClanDirectory(player, 0),
        () => openGroupChat(player, "Equipo"),
        () => showAllyRadar(player),
        () => {
            toggleAllyMarker(player);
            showSocialHub(player);
        },
        () => showHistoryMenu(player),
        () => showPrivacyMenu(player),
        () => showNotificationSettings(player),
        () => showAdminTerritoryPanel(player)
    ];
    if (isAdmin) {
        actions.push(() => showWarAdminPanel(player));
    }
    actions.push(() => showMainHub(player));

    form.show(player).then((response) => {
        if (response.canceled) return showMainHub(player);
        const handler = actions[response.selection];
        if (typeof handler === "function") handler();
    });
}

function openPrivateChat(player) {
    const onlinePlayers = world.getPlayers().filter(p => p.name !== player.name);
    if (onlinePlayers.length === 0) {
        return openPrivateOfflineChat(player);
    }

    const form = new ActionFormData()
        .title("§l👤 CHAT PRIVADO")
        .body("Selecciona un jugador en línea o envía a un nombre offline.");

    onlinePlayers.forEach(p => form.button(p.name, "textures/ui/generic_person"));
    form.button("§lEnviar a otro jugador offline", "textures/ui/arrow_right");
    form.button("§cCancelar", "textures/ui/cancel");

    form.show(player).then((response) => {
        if (response.canceled) return showSocialHub(player);

        const index = response.selection;
        if (index < onlinePlayers.length) {
            openPrivateMessageForm(player, onlinePlayers[index].name);
        } else if (index === onlinePlayers.length) {
            openPrivateOfflineChat(player);
        } else {
            showSocialHub(player);
        }
    });
}

function openPrivateOfflineChat(player) {
    const suggestions = Array.from(new Set([
        ...Database.getBookmarks(player),
        ...Database.getInbox(player).map(m => m.sender)
    ])).filter(n => n && n !== player.name);

    if (suggestions.length === 0) {
        const form = new ModalFormData()
            .title("§l👤 MENSAJE OFFLINE")
            .textField("Nombre del jugador:", "Ej: Mateo")
            .textField("Escribe tu mensaje:", "Hola...");

        form.show(player).then((response) => {
            if (response.canceled) return showSocialHub(player);

            const targetName = response.formValues[0].trim();
            const msg = response.formValues[1].trim();
            if (!targetName || !msg) return showSocialHub(player);
            sendPrivateMessage(player, targetName, msg);
        });
        return;
    }

    const form = new ActionFormData()
        .title("§l👥 CONTACTOS RECIENTES")
        .body("Selecciona un contacto o escribe otro nombre...");

    suggestions.forEach(name => form.button(name));
    form.button("§lEscribir otro nombre...");
    form.button("§cCancelar");

    form.show(player).then(res => {
        if (res.canceled) return showSocialHub(player);
        const sel = res.selection;
        if (sel < suggestions.length) {
            openPrivateMessageForm(player, suggestions[sel]);
        } else if (sel === suggestions.length) {
            // manual
            const manual = new ModalFormData()
                .title("§l👤 Enviar a...")
                .textField("Nombre del jugador:", "Ej: Mateo")
                .textField("Escribe tu mensaje:", "Hola...");
            manual.show(player).then(r => {
                if (r.canceled) return showSocialHub(player);
                const target = r.formValues[0].trim();
                const msg = r.formValues[1].trim();
                if (!target || !msg) return showSocialHub(player);
                sendPrivateMessage(player, target, msg);
            });
        } else {
            showSocialHub(player);
        }
    });
}

function openPrivateMessageForm(player, targetName) {
    const form = new ModalFormData()
        .title(`§l👤 Mensaje a ${targetName}`)
        .textField("Escribe tu mensaje:", "Hola...");

    form.show(player).then((response) => {
        if (response.canceled) return showSocialHub(player);
        const msg = response.formValues[0].trim();
        if (!msg) return showSocialHub(player);
        sendPrivateMessage(player, targetName, msg);
    });
}

function sendPrivateMessage(player, targetName, msg) {
    if (Database.isBlocked(targetName, player.name)) {
        player.sendMessage(`§c[Nexus] No puedes enviarle mensajes a ${targetName} porque te tiene bloqueado.`);
        return showSocialHub(player);
    }
    // Guardamos contacto como favorito para autocompletado futuro
    try {
        Database.addBookmark(player, targetName);
    } catch (e) {
        // no crítico
    }

    PrivateChat.sendMessage(player, targetName, msg);
    showSocialHub(player);
}

function openGroupChat(player, type) {
    const form = new ModalFormData()
        .title(`§l💬 CHAT DE ${type.toUpperCase()}`)
        .textField(`Enviar mensaje a tu ${type}:`, "Escribe aquí...");

    form.show(player).then((response) => {
        if (response.canceled) return showSocialHub(player);
        
        const msg = response.formValues[0];
        if (!msg) return showSocialHub(player);

        if (type === "Clan") {
            ClanChat.sendMessage(player, msg);
        } else {
            const members = GroupManager.getGroupMembers(player);
            if (members.length <= 1) {
                player.sendMessage(`${UI_STYLE.color.warn}[Nexus] ${UI_STYLE.color.text}No tienes un grupo activo.`);
                return showSocialHub(player);
            }

            const formattedMsg = `§7[§eGrupo§7] §f${player.name}: §f${msg}`;
            members.forEach(memberName => {
                const member = world.getPlayers().find(p => p.name === memberName);
                if (member) member.sendMessage(formattedMsg);
            });
            player.sendMessage(`${UI_STYLE.color.success}[Nexus] ${UI_STYLE.color.text}Mensaje enviado al grupo.`);
        }

        showSocialHub(player);
    });
}