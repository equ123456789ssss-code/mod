import { ActionFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import { Database } from "../core/database.js";
import { ClanManager } from "../clans/clanManager.js";
import { ClanInvites } from "../clans/clanInvites.js";
import { GroupManager } from "../core/groupManager.js";
import { UI_STYLE } from "./uiConfig.js";
import { showSocialHub } from "./socialHub.js";

const PER_PAGE = 8;

export function showPendingInvites(player, page = 0) {
    Database.cleanupInbox(player.name);
    const inbox = Database.getInbox(player.name);
    const invites = inbox
        .map((m, i) => ({ msg: m, idx: i }))
        .filter(item => item.msg && ["clan_invite", "group_invite", "alliance_invite"].includes(item.msg.type));

    if (invites.length === 0) {
        player.sendMessage(`${UI_STYLE.color.info}[Nexus] No tienes invitaciones pendientes.`);
        return showSocialHub(player);
    }

    const totalPages = Math.ceil(invites.length / PER_PAGE) || 1;
    if (page < 0) page = 0;
    if (page >= totalPages) page = totalPages - 1;

    const start = page * PER_PAGE;
    const pageItems = invites.slice(start, start + PER_PAGE);

    const form = new ActionFormData()
        .title(`§l🔔 INVITACIONES (Pág ${page + 1}/${totalPages})`)
        .body(`${UI_STYLE.color.dim}Invitaciones pendientes\n${UI_STYLE.divider}`);

    pageItems.forEach(item => {
        let t = "Invitación";
        if (item.msg.type === "clan_invite") t = "Clan";
        else if (item.msg.type === "group_invite") t = "Grupo";
        else if (item.msg.type === "alliance_invite") t = "Alianza";
        form.button(`${t}: ${item.msg.metadata?.clanTag || item.msg.metadata?.groupId || item.msg.sender}\n§8${item.msg.date}`);
    });

    if (page > 0) form.button("§l« Pág Anterior", "textures/ui/arrow_left");
    if (page < totalPages - 1) form.button("§lPág Siguiente »", "textures/ui/arrow_right");
    form.button("§c« VOLVER", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled) return showSocialHub(player);

        const selection = res.selection;
        const totalButtons = pageItems.length;
        const hasPrev = page > 0;
        const hasNext = page < totalPages - 1;

        if (selection < totalButtons) {
            const chosen = pageItems[selection];
            readInvite(player, chosen.idx, chosen.msg, page);
        } else if (hasPrev && selection === totalButtons) {
            showPendingInvites(player, page - 1);
        } else if (!hasPrev && hasNext && selection === totalButtons) {
            showPendingInvites(player, page + 1);
        } else if (hasPrev && hasNext && selection === totalButtons + 1) {
            showPendingInvites(player, page + 1);
        } else {
            showSocialHub(player);
        }
    });
}

function readInvite(player, inboxIndex, msg, page) {
    let title = `§l🔔 INVITACIÓN`;
    if (msg.type === "clan_invite") title = `§l⚔️ INVITACIÓN AL CLAN`;
    else if (msg.type === "group_invite") title = `§l👥 INVITACIÓN AL GRUPO`;
    else if (msg.type === "alliance_invite") title = `§l🤝 INVITACIÓN DE ALIANZA`;
    const body = `§7De: §f${msg.sender}\n§7Fecha: §e${msg.date}\n\n§f${msg.text}`;

    const form = new ActionFormData()
        .title(title)
        .body(body)
        .button("§aAceptar", "textures/ui/check")
        .button("§cRechazar", "textures/ui/cancel")
        .button("§l« Volver", "textures/ui/arrow_left");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 2) return showPendingInvites(player, page);

        if (res.selection === 0) {
            // Aceptar
            if (msg.type === "clan_invite") {
                const clanTag = msg.metadata?.clanTag || null;
                if (clanTag && ClanManager.addMember(player.name, clanTag)) {
                    ClanInvites.clearInvite(player.name);
                    Database.deleteMessage(player.name, inboxIndex);
                    const p = world.getPlayers().find(p => p.name === player.name);
                    if (p) {
                        p.getTags().filter(t => t.startsWith("clan:")).forEach(t => p.removeTag(t));
                        p.addTag(`clan:${clanTag}`);
                    }
                    player.sendMessage(`${UI_STYLE.color.success}[Nexus] Te has unido al clan ${clanTag}.`);
                } else {
                    player.sendMessage("§c[Nexus] No se pudo unir al clan.");
                }
            } else if (msg.type === "group_invite") {
                const groupId = msg.metadata?.groupId || null;
                if (groupId && GroupManager.joinGroup(groupId, player)) {
                    Database.deleteMessage(player.name, inboxIndex);
                    player.sendMessage(`${UI_STYLE.color.success}[Nexus] Te has unido al grupo.`);
                } else {
                    player.sendMessage("§c[Nexus] No se pudo unir al grupo.");
                }
            } else if (msg.type === "alliance_invite") {
                const fromClan = msg.metadata?.fromClan || null;
                const myClan = ClanManager.getPlayerClanTag(player.name);
                if (!myClan || !fromClan) {
                    player.sendMessage("§c[Nexus] No se pudo procesar la alianza.");
                } else if (!ClanManager.addAlliance(myClan, fromClan)) {
                    player.sendMessage("§c[Nexus] No se pudo establecer la alianza.");
                } else {
                    Database.deleteMessage(player.name, inboxIndex);
                    ClanInvites.clearInvite(player.name);
                    player.sendMessage(`${UI_STYLE.color.success}[Nexus] Alianza con ${fromClan} establecida.`);
                }
            }
        } else if (res.selection === 1) {
            // Rechazar
            Database.deleteMessage(player.name, inboxIndex);
            player.sendMessage(`${UI_STYLE.color.warn}[Nexus] Invitación rechazada.`);
        }

        showPendingInvites(player, page);
    });
}
