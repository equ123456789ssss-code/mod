import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { getAllyReport } from "../utils/allyMarker.js";
import { GroupManager } from "../core/groupManager.js";
import { Database } from "../core/database.js";
import { safeRunCommand } from "../utils/commandHelper.js";
import { showSocialHub } from "./socialHub.js";
import { UI_STYLE } from "./uiConfig.js";

// Función auxiliar para obtener información detallada de aliados
function getDetailedAllyList(player) {
    if (!player) return [];
    
    const origin = player.location;
    const MAX_DISTANCE = 120;
    
    const allies = world.getPlayers()
        .filter(other => other.name !== player.name)
        .map(other => {
            const clanA = player.getTags().find(tag => tag.startsWith("clan:"));
            const clanB = other.getTags().find(tag => tag.startsWith("clan:"));
            let allyType = null;
            
            if (clanA && clanB && clanA === clanB) {
                allyType = "clan";
            } else {
                const partyA = GroupManager.getGroupId(player);
                const partyB = GroupManager.getGroupId(other);
                if (partyA && partyB && partyA === partyB) {
                    allyType = "party";
                }
            }
            
            if (!allyType) return null;
            
            const dx = other.location.x - origin.x;
            const dz = other.location.z - origin.z;
            const distance = Math.round(Math.sqrt(dx * dx + dz * dz));
            
            if (distance > MAX_DISTANCE) return null;
            
            // Determinar dirección
            let direction = "?";
            if (Math.abs(dx) > Math.abs(dz)) {
                direction = dx > 0 ? "E" : "O";
            } else {
                direction = dz > 0 ? "S" : "N";
            }
            
            // Determinar ícono de tipo
            const typeIcon = allyType === "clan" ? "§a⚔️" : "§b🛡️";
            
            // Colorear por distancia
            let distColor = "§a";
            if (distance > 80) distColor = "§e";
            if (distance > 100) distColor = "§c";
            
            return {
                name: other.name,
                type: allyType,
                distance,
                direction,
                icon: typeIcon,
                distColor,
                location: other.location
            };
        })
        .filter(Boolean)
        .sort((a, b) => a.distance - b.distance);
    
    return allies;
}

export function showAllyRadar(player) {
    const allies = getDetailedAllyList(player);
    
    if (allies.length === 0) {
        const form = new ActionFormData()
            .title("§l🗺️ RADAR DE ALIADOS")
            .body(`${UI_STYLE.color.dim}No hay aliados cercanos en rango (120m)\n${UI_STYLE.divider}`)
            .button("« VOLVER", "textures/ui/back_button");
        
        form.show(player).then(response => {
            if (response.canceled || response.selection === 0) {
                showSocialHub(player);
            }
        });
        return;
    }
    
    // Contar por tipo
    const clanCount = allies.filter(a => a.type === "clan").length;
    const partyCount = allies.filter(a => a.type === "party").length;
    
    let bodyText = `${UI_STYLE.color.dim}═══════════════════════\n`;
    bodyText += `§a⚔️ Clan: ${clanCount} §7| §b🛡️ Party: ${partyCount}\n`;
    bodyText += `${UI_STYLE.color.dim}═══════════════════════\n\n`;
    bodyText += `${UI_STYLE.color.text}Aliados cercanos:`;
    
    const form = new ActionFormData()
        .title("§l🗺️ RADAR DE ALIADOS")
        .body(bodyText);
    
    // Agregar cada aliado como botón
    allies.forEach(ally => {
        const buttonText = `${ally.icon} ${ally.name}\n${ally.distColor}${ally.distance}m §7· ${ally.direction}`;
        form.button(buttonText, "textures/ui/generic_person");
    });
    
    form.button("« VOLVER", "textures/ui/back_button");
    
    form.show(player).then(response => {
        if (response.canceled || response.selection === allies.length) {
            showSocialHub(player);
            return;
        }
        
        if (response.selection >= 0 && response.selection < allies.length) {
            const selectedAlly = allies[response.selection];
            showAllyDetails(player, selectedAlly);
        }
    });
}

function showAllyDetails(player, ally) {
    let statusMsg = "§7Jugador en línea";
    
    // Obtener info del aliado
    const allyPlayer = world.getPlayers().find(p => p.name === ally.name);
    if (allyPlayer) {
        const health = Math.round(allyPlayer.getHealth());
        const maxHealth = Math.round(allyPlayer.getMaxHealth());
        statusMsg = `§c❤️ ${health}/${maxHealth}`;
    }
    
    let allyTypeLabel = ally.type === "clan" ? "§aClán" : "§bParty";
    
    const form = new ActionFormData()
        .title(`§l${ally.icon} ${ally.name}`)
        .body(
            `${UI_STYLE.color.dim}Tipo: ${allyTypeLabel}\n` +
            `Distancia: §e${ally.distance}m\n` +
            `Dirección: §6${ally.direction}\n` +
            `Estado: ${statusMsg}\n` +
            `${UI_STYLE.divider}`
        )
        .button("🎯 Ir a Coordenadas", "textures/ui/map_close")
        .button("💬 Enviar Mensaje", "textures/ui/mail_unopened")
        .button("« VOLVER", "textures/ui/back_button");
    
    form.show(player).then(response => {
        if (response.canceled || response.selection === 2) {
            showAllyRadar(player);
            return;
        }
        
        if (response.selection === 0) {
            // Mostrar coordenadas
            const allyPlayer = world.getPlayers().find(p => p.name === ally.name);
            if (allyPlayer) {
                const loc = allyPlayer.location;
                const coords = `X: ${Math.round(loc.x)}, Y: ${Math.round(loc.y)}, Z: ${Math.round(loc.z)}`;
                player.sendMessage(`§a[Nexus] Coordenadas de §e${ally.name}§f: §6${coords}`);
                safeRunCommand(player, "playsound random.levelup @s ~ ~ ~ 1 1.5");
            }
            showAllyDetails(player, ally);
        } else if (response.selection === 1) {
            // Enviar mensaje privado
            Database.addMessageToInbox(ally.name, player.name, "Te ha enviado una solicitud de contacto desde el Radar.");
            player.sendMessage(`§a[Nexus] Solicitud de contacto enviada a §e${ally.name}§f.`);
            safeRunCommand(player, "playsound random.levelup @s ~ ~ ~ 1 1.5");
            showAllyRadar(player);
        }
    });
}
