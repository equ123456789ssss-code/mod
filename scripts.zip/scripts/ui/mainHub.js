import { ActionFormData } from "@minecraft/server-ui";
import { UI_STYLE } from "./uiConfig.js";
import { showMainClanMenu } from "./clanForms.js";
import { showSocialHub } from "./socialHub.js";
import { showWarMenu, showWarHistory } from "./warForms.js";
import { showTeamMenu } from "../ui/teamMenu.js";
import { showBookMenu } from "./bookMenu.js";
import { ClanManager } from "../clans/clanManager.js";

export function showMainHub(player) {
    const form = new ActionFormData()
        .title(UI_STYLE.header)
        .body(`${UI_STYLE.color.dim}Sistema de Gestión Integrada\n${UI_STYLE.divider}`)
        .button("§l🛡️ CLANES\n§r§8Gestión y Territorio", "textures/ui/icon_recipe_equipment")
        .button("§l⚔️ GUERRAS\n§r§8Estado y gestión de tu clan", "textures/ui/sword")
        .button("§l§bHistorial de Guerras\n§r§8Ver resultados recientes", "textures/ui/book")
        .button("§l✉️ SOCIAL\n§r§8Inbox y Perfil", "textures/ui/mail_open_hover")
        .button("§l⚔️ EQUIPO\n§r§8Gestión Temporal", "textures/ui/friendsIcon")
        .button("§l📍 MIS LUGARES\n§r§8Coordenadas Guardadas", "textures/ui/store_home_icon");

    form.show(player).then((response) => {
        if (response.canceled) return;
        
        const actions = [
            () => showMainClanMenu(player),
            () => {
                const clanTag = ClanManager.getPlayerClanTag(player.name);
                if (!clanTag) {
                    player.sendMessage("§e[Nexus] No perteneces a ningún clan.");
                    return showMainHub(player);
                }
                return showWarMenu(player, clanTag);
            },
            () => {
                const clanTag = ClanManager.getPlayerClanTag(player.name);
                if (!clanTag) {
                    player.sendMessage("§e[Nexus] No perteneces a ningún clan.");
                    return showMainHub(player);
                }
                return showWarHistory(player, clanTag);
            },
            () => showSocialHub(player),
            () => showTeamMenu(player),
            () => showBookMenu(player)
        ];
        
        actions[response.selection]?.();
    });
}