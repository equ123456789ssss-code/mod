import { MessageFormData } from "@minecraft/server-ui";
import { Database } from "../core/database.js";
import { ClanManager } from "../clans/clanManager.js";
import { GroupManager } from "../core/groupManager.js";
import { safeRunCommand } from "../utils/commandHelper.js";

export async function notifyInvite(targetPlayer, msg) {
    if (!targetPlayer || !msg) return;
    const playerName = targetPlayer.name;

    // Preferencias del jugador
    const popup = Database.get(`nexus_notify_popup_${playerName}`, true);
    const sound = Database.get(`nexus_notify_sound_${playerName}`, true);
    const actionbar = Database.get(`nexus_notify_actionbar_${playerName}`, true);

    try {
        if (sound) safeRunCommand(targetPlayer, "playsound random.levelup @s ~ ~ ~ 1 1.2");
    } catch (e) {}

    try {
        if (actionbar) targetPlayer.onScreenDisplay.setActionBar("§aNueva invitación - abre el Buzón para gestionarla.");
    } catch (e) {}

    if (!popup) return;

    const title = msg.type === "clan_invite" ? `§l⚔️ INVITACIÓN AL CLAN` : `§l👥 INVITACIÓN AL GRUPO`;
    const body = `§7De: §f${msg.sender}\n§7Fecha: §e${msg.date}\n\n§f${msg.text}`;

    const form = new MessageFormData()
        .title(title)
        .body(body)
        .button1("§aAceptar")
        .button2("§cRechazar");

    form.show(targetPlayer).then(res => {
        // localizar índice del mensaje en inbox
        const inbox = Database.getInbox(playerName);
        const idx = inbox.findIndex(m => m && m.date === msg.date && m.sender === msg.sender && JSON.stringify(m.metadata) === JSON.stringify(msg.metadata));
        if (res.canceled || res.selection === 1) {
            if (idx !== -1) Database.deleteMessage(playerName, idx);
            return;
        }

        if (res.selection === 0) {
            if (msg.type === "clan_invite") {
                const clanTag = msg.metadata?.clanTag || null;
                if (clanTag && ClanManager.addMember(playerName, clanTag)) {
                    try {
                        const mod = await import("../clans/clanInvites.js");
                        if (mod && mod.ClanInvites && mod.ClanInvites.clearInvite) mod.ClanInvites.clearInvite(playerName);
                    } catch (e) {}
                    if (idx !== -1) Database.deleteMessage(playerName, idx);
                    targetPlayer.getTags().filter(t => t.startsWith("clan:")).forEach(t => targetPlayer.removeTag(t));
                    targetPlayer.addTag(`clan:${clanTag}`);
                    targetPlayer.sendMessage(`§a[Nexus] Te has unido al clan ${clanTag}.`);
                } else {
                    targetPlayer.sendMessage("§c[Nexus] No se pudo unir al clan.");
                }
            } else if (msg.type === "group_invite") {
                const groupId = msg.metadata?.groupId || null;
                if (groupId && GroupManager.joinGroup(groupId, targetPlayer)) {
                    if (idx !== -1) Database.deleteMessage(playerName, idx);
                    targetPlayer.sendMessage("§a[Nexus] Te has unido al grupo.");
                } else {
                    targetPlayer.sendMessage("§c[Nexus] No se pudo unir al grupo.");
                }
            }
        }
    });
}

// export default moved to end

export async function notifyNotification(targetPlayer, msg) {
    if (!targetPlayer || !msg) return;
    const playerName = targetPlayer.name;
    const popup = Database.get(`nexus_notify_popup_${playerName}`, true);
    const sound = Database.get(`nexus_notify_sound_${playerName}`, true);
    const actionbar = Database.get(`nexus_notify_actionbar_${playerName}`, true);

    try { if (sound) safeRunCommand(targetPlayer, "playsound random.levelup @s ~ ~ ~ 1 1.1"); } catch (e) {}
    try { if (actionbar) targetPlayer.onScreenDisplay.setActionBar("§aNueva notificación - abre el Buzón para verla."); } catch (e) {}

    if (!popup) return;

    const title = msg.type === "war_started" ? "§l⚔️ GUERRA INICIADA" : "§l🔔 NOTIFICACIÓN";
    const body = `§7De: §f${msg.sender}\n§7Fecha: §e${msg.date}\n\n§f${msg.text}`;

    try {
        const { MessageFormData } = await import("@minecraft/server-ui");
        const form = new MessageFormData()
            .title(title)
            .body(body)
            .button1("§aAbrir Buzón")
            .button2("§cIgnorar");

        form.show(targetPlayer).then(res => {
            if (res.canceled || res.selection === 1) return;
            // abrir buzón
            import("./inboxMenu.js").then(mod => { if (mod && mod.showInboxMenu) mod.showInboxMenu(targetPlayer); }).catch(() => {});
        });
    } catch (e) {
        // ignorar errores de UI
    }
}

export default { notifyInvite, notifyNotification };
