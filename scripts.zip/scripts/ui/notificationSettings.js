import { ActionFormData } from "@minecraft/server-ui";
import { Database } from "../core/database.js";

export function showNotificationSettings(player) {
    const playerName = player.name;
    const popup = Database.get(`nexus_notify_popup_${playerName}`, true);
    const sound = Database.get(`nexus_notify_sound_${playerName}`, true);
    const actionbar = Database.get(`nexus_notify_actionbar_${playerName}`, true);

    const form = new ActionFormData()
        .title("§l🔔 AJUSTES DE NOTIFICACIÓN")
        .body("Activa o desactiva tipos de notificación para invitaciones y alertas.")
        .button(`${popup ? "§a✔️" : "§c✖️"} Popup (Ventana)`)
        .button(`${sound ? "§a✔️" : "§c✖️"} Sonido`)
        .button(`${actionbar ? "§a✔️" : "§c✖️"} Action-Bar (Aceptar rápido)`)
        .button("§c« Volver");

    form.show(player).then(res => {
        if (res.canceled) {
            import("./socialHub.js").then(mod => {
                if (mod && mod.showSocialHub) mod.showSocialHub(player);
            }).catch(() => {});
            return;
        }
        const sel = res.selection;
        if (sel === 0) {
            Database.set(`nexus_notify_popup_${playerName}`, !popup);
            player.sendMessage(`§a[Nexus] Popup ${!popup ? "activado" : "desactivado"}.`);
            return showNotificationSettings(player);
        }
        if (sel === 1) {
            Database.set(`nexus_notify_sound_${playerName}`, !sound);
            player.sendMessage(`§a[Nexus] Sonido ${!sound ? "activado" : "desactivado"}.`);
            return showNotificationSettings(player);
        }
        if (sel === 2) {
            Database.set(`nexus_notify_actionbar_${playerName}`, !actionbar);
            player.sendMessage(`§a[Nexus] Action-Bar ${!actionbar ? "activado" : "desactivado"}.`);
            return showNotificationSettings(player);
        }
        import("./socialHub.js").then(mod => {
            if (mod && mod.showSocialHub) mod.showSocialHub(player);
        }).catch(() => {});
    });
}

export default { showNotificationSettings };
