import { ActionFormData } from "@minecraft/server-ui";
import { UI_STYLE } from "./uiConfig.js";
import { showMainHub } from "./mainHub.js";

export function showHelpMenu(player) {
    const form = new ActionFormData()
        .title("§l§9NEXUS - GUÍA DE COMANDOS")
        .body(`${UI_STYLE.color.dim}Selecciona una categoría para aprender más\n${UI_STYLE.divider}`);

    form.button("§l🛡️ Clanes", "textures/ui/icon_recipe_equipment");
    form.button("§l⚔️ Guerras", "textures/ui/sword");
    form.button("§l👥 Grupo / Equipo", "textures/ui/friendsIcon");
    form.button("§l💬 Chat", "textures/ui/chat");
    form.button("§l📍 Territorio", "textures/ui/compass");
    form.button("§l🐾 Familiares", "textures/ui/generic_creature");
    form.button("§c« VOLVER", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 6) return showMainHub(player);

        switch (res.selection) {
            case 0: return showHelpClans(player);
            case 1: return showHelpWars(player);
            case 2: return showHelpTeam(player);
            case 3: return showHelpChat(player);
            case 4: return showHelpTerritory(player);
            case 5: return showHelpFamiliars(player);
        }
    });
}

function showHelpClans(player) {
    const form = new ActionFormData()
        .title("§l§9CLANES - GUÍA")
        .body(`§7Comandos para gestionar tu clan:

§a!clan§7 o §a/clan
§8Abre el menú principal de clanes

§a!aceptar <TAG> <contraseña>§7 o §a/aceptar <TAG> <contraseña>
§8Únete a un clan (con invitación o contraseña)

§a!clan join <TAG> <contraseña>§7 o §a/clan join <TAG> <contraseña>
§8Síntesis para unirse a clan protegido

§7Características:
§f• Crear clanes con tag único
§f• Contraseña opcional para proteger
§f• Icono personalizado
§f• Sistema de alianzas
§f• Gestor de miembros

${UI_STYLE.divider}`)
        .button("« Volver", "textures/ui/arrow_left")
        .button("§c Cerrar", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 1) return showMainHub(player);
        if (res.selection === 0) return showHelpMenu(player);
    });
}

function showHelpWars(player) {
    const form = new ActionFormData()
        .title("§l§9GUERRAS - GUÍA")
        .body(`§7Sistema de guerras entre clanes:

§a!guerra§7 o §a/guerra
§8Abre el menú de guerras

§7Características:
§f• Solicitar guerras entre clanes
§f• Sistema de puntos por kills
§f• Rachas (doble, triple, mega kills)
§f• Historial de guerras
§f• Soporte para alianzas temporales

§7Puntos:
§f• Kill: +10 pts
§f• Asistencia: +5 pts
§f• Doble kill: +5 bonus
§f• Triple kill: +10 bonus
§f• Mega kill (4+): +15 bonus

${UI_STYLE.divider}`)
        .button("« Volver", "textures/ui/arrow_left")
        .button("§c Cerrar", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 1) return showMainHub(player);
        if (res.selection === 0) return showHelpMenu(player);
    });
}

function showHelpTeam(player) {
    const form = new ActionFormData()
        .title("§l§9GRUPO / EQUIPO - GUÍA")
        .body(`§7Sistemas de cooperación:

§a!grupo§7 o §a/grupo
§8Abre el menú de equipo/grupo

§7Características:
§f• Crear grupos temporales
§f• Invitar jugadores
§f• Chat de grupo
§f• Protección de daño aliado
§f• Familiar asignado al grupo

§7Diferencia:
§f• GRUPO: Equipo temporal, sin persistencia
§f• CLAN: Permanente, con territorio

${UI_STYLE.divider}`)
        .button("« Volver", "textures/ui/arrow_left")
        .button("§c Cerrar", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 1) return showMainHub(player);
        if (res.selection === 0) return showHelpMenu(player);
    });
}

function showHelpChat(player) {
    const form = new ActionFormData()
        .title("§l§9CHAT - GUÍA")
        .body(`§7Sistemas de comunicación:

§a!c <mensaje>§7 o §a/c <mensaje>
§8Chat de clan (solo miembros ven)

§a!g <mensaje>§7 o §a/g <mensaje>
§8Chat de grupo

§a!msg <jugador> <mensaje>§7 o §a/msg <jugador> <mensaje>
§8Mensaje privado a jugador

§a!r <mensaje>§7 o §a/r <mensaje>
§8Responder al último mensaje privado

§c━━ MODO SUPERVIVENCIA ━━
§7Todos los comandos funcionan en modo supervivencia.
§aUsa ! o / como prefijo en el chat.

§7Prefijos disponibles:
§f• §a!comando§7 = Funciona siempre
§f• §a/comando§7 = Alias (puede no funcionar en algunos servidores)

§7Recomendación en Supervivencia:
§aUsa §a!§7 para máxima compatibilidad

${UI_STYLE.divider}`)
        .button("« Volver", "textures/ui/arrow_left")
        .button("§c Cerrar", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 1) return showMainHub(player);
        if (res.selection === 0) return showHelpMenu(player);
    });
}

function showHelpTerritory(player) {
    const form = new ActionFormData()
        .title("§l§9TERRITORIO - GUÍA")
        .body(`§7Sistema de reclamación de chunks:

§7Comandos:
§f• §a!clan§7 → Menú Principal
§f• Opción: "Gestión de Territorio"

§7Características:
§f• Reclamar chunks individuales
§f• Reclamar en radio
§f• Establecer base del clan
§f• Protección contra construcción
§f• Marcadores visuales con partículas

§7Límite de reclamos:
§f• Configurable por administrador
§f• Mostrado en HUD de acciones

§7Partículas:
§f• Verde: Tu clan
§f• Amarillo: Aliados
§f• Rojo: Enemigos

${UI_STYLE.divider}`)
        .button("« Volver", "textures/ui/arrow_left")
        .button("§c Cerrar", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 1) return showMainHub(player);
        if (res.selection === 0) return showHelpMenu(player);
    });
}

function showHelpFamiliars(player) {
    const form = new ActionFormData()
        .title("§l§9FAMILIARES - GUÍA")
        .body(`§7Sistema de mascotas de combate:

§a!reclutar§7 o §a/reclutar
§8Abre formulario para reclutar entidad

§a!listar
§8Muestra tus familiares registrados

§a!llamar
§8Llama tus familiares a tu posición

§a!modo_guardia§7 o §a!guardia
§8Activa/desactiva modo guardia

§a!soltar
§8Libera todos tus familiares

§7Características:
§f• Registra entidades como familiares
§f• Protección de fuego aliado
§f• Modo guardia automático
§f• Límite: 15 familiares por jugador

${UI_STYLE.divider}`)
        .button("« Volver", "textures/ui/arrow_left")
        .button("§c Cerrar", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled || res.selection === 1) return showMainHub(player);
        if (res.selection === 0) return showHelpMenu(player);
    });
}

export default { showHelpMenu };
