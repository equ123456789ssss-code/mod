import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import { Database } from "../core/database.js";
import { ClanManager } from "../clans/clanManager.js";
import { WarManager } from "../war/warManager.js";
import { ClanInvites } from "../clans/clanInvites.js";
import { UI_STYLE } from "./uiConfig.js";
import { showSocialHub } from "./socialHub.js";
import { GroupManager } from "../core/groupManager.js";
import { safeRunCommand } from "../utils/commandHelper.js";

const MESSAGES_PER_PAGE = 8;

function updatePlayerClan(player, clanName) {
    player.getTags().filter(tag => tag.startsWith("clan:")).forEach(tag => player.removeTag(tag));
    if (clanName) player.addTag(`clan:${clanName}`);
}

function notifyClanMembers(clanTag, text) {
    if (!clanTag || !text) return;
    try {
        const clan = ClanManager.getClan(clanTag);
        if (!clan) return;
        let members = [];
        if (Array.isArray(clan.members)) members = clan.members.slice();
        else if (clan.members && typeof clan.members === 'object') members = Object.keys(clan.members);

        for (const name of members) {
            try {
                const p = world.getPlayers().find(pl => pl.name === name);
                if (p) p.sendMessage(text);
            } catch (e) {}
        }
    } catch (e) {}
}

function hasClanLeadership(playerName, clanTag) {
    if (!playerName || !clanTag) return false;
    const clan = ClanManager.getClan(clanTag);
    if (!clan || !clan.members || !clan.members[playerName]) return false;
    const role = clan.members[playerName].role;
    return role === "leader" || role === "coleader";
}

export function showInboxMenu(player, page = 0) {
    Database.cleanupInbox(player.name);
    const inbox = Database.getInbox(player.name);
    const totalPages = Math.ceil(inbox.length / MESSAGES_PER_PAGE) || 1;
    
    if (page < 0) page = 0;
    if (page >= totalPages) page = totalPages - 1;

    const startIndex = page * MESSAGES_PER_PAGE;
    const pageMessages = inbox.slice(startIndex, startIndex + MESSAGES_PER_PAGE);

    const form = new ActionFormData()
        .title(`§l📥 BUZÓN (Pág ${page + 1}/${totalPages})`)
        .body(`${UI_STYLE.color.dim}Total de mensajes: ${inbox.length}\n${UI_STYLE.divider}`);

    pageMessages.forEach((msg) => {
        const icon = msg.read ? "textures/ui/mail_opened" : "textures/ui/mail_unopened_hover";
        const unreadColor = msg.read ? "§7" : "§l§e";
        form.button(`${unreadColor}De: ${msg.sender}\n§r§8${msg.date}`, icon);
    });

    const hasPrev = page > 0;
    const hasNext = page < totalPages - 1;
    if (hasPrev) form.button("§l« Pág Anterior", "textures/ui/arrow_left");
    if (hasNext) form.button("§lPág Siguiente »", "textures/ui/arrow_right");
    form.button("§c« VOLVER", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled) return showSocialHub(player);

        const selection = res.selection;
        const totalButtons = pageMessages.length;
        const prevIndex = hasPrev ? totalButtons : -1;
        const nextIndex = hasPrev ? totalButtons + 1 : totalButtons;
        const backIndex = totalButtons + (hasPrev ? 1 : 0) + (hasNext ? 1 : 0);

        if (selection < totalButtons) {
            const realIndex = startIndex + selection;
            readMessage(player, realIndex, inbox[realIndex], page);
        } else if (hasPrev && selection === prevIndex) {
            showInboxMenu(player, page - 1);
        } else if (hasNext && selection === nextIndex) {
            showInboxMenu(player, page + 1);
        } else if (selection === backIndex) {
            showSocialHub(player);
        } else {
            showSocialHub(player);
        }
    });
}

function readMessage(player, index, msg, page) {
    Database.markMessageAsRead(player.name, index); 
    
    const isClanInvite = msg.type === "clan_invite" || msg.text.includes("§l⚔️ INVITACIÓN AL CLAN");
    const isGroupInvite = msg.type === "group_invite" || msg.text.includes("§l👥 INVITACIÓN AL GRUPO");
    const isAllianceInvite = msg.type === "alliance_invite" || msg.text.includes("INVITACIÓN DE ALIANZA");
    const isInvite = isClanInvite || isGroupInvite || isAllianceInvite;

    const form = new ActionFormData()
        .title(`§l✉️ MENSAJE DE: ${msg.sender}`)
        .body(`§7Fecha: §e${msg.date}\n${UI_STYLE.divider}\n\n§f${msg.text}\n\n${UI_STYLE.divider}`);

    // Botón dinámico: Aceptar si es invitación, Responder si es mensaje normal
    const isWarRequest = msg.type === "war_request" || msg.type === "ally_request";
    const isNotification = ["ally_accepted", "war_started", "request_rejected"].includes(msg.type);

    if (isWarRequest) {
        form.button("§l§2Aceptar Solicitud", "textures/ui/check");
        form.button("§l§cRechazar Solicitud", "textures/ui/cancel");
    } else if (isInvite) {
        form.button("§a§l✅ ACEPTAR INVITACIÓN", "textures/ui/check");
    } else {
        form.button("§l↪ Responder", "textures/ui/refresh");
    }

    form.button("§l🗑️ Borrar Mensaje", "textures/ui/trash");
    form.button("§l« Volver", "textures/ui/cancel");

    form.show(player).then(res => {
        if (res.canceled) return showInboxMenu(player, page);

        if (isWarRequest) {
            if (res.selection === 0 || res.selection === 1) {
                const clanTag = ClanManager.getPlayerClanTag(player.name);
                const clanData = ClanManager.getClan(clanTag);
                if (!clanTag || !clanData || !hasClanLeadership(player.name, clanTag)) {
                    player.sendMessage("§c[Nexus] Solo el líder o co-líder del clan puede gestionar solicitudes.");
                    return showInboxMenu(player, page);
                }
                const reqId = msg.metadata?.requestId;
                if (!reqId) {
                    player.sendMessage("§c[Nexus] Solicitud inválida.");
                    return showInboxMenu(player, page);
                }
                const result = res.selection === 0
                    ? WarManager.acceptWarRequest(reqId)
                    : WarManager.rejectWarRequest(reqId);
                if (!result.success) {
                    player.sendMessage(`§c[Nexus] ${result.error}`);
                } else {
                    Database.deleteMessage(player.name, index);
                    player.sendMessage(`§a[Nexus] Solicitud ${res.selection === 0 ? "aceptada" : "rechazada"}.`);
                }
                return showInboxMenu(player, page);
            }
            if (res.selection === 2) {
                Database.deleteMessage(player.name, index);
                player.sendMessage(`${UI_STYLE.color.success}[Nexus] Mensaje eliminado.`);
                return showInboxMenu(player, page);
            }
            return showInboxMenu(player, page);
        }

        if (isInvite) {
            if (res.selection === 0) {
                processInvitation(player, msg, index);
                return;
            }
            if (res.selection === 1) {
                Database.deleteMessage(player.name, index);
                player.sendMessage(`${UI_STYLE.color.success}[Nexus] Mensaje eliminado.`);
                return showInboxMenu(player, page);
            }
            return showInboxMenu(player, page);
        }

        if (isNotification) {
            if (res.selection === 0) {
                Database.deleteMessage(player.name, index);
                player.sendMessage(`${UI_STYLE.color.success}[Nexus] Notificación confirmada.`);
                return showInboxMenu(player, page);
            }
            if (res.selection === 1) {
                Database.deleteMessage(player.name, index);
                player.sendMessage(`${UI_STYLE.color.success}[Nexus] Mensaje eliminado.`);
                return showInboxMenu(player, page);
            }
            return showInboxMenu(player, page);
        }

        if (res.selection === 0) {
            openReplyForm(player, msg.sender, page);
            return;
        }
        if (res.selection === 1) {
            Database.deleteMessage(player.name, index);
            player.sendMessage(`${UI_STYLE.color.success}[Nexus] Mensaje eliminado.`);
            return showInboxMenu(player, page);
        }
        return showInboxMenu(player, page);
    });
}

function processInvitation(player, msg, index) {
    try {
        // Alliance invite
        if (msg.type === "alliance_invite" || msg.text.includes("INVITACIÓN DE ALIANZA")) {
            const fromClan = msg.metadata?.fromClan || (() => {
                const match = msg.text.match(/Clan:\s*([^\n\r]+)/i);
                return match ? match[1].trim() : null;
            })();

            const myClan = ClanManager.getPlayerClanTag(player.name);
            if (!myClan) {
                player.sendMessage("§c[Nexus] Debes pertenecer a un clan para aceptar alianzas.");
                return showInboxMenu(player);
            }

            const myClanData = ClanManager.getClan(myClan);
            if (!myClanData || !hasClanLeadership(player.name, myClan)) {
                player.sendMessage("§c[Nexus] Solo el líder o co-líder del clan puede aceptar alianzas.");
                return showInboxMenu(player);
            }

            if (!fromClan) {
                player.sendMessage("§c[Nexus] Datos de alianza inválidos.");
                return showInboxMenu(player);
            }

            const ok = ClanManager.addAlliance(myClan, fromClan);
            if (ok) {
                Database.deleteMessage(player.name, index);
                player.sendMessage(`§a[Nexus] Alianza con ${fromClan} aceptada.`);
                const other = ClanManager.getClan(fromClan);
                if (other && other.leader) {
                    try {
                        const otherOnline = world.getPlayers().find(p => p.name === other.leader);
                        if (otherOnline) otherOnline.sendMessage(`§a[Nexus] Tu clan §b${fromClan} §7ha sido aliado con §a${myClan}§7.`);
                    } catch (e) {}
                }
                try {
                    const notifyText = `§a[Nexus] §7Alianza establecida entre §e${myClan} §7y §e${fromClan}.`;
                    notifyClanMembers(myClan, notifyText);
                    notifyClanMembers(fromClan, notifyText);
                } catch (e) {}
            } else {
                player.sendMessage("§c[Nexus] No se pudo establecer la alianza.");
            }

            return showInboxMenu(player);
        }

        // Clan invite
        if (msg.type === "clan_invite" || msg.text.includes("§l⚔️ INVITACIÓN AL CLAN")) {
            const clanName = msg.metadata?.clanTag || (() => {
                const match = msg.text.match(/Clan:\s*([^\n\r]+)/i);
                return match ? match[1].trim() : null;
            })();
            const success = clanName ? ClanManager.addMember(player.name, clanName) : false;
            if (success) {
                updatePlayerClan(player, clanName);
                Database.deleteMessage(player.name, index);
                ClanInvites.clearInvite(player.name);
                player.sendMessage(`§a[Nexus] ¡Te has unido al clan §e${clanName}§a!`);
            } else {
                player.sendMessage("§c[Nexus] No se pudo unir al clan.");
            }
            return showInboxMenu(player);
        }

        // Group invite
        if (msg.type === "group_invite" || msg.text.includes("§l👥 INVITACIÓN AL GRUPO")) {
            const groupId = msg.metadata?.groupId || (() => {
                const match = msg.text.match(/ID_GRUPO:(\S+)/i);
                return match ? match[1].trim() : null;
            })();
            const success = groupId ? GroupManager.joinGroup(groupId, player) : false;
            if (success) {
                Database.deleteMessage(player.name, index);
                player.sendMessage(`§a[Nexus] ¡Te has unido al grupo exitosamente!`);
            } else {
                player.sendMessage(`§c[Nexus] El grupo ya no existe.`);
            }
            return showInboxMenu(player);
        }

    } catch (e) {
        player.sendMessage("§c[Nexus] Error crítico al procesar la invitación.");
    }
    showInboxMenu(player);
}

function openReplyForm(player, targetName, page) {
    const form = new ModalFormData()
        .title(`§l↪ RESPONDER A: ${targetName}`)
        .textField("Tu respuesta:", "Escribe aquí...");

    form.show(player).then(res => {
        if (res.canceled) return showInboxMenu(player, page);
        const msg = res.formValues[0]?.trim();
        if (!msg) return showInboxMenu(player, page);

        const targetOnline = world.getPlayers().find(p => p.name.toLowerCase() === targetName.toLowerCase());
        if (targetOnline) {
            targetOnline.onScreenDisplay.setTitle("§l§e✉️ NUEVA RESPUESTA", {
                subtitle: `De: ${player.name}`,
                fadeInDuration: 10, stayDuration: 60, fadeOutDuration: 10
            });
            safeRunCommand(targetOnline, "playsound random.orb @s ~ ~ ~ 1 1");
        }

        Database.addMessageToInbox(targetName, player.name, msg);
        player.sendMessage(`§a[Nexus] §7Respuesta enviada a §e${targetName}§f.`);
        showInboxMenu(player, page);
    });
}