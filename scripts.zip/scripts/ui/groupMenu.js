import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import { GroupManager } from "../core/groupManager.js";
import { Database } from "../core/database.js";

export function showGroupMenu(player) {
    const isInGroup = GroupManager.isPlayerInGroup(player);
    const form = new ActionFormData()
        .title("§l👥 GESTIÓN DE GRUPOS")
        .body(isInGroup ? "§7Estás en un grupo activo." : "§7No perteneces a ningún grupo.");

    if (!isInGroup) {
        form.button("§l➕ Crear Grupo Nuevo", "textures/ui/color_plus");
    } else {
        form.button("§l👀 Ver Miembros", "textures/ui/friend_glyph_centered");
        form.button("§l✉️ Invitar Jugador", "textures/ui/mail_unopened_hover");
        form.button("§l🚪 Salir del Grupo", "textures/ui/cancel");
    }
    form.button("§l« Volver", "textures/ui/arrow_left");

    form.show(player).then(res => {
        if (res.canceled) return;

        if (!isInGroup) {
            if (res.selection === 0) {
                GroupManager.createGroup(player);
                player.sendMessage("§a[Nexus] Grupo creado.");
                showGroupMenu(player);
            }
            return;
        }

        handleGroupActions(player, res.selection);
    });
}

function handleGroupActions(player, selection) {
    switch (selection) {
        case 0: {
            const members = GroupManager.getGroupMembers(player);
            player.sendMessage(`§a[Nexus] Miembros del grupo: §f${members.join(", ")}`);
            break;
        }
        case 1: {
            const form = new ModalFormData()
                .title("§l📩 INVITAR JUGADOR")
                .textField("Nombre del jugador:", "Ej: Mateo");

            form.show(player).then(res => {
                if (res.canceled) return;

                const targetName = res.formValues[0].trim();
                if (!targetName) return;
                if (targetName.toLowerCase() === player.name.toLowerCase()) {
                    player.sendMessage("§c[Nexus] No puedes invitarte a ti mismo.");
                    return;
                }

                const target = world.getPlayers().find(p => p.name.toLowerCase() === targetName.toLowerCase());
                if (!target) {
                    player.sendMessage("§c[Nexus] Ese jugador no está conectado.");
                    return;
                }

                const groupId = GroupManager.getGroupId(player);
                const inviteText = `§l👥 INVITACIÓN AL GRUPO\n§fDe: ${player.name}\n§7ID_GRUPO: ${groupId}\n\n§eEscribe !aceptar o /aceptar para unirte.`;
                Database.addMessageToInbox(target.name, "SISTEMA (Grupo)", inviteText, "group_invite", { groupId });
                player.sendMessage(`§a[Nexus] Invitación enviada a ${target.name}.`);
            });
            break;
        }
        case 2:
            GroupManager.leaveGroup(player);
            player.sendMessage("§c[Nexus] Has abandonado el grupo.");
            showGroupMenu(player);
            break;
    }
}