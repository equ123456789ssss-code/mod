import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { world, system } from "@minecraft/server";
import { WarConfig } from "../war/warConfig.js";
import { WarManager } from "../war/warManager.js";

function isAdmin(player) {
    if (!player || typeof player.getTags !== "function") return false;
    return Array.isArray(player.getTags()) && player.getTags().includes("nexus_admin");
}

function getConfigOptions() {
    const config = WarConfig.getConfig();
    return [
        { key: "WINNING_POINTS", title: "Puntos para ganar", value: config.WINNING_POINTS, min: 1, max: 100 },
        { key: "MAX_DURATION_MINUTES", title: "Duración máxima (min)", value: config.MAX_DURATION_MINUTES, min: 5, max: 10080 },
        { key: "KILL_POINTS", title: "Puntos por matar", value: config.KILL_POINTS, min: 0.1, max: 10 },
        { key: "ASSIST_POINTS", title: "Puntos por asistencia", value: config.ASSIST_POINTS, min: 0, max: 5 },
        { key: "STREAK_2_BONUS", title: "Bonus racha 2x", value: config.STREAK_2_BONUS, min: 0, max: 20 },
        { key: "STREAK_3_BONUS", title: "Bonus racha 3x", value: config.STREAK_3_BONUS, min: 0, max: 20 },
        { key: "STREAK_4_PLUS_BONUS", title: "Bonus racha 4x+", value: config.STREAK_4_PLUS_BONUS, min: 0, max: 20 }
    ];
}

function getWarConfigBody() {
    const config = WarConfig.getConfig();
    const durationHours = Math.floor(config.MAX_DURATION_MINUTES / 60);
    const durationMins = config.MAX_DURATION_MINUTES % 60;
    return `Estado: ${config.ENABLED ? "Habilitado" : "Deshabilitado"}\n` +
        `Puntos para ganar: ${config.WINNING_POINTS}\n` +
        `Duración máxima: ${durationHours}h ${durationMins}m\n` +
        `Kill: ${config.KILL_POINTS}\n` +
        `Asistencia: ${config.ASSIST_POINTS}\n` +
        `Racha 2x: +${config.STREAK_2_BONUS}\n` +
        `Racha 3x: +${config.STREAK_3_BONUS}\n` +
        `Racha 4x+: +${config.STREAK_4_PLUS_BONUS}`;
}

export function showWarAdminPanel(player) {
    if (!isAdmin(player)) return player.sendMessage("§c[Nexus] No tienes permisos de administrador para gestionar guerras.");

    const form = new ActionFormData()
        .title("§l§cAdmin - Guerras")
        .body("Administra la configuración y revisa estado de guerras. No puedes editar en plena guerra activa.")
        .button("§l§2Ver configuración actual")
        .button("§l§6Editar configuración")
        .button("§l§eEstado de guerras activas")
        .button("§l§cRestablecer config a valores por defecto")
        .button("§cCerrar");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return;
        if (res.selection === 0) return showWarConfig(player);
        if (res.selection === 1) return showWarConfigEditor(player);
        if (res.selection === 2) return showWarStatus(player);
        if (res.selection === 3) return resetWarConfig(player);
    }).catch(() => {});
}

function showWarConfig(player) {
    const body = getWarConfigBody();
    new ActionFormData()
        .title("§l§2Configuración de Guerras")
        .body(body)
        .button("§l§eEditar configuración")
        .button("§cVolver")
        .show(player).then((res) => {
            if (res.canceled || res.selection === undefined) return showWarAdminPanel(player);
            if (res.selection === 0) return showWarConfigEditor(player);
            showWarAdminPanel(player);
        }).catch(() => showWarAdminPanel(player));
}

function showWarConfigEditor(player) {
    const options = getConfigOptions();
    const form = new ActionFormData()
        .title("§l§6Editar Configuración de Guerras")
        .body("Selecciona la opción que deseas cambiar:");
    options.forEach(option => form.button(`§l${option.title}\n§7Actual: ${option.value}`));
    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return showWarAdminPanel(player);
        if (res.selection >= options.length) return showWarAdminPanel(player);
        showWarConfigOptionEditor(player, options[res.selection]);
    }).catch(() => showWarAdminPanel(player));
}

function showWarConfigOptionEditor(player, option) {
    const form = new ModalFormData()
        .title(`§l§2Editar ${option.title}`)
        .textField(`Nuevo valor para ${option.title}:`, String(option.value));
    form.show(player).then((res) => {
        if (res.canceled || !res.formValues) return showWarAdminPanel(player);
        const value = res.formValues[0]?.trim();
        if (value === "") return showWarAdminPanel(player);
        const result = WarConfig.updateConfig(option.key, value);
        if (!result.success) {
            player.sendMessage(`§c[Nexus] ${result.error}`);
            return showWarAdminPanel(player);
        }
        player.sendMessage(`§a[Nexus] ${option.title} actualizado a ${value}.`);
        world.getPlayers().forEach(p => {
            if (Array.isArray(p.getTags()) && p.getTags().includes("nexus_admin")) {
                p.sendMessage(`§6[Nexus Admin] ${player.name} cambió ${option.title} a ${value}`);
            }
        });
        showWarAdminPanel(player);
    }).catch(() => showWarAdminPanel(player));
}

function showWarStatus(player) {
    const activeWars = WarManager.getActiveWars();
    if (!Array.isArray(activeWars) || activeWars.length === 0) {
        player.sendMessage("§a[Nexus] No hay guerras activas.");
        return showWarAdminPanel(player);
    }

    const form = new ActionFormData()
        .title("§l§eGuerras Activas")
        .body("Selecciona una guerra para ver su estado:");
    activeWars.forEach(war => {
        const scoreText = war.clans.map(c => `${c}:${war.score?.[c] || 0}`).join(" vs ");
        form.button(`§l${war.id}\n§7${scoreText}`);
    });
    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return showWarAdminPanel(player);
        if (res.selection >= activeWars.length) return showWarAdminPanel(player);
        const war = activeWars[res.selection];
        showActiveWarDetails(player, war);
    }).catch(() => showWarAdminPanel(player));
}

function showActiveWarDetails(player, war) {
    const scoreText = war.clans.map(c => `${c}:${war.score?.[c] || 0}`).join(" | ");
    const form = new ActionFormData()
        .title(`§l§4Guerra Activa - ${war.id}`)
        .body(`Participantes: ${war.clans.join(", ")}\nPuntaje: ${scoreText}\nIniciada: ${new Date(war.startedAt).toLocaleString()}`)
        .button("§l§cForzar finalización de guerra")
        .button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return showWarAdminPanel(player);
        if (res.selection === 0) {
            const result = WarManager.endWarWithAutoResult(war.id);
            if (!result.success) {
                player.sendMessage(`§c[Nexus] ${result.error}`);
                return showWarAdminPanel(player);
            }
            if (result.tie) {
                player.sendMessage(`§e[Nexus] Guerra ${war.id} finalizada en empate.`);
            } else {
                player.sendMessage(`§a[Nexus] Guerra ${war.id} finalizada. Ganador: ${result.winner}.`);
            }
            return showWarAdminPanel(player);
        }
        showWarAdminPanel(player);
    }).catch(() => showWarAdminPanel(player));
}

function resetWarConfig(player) {
    const result = WarConfig.resetConfig();
    if (!result.success) {
        player.sendMessage(`§c[Nexus] ${result.error}`);
        return showWarAdminPanel(player);
    }
    player.sendMessage("§a[Nexus] Configuración de guerras restablecida a valores por defecto.");
    world.getPlayers().forEach(p => {
        if (Array.isArray(p.getTags()) && p.getTags().includes("nexus_admin")) {
            p.sendMessage(`§6[Nexus Admin] ${player.name} reseteó la configuración de guerras.`);
        }
    });
    showWarAdminPanel(player);
}

export default { showWarAdminPanel };