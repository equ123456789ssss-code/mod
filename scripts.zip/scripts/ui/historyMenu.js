import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { Database } from "../core/database.js";
import { UI_STYLE } from "./uiConfig.js";
import { showSocialHub } from "./socialHub.js";

export function showHistoryMenu(player) {
    const history = Database.getHistory(player.name, 50);

    const form = new ActionFormData()
        .title("§l📜 HISTORIAL NEXUS")
        .body(`${UI_STYLE.color.dim}Últimas acciones y mensajes\n${UI_STYLE.divider}`);

    if (!history || history.length === 0) {
        form.body("§7No hay historial disponible.");
    } else {
        history.forEach((h) => {
            const label = h.type ? `${h.type}` : "evento";
            const who = h.sender ? ` ${h.sender}` : "";
            const when = h.date ? ` - ${new Date(h.date).toLocaleString()}` : "";
            form.button(`§r${label}${who}${when}`);
        });
    }

    form.button("§lBorrar Historial", "textures/ui/trash")
        .button("§c« VOLVER", "textures/ui/arrow_left");

    form.show(player).then(res => {
        if (res.canceled) return showSocialHub(player);

        const sel = res.selection;
        if (!history || history.length === 0) {
            // solo opciones: borrar o volver
            if (sel === 0) {
                Database.clearHistory(player.name);
                player.sendMessage("§a[Nexus] Historial borrado.");
            }
            return showHistoryMenu(player);
        }

        if (sel < history.length) {
            const item = history[sel];
            const modal = new ModalFormData()
                .title("Detalle del evento")
                .textField("Resumen:", JSON.stringify({
                    type: item.type,
                    sender: item.sender,
                    target: item.target,
                    metadata: item.metadata
                }))
                .textField("Contenido/Texto:", item.text || "");

            modal.show(player).then(() => showHistoryMenu(player));
            return;
        }

        // Si seleccionó borrar (posición history.length)
        if (sel === history.length) {
            Database.clearHistory(player.name);
            player.sendMessage("§a[Nexus] Historial borrado.");
            return showHistoryMenu(player);
        }

        // volver
        return showSocialHub(player);
    });
}
