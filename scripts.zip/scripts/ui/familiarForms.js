import { MessageFormData } from "@minecraft/server-ui";
import { system } from "@minecraft/server";
import { FamiliarManager } from "../familiars/familiarManager.js";

export function showRecruitConfirm(player) {
    if (!player) return;
    new MessageFormData()
        .title("§l§2Reclutar Familiar")
        .body("¿Deseas intentar reclutar al mob más cercano (rango 6)?\nNota: algunos mobs no son reclutables.")
        .button1("§aSí, reclutar")
        .button2("§cNo, cancelar")
        .show(player)
        .then(r => {
            if (r.canceled || r.selection === 1) return;
            system.run(() => {
                try {
                    const res = FamiliarManager.recruitNearest(player, 6);
                    if (!res) return player.sendMessage("§c[Nexus] No se pudo reclutar.");
                    if (typeof res === "string") return player.sendMessage(`§c[Nexus] ${res}`);
                    if (res.success) {
                        player.sendMessage(`§a[Nexus] Familiar reclutado: ${res.entityType || res.entityId}`);
                    } else {
                        player.sendMessage("§c[Nexus] No se pudo reclutar.");
                    }
                } catch (e) {
                    player.sendMessage("§c[Nexus] Error al intentar reclutar.");
                }
            });
        }).catch(() => {});
}

export default { showRecruitConfirm };
