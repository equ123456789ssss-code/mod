// scripts/ui/bookMenu.js
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { UI_STYLE } from "./uiConfig.js";
import { showMainHub } from "./mainHub.js";
import { Database } from "../core/database.js";
import { Config } from "../config.js";

export function showBookMenu(player) {
    // Ahora pasamos 'player' entero a la base de datos
    let bookmarks = Database.getBookmarks(player);

    const form = new ActionFormData()
        .title(`§l📍 MIS LUGARES`)
        .body(`${UI_STYLE.color.dim}Tus ubicaciones guardadas:\n${UI_STYLE.divider}`)
        .button("§l➕ Guardar Ubicación Actual", "textures/ui/color_plus");

    // Generar botones dinámicos según lo guardado
    bookmarks.forEach(mark => {
        form.button(`§l📌 ${mark.name}\n§r§8X:${mark.x} Y:${mark.y} Z:${mark.z}`);
    });

    form.button("§c« VOLVER AL HUB", "textures/ui/cancel");

    form.show(player).then((response) => {
        if (response.canceled) return showMainHub(player);
        
        if (response.selection === 0) {
            saveNewBookmark(player);
        } else if (response.selection === bookmarks.length + 1) {
            showMainHub(player);
        } else {
            const selected = bookmarks[response.selection - 1];
            player.sendMessage(`${UI_STYLE.color.success}[Nexus] ${UI_STYLE.color.text}Teletransportándose a §e${selected.name}...`);
            player.teleport({ x: selected.x, y: selected.y, z: selected.z });
        }
    });
}

function saveNewBookmark(player) {
    const form = new ModalFormData()
        .title("§l➕ NUEVO LUGAR")
        .textField("Nombre de la ubicación:", "Ej: Casa Base");

    form.show(player).then((response) => {
        if (response.canceled) return showBookMenu(player);
        
        const name = response.formValues[0]?.trim();
        if (!name) return showBookMenu(player);

        const bookmarks = Database.getBookmarks(player);
        if (bookmarks.length >= Config.BOOKMARK_LIMIT) {
            player.sendMessage("§c[Nexus] Has alcanzado el límite de lugares guardados.");
            return showBookMenu(player);
        }

        const pos = player.location;
        const newMark = {
            name: name,
            x: Math.floor(pos.x),
            y: Math.floor(pos.y),
            z: Math.floor(pos.z)
        };

        Database.addBookmark(player, newMark);
        player.sendMessage(`${UI_STYLE.color.success}[Nexus] §fUbicación §e${name} §fguardada.`);
        showBookMenu(player);
    });
}