import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { UI_STYLE } from "./uiConfig.js";
import { showMainHub } from "./mainHub.js";
import { GroupManager } from "../core/groupManager.js";
import { Database } from "../core/database.js";
import { world } from "@minecraft/server";

export function showTeamMenu(player) {
    const isInGroup = GroupManager.isPlayerInGroup(player);
    const members = GroupManager.getGroupMembers(player);

    const groupData = isInGroup ? GroupManager.getGroupData(player) : null;
    const memberRoles = isInGroup && groupData ? members.map(name => `§f${name} §7(${GroupManager.getGroupMemberRole(name) || "member"})`) : [];
    const canManageRoles = isInGroup && GroupManager.hasGroupPermission(player.name, "coleader");

    const form = new ActionFormData()
        .title(`§l⚔️ GESTIÓN DE EQUIPO`)
        .body(`${UI_STYLE.color.dim}Estado: ${isInGroup ? "§aDentro de un Grupo" : "§7Sin Grupo"}\n${isInGroup ? `§7Miembros (${members.length}): §f${memberRoles.join(", ")}` : ""}\n${UI_STYLE.divider}`)
        .button(isInGroup ? "§l➕ Invitar a un Jugador" : "§l➕ Crear Grupo", "textures/ui/color_plus");

    if (isInGroup && canManageRoles) {
        form.button("§l⚙️ Gestionar Roles");
    }

    if (isInGroup) {
        form.button("§l🏃 Abandonar Grupo", "textures/ui/icon_trash");
    }

    form.button("§c« VOLVER AL HUB", "textures/ui/cancel");

    form.show(player).then((response) => {
        if (response.canceled) return showMainHub(player);

        if (!isInGroup) {
            if (response.selection === 0) {
                GroupManager.createGroup(player);
                player.sendMessage(`§a[Nexus] ¡Grupo creado exitosamente!`);
                showTeamMenu(player);
            } else {
                showMainHub(player);
            }
            return;
        }

        if (response.selection === 0) {
            inviteTeamMember(player);
            return;
        }

        const leaveIndex = canManageRoles ? 2 : 1;
        const manageIndex = canManageRoles ? 1 : -1;

        if (manageIndex !== -1 && response.selection === manageIndex) {
            return showGroupMembers(player);
        }

        if (response.selection === leaveIndex) {
            return confirmLeaveGroup(player);
        }

        showMainHub(player);
    });
}

// Función de confirmación para no salir por error
function confirmLeaveGroup(player) {
    const form = new ActionFormData()
        .title("§l⚠️ ¿ABANDONAR?")
        .body("¿Estás seguro de que deseas salir del grupo?\n§7Si eres el único, el grupo se eliminará.")
        .button("§cSí, abandonar")
        .button("§7No, cancelar");

    form.show(player).then(res => {
        if (res.selection === 0) {
            GroupManager.leaveGroup(player);
            player.sendMessage(`${UI_STYLE.color.warn}[Nexus] ${UI_STYLE.color.text}Has abandonado el grupo.`);
        }
        showTeamMenu(player);
    });
}

function inviteTeamMember(player) {
    const form = new ModalFormData()
        .title("§l⚔️ NUEVO INTEGRANTE")
        .textField("Nombre del jugador a invitar:", "Ej: Tomás");

    form.show(player).then((response) => {
        if (response.canceled) return showTeamMenu(player);
        
        const targetName = response.formValues[0].trim();
        if (!targetName) return showTeamMenu(player);

        // Validación 1: No invitarse a uno mismo
        if (targetName.toLowerCase() === player.name.toLowerCase()) {
            player.sendMessage("§c[Nexus] ¡No puedes invitarte a ti mismo!");
            return showTeamMenu(player);
        }

        // Validación 2: Jugador online
        const targetPlayer = world.getPlayers().find(p => p.name.toLowerCase() === targetName.toLowerCase());
        if (!targetPlayer) {
            player.sendMessage("§c[Nexus] Ese jugador no está conectado.");
            return showTeamMenu(player);
        }

        // Envío al buzón
        const groupId = GroupManager.getGroupId(player);
        const inviteText = `§l👥 INVITACIÓN AL GRUPO\nEl jugador §e${player.name} §fte invita a su grupo.\n\nID_GRUPO:${groupId}\n\n§7Escribe !aceptar o /aceptar para unirte.`;
        
        Database.addMessageToInbox(targetName, player.name, inviteText, "group_invite", { groupId });
        player.sendMessage(`${UI_STYLE.color.success}[Nexus] Invitación enviada a §e${targetName}§f.`);
    });
}

function showGroupMembers(player) {
    const groupData = GroupManager.getGroupData(player);
    if (!groupData) return showTeamMenu(player);

    const members = Array.isArray(groupData.members) ? groupData.members : [];
    const isLeaderOrCo = GroupManager.hasGroupPermission(player.name, "coleader");

    const form = new ActionFormData()
        .title("§l👥 Miembros del Grupo")
        .body(`Selecciona un miembro para ver su rango${isLeaderOrCo ? " o gestionarlo" : ""}:`);

    members.forEach(name => {
        const role = GroupManager.getGroupMemberRole(name) || "member";
        form.button(`§l${name} §7(${role})`);
    });
    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return showTeamMenu(player);
        if (res.selection >= members.length) return showTeamMenu(player);

        const selectedMember = members[res.selection];
        if (!selectedMember) return showTeamMenu(player);

        if (!isLeaderOrCo || selectedMember === player.name) {
            return showTeamMenu(player);
        }

        showManageGroupMember(player, selectedMember);
    });
}

function showManageGroupMember(player, targetName) {
    const currentRole = GroupManager.getGroupMemberRole(targetName) || "member";
    const form = new ActionFormData()
        .title(`§l⚙️ Gestionar ${targetName}`)
        .body(`Rol actual: §e${currentRole}\nSelecciona el nuevo rol:`);

    const roles = ["coleader", "moderator", "member"];
    const available = roles.filter(role => role !== currentRole);
    available.forEach(role => {
        const label = role === "coleader" ? "Coleader" : role === "moderator" ? "Moderator" : "Miembro";
        form.button(`§l${label}`);
    });
    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return showGroupMembers(player);
        if (res.selection >= available.length) return showGroupMembers(player);

        const selectedRole = available[res.selection];
        const success = GroupManager.setGroupRole(player.name, targetName, selectedRole);
        if (!success) {
            player.sendMessage("§c[Nexus] No se pudo cambiar el rol.");
            return showGroupMembers(player);
        }

        player.sendMessage(`§a[Nexus] Rol de ${targetName} actualizado a §e${selectedRole}.`);
        showGroupMembers(player);
    });
}
