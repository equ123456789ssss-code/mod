import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { world } from "@minecraft/server";
import { ClanManager } from "../clans/clanManager.js";
import { Database } from "../core/database.js";
import { WarManager } from "../war/warManager.js";
import { WarConfig } from "../war/warConfig.js";

function sendClanMessage(clanTag, text) {
    if (!clanTag || !text) return;
    const clan = ClanManager.getClan(clanTag);
    if (!clan || !clan.members) return;
    const players = Array.isArray(clan.members) ? clan.members : Object.keys(clan.members);
    for (const playerName of players) {
        try {
            const player = world.getPlayers().find(p => p.name === playerName);
            if (player) player.sendMessage(text);
        } catch (e) {}
    }
}

function sendClansMessage(clans, text) {
    if (!Array.isArray(clans) || !text) return;
    for (const clanTag of clans) {
        sendClanMessage(clanTag, text);
    }
}

function normalizeClanTag(tag) {
    if (!tag && tag !== 0) return null;
    const str = String(tag).trim();
    if (!str) return null;
    const normalized = str.toUpperCase();
    return normalized || null;
}

function safeGetMemberRole(playerName, clan) {
    if (!playerName || !clan || !clan.members) return null;
    try {
        const m = clan.members[playerName] || clan.members[String(playerName).toLowerCase()] || clan.members[String(playerName).toUpperCase()];
        return m && m.role ? m.role : null;
    } catch (e) {
        return null;
    }
}

function isWarAdmin(player) {
    if (!player || typeof player.getTags !== "function") return false;
    return Array.isArray(player.getTags()) && player.getTags().includes("nexus_admin");
}

function getWarConfigOptions() {
    const config = WarConfig.getConfig();
    return [
        { key: "WINNING_POINTS", label: "Puntos para ganar", value: config.WINNING_POINTS, min: 1, max: 100 },
        { key: "MAX_DURATION_MINUTES", label: "Duración máxima (min)", value: config.MAX_DURATION_MINUTES, min: 5, max: 10080 },
        { key: "KILL_POINTS", label: "Puntos por matar", value: config.KILL_POINTS, min: 0.1, max: 10 },
        { key: "ASSIST_POINTS", label: "Puntos por asistencia", value: config.ASSIST_POINTS, min: 0, max: 5 },
        { key: "STREAK_2_BONUS", label: "Bonus racha 2x", value: config.STREAK_2_BONUS, min: 0, max: 20 },
        { key: "STREAK_3_BONUS", label: "Bonus racha 3x", value: config.STREAK_3_BONUS, min: 0, max: 20 },
        { key: "STREAK_4_PLUS_BONUS", label: "Bonus racha 4x+", value: config.STREAK_4_PLUS_BONUS, min: 0, max: 20 }
    ];
}

function isValidWar(war) {
    return war && typeof war === "object" && Array.isArray(war.clans) && war.clans.length >= 2 && typeof war.id === "string";
}

function getAvailableWarTargets(clanTag) {
    const normalized = normalizeClanTag(clanTag);
    if (!normalized) return [];
    const allClans = ClanManager.getAllClans() || [];
    return allClans
        .map(tag => normalizeClanTag(tag))
        .filter(tag => tag && tag !== normalized)
        .filter(tag => ClanManager.getClan(tag))
        .filter(tag => !WarManager.getWarBetween(normalized, tag));
}

function clearWarRequestInboxMessage(player, requestId) {
    if (!player || !requestId) return;
    try {
        const found = Database.findInboxMessage(player.name, msg => msg && msg.metadata && msg.metadata.requestId === requestId);
        if (found) Database.deleteMessage(player.name, found.index);
    } catch (e) {
        // ignore on cleanup failure
    }
}

function getAvailableAllies(clanTag, war) {
    const normalized = normalizeClanTag(clanTag);
    if (!normalized || !isValidWar(war)) return [];
    const allies = ClanManager.getAllies(normalized) || [];
    const existing = Array.isArray(war.clans) ? war.clans.map(c => normalizeClanTag(c)) : [];
    const pendingAllyTargets = WarManager.getOutgoingRequestsForClan(normalized)
        .filter(req => req.type === "ally" && req.warId === war.id)
        .map(req => normalizeClanTag(req.toClan));

    return allies
        .map(a => normalizeClanTag(a))
        .filter(a => a && !existing.includes(a) && !pendingAllyTargets.includes(a));
}

function formatRequestLabel(req) {
    const t = req.type === "ally" ? "ayuda" : "guerra";
    const extra = req.type === "ally" && req.warId ? ` (${req.warId})` : "";
    return `${req.fromClan} → ${req.toClan} [${t}]${extra}`;
}

export function showWarMenu(player, clanTag) {
    const normalizedClanTag = normalizeClanTag(clanTag);
    if (!player || !normalizedClanTag) return;
    const clan = ClanManager.getClan(normalizedClanTag);
    if (!clan) return player.sendMessage("§c[Nexus] Clan no encontrado.");
    const role = safeGetMemberRole(player.name, clan);
    const isLeader = role === "leader" || role === "coleader";

    const pendingCount = WarManager.getPendingRequestsForClan(normalizedClanTag).length;
    const activeCount = WarManager.getWarsForClan(normalizedClanTag).length;
    const bodyLines = [
        "Selecciona una opción para administrar o ver las guerras de tu clan.",
        `§7Solicitudes pendientes: §e${pendingCount}`,
        `§7Guerras activas: §e${activeCount}`
    ];

    const form = new ActionFormData()
        .title(`§l§4Gestión de Guerras - ${normalizedClanTag}`)
        .body(bodyLines.join("\n"));

    if (isLeader) {
        form.button("§l§2Proponer Guerra");
        form.button("§l§3Ver solicitudes entrantes");
        form.button("§l§6Ver solicitudes salientes");
    }
    form.button("§l§eGuerras activas");
    form.button("§l§bHistorial de guerras");
    form.button("§cCerrar");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return;
        const selection = res.selection;
        let offset = 0;
        if (isLeader) {
            if (selection === offset) return showProposeWarForm(player, clanTag);
            offset += 1;
            if (selection === offset) return showWarRequests(player, clanTag);
            offset += 1;
            if (selection === offset) return showOutgoingWarRequests(player, clanTag);
            offset += 1;
        }
        if (selection === offset) return showActiveWars(player, clanTag);
        offset += 1;
        if (selection === offset) return showWarHistory(player, clanTag);
        offset += 1;
        player.sendMessage("§e[Nexus] Cerrando el menú de guerras.");
        return;
    }).catch(() => {});
}

function showProposeWarForm(player, clanTag) {
    const normalizedClanTag = normalizeClanTag(clanTag);
    const targetClans = getAvailableWarTargets(normalizedClanTag);

    if (!targetClans.length) {
        return player.sendMessage("§e[Nexus] No hay clanes disponibles para declarar guerra en este momento.");
    }

    const form = new ActionFormData()
        .title("§l§2Proponer Guerra")
        .body(`Selecciona el clan al que deseas declarar la guerra.\n§7Clanes disponibles: ${targetClans.length}`);

    targetClans.forEach(tag => form.button(`§l${tag}`));
    form.button("§cCancelar");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return showWarMenu(player, clanTag);
        if (res.selection >= targetClans.length) return showWarMenu(player, clanTag);
        const target = normalizeClanTag(targetClans[res.selection]);
        if (!target) return showWarMenu(player, clanTag);
        if (target === normalizedClanTag) return player.sendMessage("§c[Nexus] No puedes declararte la guerra a ti mismo.");

        const result = WarManager.createWarRequest(normalizedClanTag, target);
        if (!result.success) {
            player.sendMessage(`§c[Nexus] ${result.error}`);
            return showWarMenu(player, clanTag);
        }
        player.sendMessage(`§a[Nexus] Solicitud de guerra enviada a ${target}.`);
        sendClanMessage(target, `§c[Nexus] Clan ${clanTag} te ha declarado la guerra. Usa !guerra para responder.`);
        return showWarMenu(player, clanTag);
    }).catch(() => {
        showWarMenu(player, clanTag);
    });
}

function showWarRequests(player, clanTag) {
    const normalizedClanTag = normalizeClanTag(clanTag);
    const requests = WarManager.getPendingRequestsForClan(normalizedClanTag)
        .filter(req => req && req.id && req.fromClan && req.toClan && ["declare", "ally"].includes(req.type));
    if (!requests || requests.length === 0) return player.sendMessage("§e[Nexus] No tienes solicitudes de guerra entrantes pendientes.");

    const form = new ActionFormData()
        .title("§l§3Solicitudes Entrantes")
        .body(`Selecciona una solicitud entrante para aceptar o rechazar.\n§7Total: ${requests.length}`);

    requests.forEach(req => form.button(formatRequestLabel(req)));
    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return;
        if (res.selection >= requests.length) return showWarMenu(player, clanTag);
        const request = requests[res.selection];
        showRequestActions(player, clanTag, request);
    }).catch(() => {});
}

function showOutgoingWarRequests(player, clanTag) {
    const normalizedClanTag = normalizeClanTag(clanTag);
    const requests = WarManager.getOutgoingRequestsForClan(normalizedClanTag)
        .filter(req => req && req.id && req.fromClan && req.toClan && ["declare", "ally"].includes(req.type));
    if (!requests || requests.length === 0) return player.sendMessage("§e[Nexus] No tienes solicitudes de guerra salientes pendientes.");

    const form = new ActionFormData()
        .title("§l§6Solicitudes Salientes")
        .body(`Selecciona una solicitud saliente para cancelar.\n§7Total: ${requests.length}`);

    requests.forEach(req => form.button(formatRequestLabel(req)));
    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return;
        if (res.selection >= requests.length) return showWarMenu(player, clanTag);
        const request = requests[res.selection];
        showOutgoingRequestActions(player, clanTag, request);
    }).catch(() => {});
}

function showOutgoingRequestActions(player, clanTag, request) {
    if (!request) return showWarMenu(player, clanTag);
    new ActionFormData()
        .title("§l§eSolicitud Saliente")
        .body(`Cancelar solicitud de ${request.type === "ally" ? "ayuda aliada" : "guerra"} a ${request.toClan}.${request.warId ? `\nGuerra: ${request.warId}` : ""}`)
        .button("§l§cCancelar solicitud")
        .button("§cVolver")
        .show(player)
        .then((res) => {
            if (res.canceled || res.selection === undefined) return showWarMenu(player, clanTag);
            if (res.selection === 0) {
                const result = WarManager.cancelWarRequest(request.id, clanTag);
                if (!result.success) {
                    player.sendMessage(`§c[Nexus] ${result.error}`);
                    return showWarMenu(player, clanTag);
                }
                player.sendMessage(`§a[Nexus] Solicitud cancelada.`);
                return showWarMenu(player, clanTag);
            }
            return showWarMenu(player, clanTag);
        }).catch(() => {
            showWarMenu(player, clanTag);
        });
}

function showRequestActions(player, clanTag, request) {
    if (!request) return showWarMenu(player, clanTag);
    const actionLabel = request.type === "ally" ? "Aceptar ayuda" : "Aceptar guerra";
    const bodyText = request.type === "ally"
        ? `Clan ${request.fromClan} solicita ayuda en la guerra ${request.warId}.`
        : `Clan ${request.fromClan} ha declarado la guerra a ${clanTag}.`;
    new ActionFormData()
        .title(`§l§eSolicitud de Guerra`)
        .body(bodyText)
        .button(`§l§2${actionLabel}`)
        .button("§l§cRechazar")
        .button("§cVolver")
        .show(player)
        .then((res) => {
            if (res.canceled || res.selection === undefined) return showWarMenu(player, clanTag);
            if (res.selection === 0) {
                const result = WarManager.acceptWarRequest(request.id);
                if (!result.success) {
                    player.sendMessage(`§c[Nexus] ${result.error}`);
                    return showWarMenu(player, clanTag);
                }
                if (request.type === "ally") {
                    player.sendMessage(`§a[Nexus] Has aceptado un pedido de ayuda para la guerra ${request.warId}.`);
                    sendClanMessage(request.fromClan, `§c[Nexus] Tu aliado ${clanTag} se ha unido a la guerra ${request.warId}.`);
                    if (result.war && Array.isArray(result.war.clans)) {
                        sendClansMessage(result.war.clans, `§e[Nexus] El clan ${clanTag} se ha unido a la guerra como aliado.`);
                    }
                } else {
                    player.sendMessage(`§a[Nexus] Guerra iniciada entre ${request.fromClan} y ${clanTag}.`);
                    sendClanMessage(request.fromClan, `§c[Nexus] Tu solicitud de guerra contra ${clanTag} ha sido aceptada.`);
                }
                clearWarRequestInboxMessage(player, request.id);
                return showWarMenu(player, clanTag);
            }
            if (res.selection === 1) {
                const result = WarManager.rejectWarRequest(request.id);
                if (!result.success) {
                    player.sendMessage(`§c[Nexus] ${result.error}`);
                    return showWarMenu(player, clanTag);
                }
                if (request.type === "ally") {
                    player.sendMessage(`§a[Nexus] Has rechazado el pedido de ayuda de ${request.fromClan}.`);
                    sendClanMessage(request.fromClan, `§e[Nexus] Tu solicitud de ayuda para la guerra ${request.warId} fue rechazada.`);
                } else {
                    player.sendMessage(`§a[Nexus] Has rechazado la solicitud de guerra de ${request.fromClan}.`);
                    sendClanMessage(request.fromClan, `§e[Nexus] Tu solicitud de guerra contra ${clanTag} fue rechazada.`);
                }
                clearWarRequestInboxMessage(player, request.id);
                return showWarMenu(player, clanTag);
            }
            return showWarMenu(player, clanTag);
        }).catch(() => {
            showWarMenu(player, clanTag);
        });
}

function showActiveWars(player, clanTag) {
    const normalizedClanTag = normalizeClanTag(clanTag);
    const wars = WarManager.getWarsForClan(normalizedClanTag);
    if (!wars || wars.length === 0) return player.sendMessage("§e[Nexus] No hay guerras activas relacionadas con tu clan.");

    const form = new ActionFormData()
        .title("§l§6Guerras Activas")
        .body(`Selecciona una guerra para ver detalles.\n§7Total: ${wars.length}`);

    wars.forEach(war => {
        const participants = Array.isArray(war.clans) ? war.clans.map(normalizeClanTag).filter(Boolean) : [];
        const enemies = participants.filter(c => c !== normalizedClanTag);
        const scoreText = participants.map(c => `${c}:${war.score?.[c] || 0}`).join(" | ");
        const label = enemies.length ? enemies.join(", ") : "Desconocido";
        form.button(`§l${label}\n§7${scoreText}`);
    });
    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return;
        if (res.selection >= wars.length) return showWarMenu(player, clanTag);
        const war = wars[res.selection];
        showWarDetails(player, clanTag, war);
    }).catch(() => {});
}

function showHelpFromAllies(player, clanTag, war) {
    const normalizedClanTag = normalizeClanTag(clanTag);
    if (!normalizedClanTag || !isValidWar(war)) return showWarDetails(player, clanTag, war);
    const allies = getAvailableAllies(normalizedClanTag, war);
    if (!allies || allies.length === 0) {
        player.sendMessage("§e[Nexus] No tienes aliados disponibles fuera de la guerra.");
        return showWarDetails(player, clanTag, war);
    }

    const form = new ActionFormData()
        .title("§l§2Pedir ayuda a aliados")
        .body(`Selecciona un clan aliado disponible:\n§7Aliados disponibles: ${allies.length}`);
    allies.forEach(tag => form.button(`§l${tag}`));
    form.button("§cCancelar");

    form.show(player).then(res => {
        if (res.canceled || res.selection === undefined) return showWarDetails(player, clanTag, war);
        if (res.selection >= allies.length) return showWarDetails(player, clanTag, war);
        const target = normalizeClanTag(allies[res.selection]);
        if (!target) {
            player.sendMessage("§c[Nexus] Selección inválida.");
            return showWarDetails(player, clanTag, war);
        }
        const result = WarManager.createWarRequest(normalizedClanTag, target, "ally", war.id);
        if (!result.success) {
            player.sendMessage(`§c[Nexus] ${result.error}`);
            return showWarDetails(player, clanTag, war);
        }
        player.sendMessage(`§a[Nexus] Pedido de ayuda enviado a ${target}.`);
        sendClanMessage(target, `§c[Nexus] Clan ${clanTag} solicita ayuda en la guerra ${war.id}. Usa !guerra para responder.`);
        return showWarDetails(player, clanTag, war);
    }).catch(() => {
        showWarDetails(player, clanTag, war);
    });
}

function showWarDetails(player, clanTag, war) {
    if (!isValidWar(war)) return showWarMenu(player, clanTag);
    const normalizedClanTag = normalizeClanTag(clanTag);
    const clan = ClanManager.getClan(normalizedClanTag);
    const role = clan && clan.members && clan.members[player.name] ? clan.members[player.name].role : null;
    const isLeader = role === "leader" || role === "coleader";
    const participants = Array.isArray(war.clans) ? war.clans.map(normalizeClanTag).filter(Boolean) : [];
    const otherClans = participants.filter(c => c !== normalizedClanTag);
    const activeScores = war.score || {};
    const scoreText = participants.map(c => `${c}:${activeScores[c] || 0}`).join(" | ");
    const alliesAvailable = getAvailableAllies(normalizedClanTag, war);
    const alliesText = otherClans.length ? otherClans.join(", ") : "Ninguno";

    // OBTENER CONFIGURACIÓN DINÁMICA
    const config = WarConfig.getConfig();

    // Mostrar progreso hacia victoria
    const myScore = activeScores[normalizedClanTag] || 0;
    const scoreProgress = `${myScore}/${config.WINNING_POINTS} puntos`;
    const progressBar = `${"§a▓".repeat(Math.min(myScore, config.WINNING_POINTS))}${"§8░".repeat(Math.max(0, config.WINNING_POINTS - myScore))}`;

    const availableAlliesLabel = alliesAvailable.length > 0 ? alliesAvailable.join(", ") : "Ninguno";
    const form = new ActionFormData()
        .title(`§l§4Guerra ${war.id}`)
        .body(() => {
            // Formatear fecha de inicio de forma segura
            let startedText = "Fecha desconocida";
            try {
                const d = new Date(war.startedAt);
                if (!Number.isNaN(d.getTime())) startedText = d.toLocaleString();
            } catch (e) {}

            // Asegurar WINNING_POINTS razonable
            let winPoints = parseInt(config.WINNING_POINTS, 10) || 10;
            winPoints = Math.min(Math.max(winPoints, 1), 200);

            // Construir barra de progreso con enteros y límites
            const myScoreNum = Math.floor(Number(myScore) || 0);
            const filled = Math.min(myScoreNum, winPoints);
            const empty = Math.max(0, winPoints - filled);
            const safeProgressBar = `${"§a▓".repeat(filled)}${"§8░".repeat(empty)}`;

            return `Clan: §e${normalizedClanTag}\nEnemigos/Aliados: §c${alliesText}\nPuntaje: §a${scoreText}\n\n§l§6Progreso: ${scoreProgress}\n${safeProgressBar}\n\n§7Iniciada: §e${startedText}\nAliados disponibles: §e${alliesAvailable.length} §7(${availableAlliesLabel})`;
        }());

    let buttonIndex = 0;
    const optionIndexes = { recordVictory: buttonIndex++ };
    form.button("§l§2Registrar victoria propia");

    if (isLeader && alliesAvailable.length > 0) {
        optionIndexes.askHelp = buttonIndex;
        buttonIndex++;
        form.button(`§l§4Pedir ayuda a aliados (§e${alliesAvailable.length} disponibles§r)`);
    }
    if (otherClans.length > 0) {
        optionIndexes.enemyDetails = buttonIndex;
        buttonIndex++;
        form.button("§l§3Ver detalles de clan enemigo");
    }
    if (isLeader) {
        optionIndexes.endWar = buttonIndex;
        buttonIndex++;
        form.button("§l§cFinalizar guerra");
    }
    optionIndexes.back = buttonIndex;
    buttonIndex++;
    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return showWarMenu(player, clanTag);
        if (res.selection === optionIndexes.recordVictory) {
            const result = WarManager.recordVictory(war.id, normalizedClanTag);
            if (!result.success) {
                player.sendMessage(`§c[Nexus] ${result.error}`);
                return showWarDetails(player, clanTag, war);
            }
            player.sendMessage(`§a[Nexus] Victoria registrada para ${normalizedClanTag}. Nuevo puntaje: ${normalizedClanTag} ${result.war.score[normalizedClanTag]} - ${otherClans.join(", ")}`);
            sendClansMessage(otherClans, `§e[Nexus] El clan ${normalizedClanTag} ha registrado una victoria en la guerra actual.`);
            return showWarDetails(player, clanTag, result.war);
        }
        if (optionIndexes.askHelp !== undefined && res.selection === optionIndexes.askHelp) {
            return showHelpFromAllies(player, clanTag, war);
        }
        if (optionIndexes.enemyDetails !== undefined && res.selection === optionIndexes.enemyDetails) {
            return showEnemyClanSelection(player, clanTag, war, otherClans);
        }
        if (optionIndexes.endWar !== undefined && res.selection === optionIndexes.endWar) {
            const result = WarManager.endWarWithAutoResult(war.id);
            if (!result.success) {
                player.sendMessage(`§c[Nexus] ${result.error}`);
                return showWarDetails(player, clanTag, war);
            }
            if (result.tie) {
                player.sendMessage(`§e[Nexus] Guerra ${war.id} finalizada en empate.`);
                sendClansMessage(otherClans, `§e[Nexus] La guerra ${war.id} terminó en empate.`);
            } else {
                player.sendMessage(`§a[Nexus] Guerra finalizada. Ganador: ${result.winner}.`);
                sendClansMessage(otherClans, `§e[Nexus] Guerra ${war.id} finalizada. Ganador: ${result.winner}.`);
            }
            return showWarMenu(player, clanTag);
        }
        return showWarMenu(player, clanTag);
    }).catch(() => {
        showWarMenu(player, clanTag);
    });
}

function showEnemyClanSelection(player, clanTag, war, enemyClans) {
    if (!Array.isArray(enemyClans) || enemyClans.length === 0) return showWarDetails(player, clanTag, war);
    const form = new ActionFormData()
        .title("§l§3Detalles de Clan Enemigo")
        .body("Selecciona el clan enemigo para ver su información:");

    enemyClans.forEach(tag => form.button(`§l${tag}`));
    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return showWarDetails(player, clanTag, war);
        if (res.selection >= enemyClans.length) return showWarDetails(player, clanTag, war);
        return showEnemyClanInfo(player, clanTag, enemyClans[res.selection], war);
    }).catch(() => {
        showWarDetails(player, clanTag, war);
    });
}

function showEnemyClanInfo(player, clanTag, enemyClanTag, war) {
    const enemyClan = ClanManager.getClan(enemyClanTag);
    if (!enemyClan) {
        player.sendMessage("§c[Nexus] No se encontró información del clan enemigo.");
        return showWarDetails(player, clanTag, war);
    }

    const memberCount = enemyClan.members ? Object.keys(enemyClan.members).length : 0;
    const allyCount = Array.isArray(enemyClan.allies) ? enemyClan.allies.length : 0;
    const claimCount = Array.isArray(enemyClan.claims) ? enemyClan.claims.length : 0;
    const claimLimit = enemyClan.claimLimit || ClanManager.getClaimLimit(enemyClanTag);

    const form = new ActionFormData()
        .title(`§l§cClan Enemigo - ${enemyClanTag}`)
        .body(
            `Nombre: §e${enemyClan.name || enemyClanTag}` +
            `\nLíder: §f${enemyClan.leader || 'Desconocido'}` +
            `\nMiembros: §a${memberCount}` +
            `\nAliados: §b${allyCount}` +
            `\nReclamos: §e${claimCount}/${claimLimit}`
        )
        .button("§l§2Volver al detalle de guerra");

    form.show(player).then(() => {
        showWarDetails(player, clanTag, war);
    }).catch(() => {
        showWarDetails(player, clanTag, war);
    });
}

function showWarHistory(player, clanTag) {
    const normalizedClanTag = normalizeClanTag(clanTag);
    const stats = WarManager.getWarStats(normalizedClanTag);
    const history = Array.isArray(stats.history) ? stats.history.slice(-5).reverse() : [];

    const statsText = [
        `§l§6Estadísticas de Guerras`,
        `Victorias: §a${stats.wins}`,
        `Derrotas: §c${stats.losses}`,
        `Total: §e${stats.totalWars}`,
        `Winrate: §b${stats.winRate}%`
    ].join("\n");

    const form = new ActionFormData()
        .title(`§l§eHistorial - ${clanTag}`)
        .body(statsText);

    const historyItems = [];
    if (history.length > 0) {
        history.forEach(war => {
            const enemyClans = war.clans.filter(c => c !== normalizedClanTag).join(", ");
            const result = war.tie ? "§eEMPATE" : (war.winner === normalizedClanTag ? "§aVICTORIA" : "§cDERROTA");
            const finalScore = `${war.finalScore?.[normalizedClanTag] || 0}-${war.finalScore?.[war.clans.find(c => c !== normalizedClanTag)] || 0}`;
            const dateText = war.finishedAt ? new Date(war.finishedAt).toLocaleString() : "Fecha desconocida";
            form.button(`${result} vs ${enemyClans}\n§7${dateText} · ${finalScore}`);
            historyItems.push(war);
        });
    } else {
        form.body(statsText + "\n\n§7Sin historial de guerras completadas.");
    }

    form.button("§cVolver");

    form.show(player).then((res) => {
        if (res.canceled || res.selection === undefined) return showWarMenu(player, clanTag);
        if (res.selection < historyItems.length) return showWarHistoryDetails(player, clanTag, historyItems[res.selection]);
        return showWarMenu(player, clanTag);
    }).catch(() => {
        showWarMenu(player, clanTag);
    });
}

function showWarHistoryDetails(player, clanTag, war) {
    if (!isValidWar(war)) return showWarHistory(player, clanTag);
    const normalizedClanTag = normalizeClanTag(clanTag);
    const enemyClans = war.clans.filter(c => c !== normalizedClanTag).join(", ");
    const finalScore = `${war.finalScore?.[normalizedClanTag] || 0}-${war.finalScore?.[war.clans.find(c => c !== normalizedClanTag)] || 0}`;
    const result = war.tie ? "EMPATE" : (war.winner === normalizedClanTag ? "VICTORIA" : "DERROTA");
    const dateText = war.finishedAt ? new Date(war.finishedAt).toLocaleString() : "Fecha desconocida";
    const details = [
        `Clan: §e${normalizedClanTag}`,
        `Rivales: §c${enemyClans}`,
        `Resultado: §b${result}`,
        `Puntaje final: §a${finalScore}`,
        `Finalizado: §e${dateText}`
    ].join("\n");

    new ActionFormData()
        .title(`§l§eDetalle de Guerra - ${war.id}`)
        .body(details)
        .button("§l§2Volver al historial")
        .button("§cVolver al menú de guerras")
        .show(player).then((res) => {
            if (res.canceled || res.selection === undefined || res.selection === 1) return showWarMenu(player, clanTag);
            return showWarHistory(player, clanTag);
        }).catch(() => showWarHistory(player, clanTag));
}

export { showWarMenu, showWarHistory };
