import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { world, system } from "@minecraft/server";
import { TerritoryManager } from "../territories/territoryManager.js";
import { Database } from "../core/database.js";
import { spawnClaimEffect, spawnMultiClaimEffect } from "../territories/claimMarkers.js";

export function showAdminTerritoryPanel(player) {
    if (!player) return;
    const isAdmin = player.getTags().find(t => t === "nexus_admin");
    if (!isAdmin) return player.sendMessage("§c[Nexus] No tienes permisos de administrador.");

    const form = new ActionFormData()
        .title("§l§cAdmin - Territorios")
        .body("Acciones de administrador sobre territorios. Usa con cuidado.")
        .button("§l§2Forzar Claim en este chunk")
        .button("§l§cForzar Unclaim en este chunk")
        .button("§l§6Forzar Claim a Clan (seleccionar clan)")
        .button("§l§eVer propietario del chunk actual")
        .button("§l§cCerrar");

    form.show(player).then(r => {
        if (r.canceled) return;
        const sel = r.selection;
        const chunkId = TerritoryManager.getChunkId(player.location, player.dimension.id);
        if (sel === 0) {
            new ModalFormData().title("Forzar Claim").textField("Clan tag (Ej: WAR):", "TAG").show(player).then(res => {
                if (res.canceled) return;
                const tag = String(res.formValues[0]).toUpperCase();
                system.run(() => {
                    const ok = TerritoryManager.forceClaimChunk(chunkId, tag);
                    if (ok) {
                        player.sendMessage(`§a[Nexus] Chunk ${chunkId} forzado a clan ${tag}.`);
                        try { spawnClaimEffect(player, chunkId); } catch(e){}
                    } else player.sendMessage("§c[Nexus] No se pudo forzar el claim.");
                });
            });
        } else if (sel === 1) {
            system.run(() => {
                const ok = TerritoryManager.forceUnclaimChunk(chunkId);
                if (ok) {
                    player.sendMessage(`§a[Nexus] Chunk ${chunkId} liberado (forzado).`);
                } else player.sendMessage("§c[Nexus] No se pudo liberar el chunk.");
            });
        } else if (sel === 2) {
            const clans = Database.getAllClans();
            if (!clans || clans.length === 0) return player.sendMessage("§c[Nexus] No hay clans registrados.");
            const listForm = new ActionFormData().title("Seleccionar Clan").body("Selecciona el clan al que forzar el claim:");
            clans.forEach(c => listForm.button(String(c)));
            listForm.button("§cCancelar");
            listForm.show(player).then(choice => {
                if (choice.canceled) return;
                if (choice.selection < clans.length) {
                    const tag = String(clans[choice.selection]).toUpperCase();
                    system.run(() => {
                        const ok = TerritoryManager.forceClaimChunk(chunkId, tag);
                        if (ok) {
                            player.sendMessage(`§a[Nexus] Chunk ${chunkId} forzado a clan ${tag}.`);
                            try { spawnClaimEffect(player, chunkId); } catch(e){}
                        } else player.sendMessage("§c[Nexus] No se pudo forzar el claim.");
                    });
                }
            });
        } else if (sel === 3) {
            const owner = TerritoryManager.getChunkOwner(chunkId);
            if (owner) player.sendMessage(`§7Propietario: §e${owner}`);
            else player.sendMessage("§7Chunk sin propietario.");
        }
    });
}

// Exponer por defecto para imports
export default { showAdminTerritoryPanel };
