export const Logger = {
    logEvent(category, message) {
        const timestamp = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
        console.warn(`[Nexus Log] [${timestamp}] [${category.toUpperCase()}] ${message}`);
    }
}