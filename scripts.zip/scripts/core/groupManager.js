/**
 * Gestor de Grupos Temporales (RAM)
 * Estructura: Map<groupId, { leader, members: string[] }>
 */
const activeGroups = new Map();
const playerGroups = new Map();
const partyInvites = new Map();
const ROLE_WEIGHTS = { leader: 4, coleader: 3, moderator: 2, member: 1 };

import { system } from "@minecraft/server";

export const GroupManager = {
    playerGroups,

    // Backwards-compatible: acepta objeto jugador o nombre
    isPlayerInGroup(playerOrName) {
        const name = typeof playerOrName === "string" ? playerOrName : playerOrName?.name;
        return playerGroups.has(name);
    },

    getGroupId(playerOrName) {
        const name = typeof playerOrName === "string" ? playerOrName : playerOrName?.name;
        return playerGroups.get(name) || null;
    },

    getGroupMembers(playerOrName) {
        const groupId = this.getGroupId(playerOrName);
        if (!groupId) return [];
        const group = activeGroups.get(groupId);
        return group ? [...group.members] : [];
    },

    createGroup(player) {
        if (playerGroups.has(player.name)) return null;

        const groupId = `grp_${player.name}`;
        const groupData = {
            id: groupId,
            leader: player.name,
            members: [player.name],
            roles: { [player.name]: "leader" }
        };

        activeGroups.set(groupId, groupData);
        playerGroups.set(player.name, groupId);
        if (typeof player.addTag === "function") player.addTag("in_group");

        return groupId;
    },

    joinGroup(groupId, player) {
        const group = activeGroups.get(groupId);
        if (!group || playerGroups.has(player.name)) return false;
        group.members.push(player.name);
        if (!group.roles) group.roles = {};
        group.roles[player.name] = "member";
        playerGroups.set(player.name, groupId);
        if (typeof player.addTag === "function") player.addTag("in_group");
        return true;
    },

    leaveGroup(playerOrName) {
        const name = typeof playerOrName === "string" ? playerOrName : playerOrName?.name;
        const playerObj = typeof playerOrName === "string" ? null : playerOrName;

        const groupId = playerGroups.get(name);
        if (!groupId) return false;

        const group = activeGroups.get(groupId);
        if (!group) return false;

        group.members = group.members.filter(n => n !== name);
        if (group.roles) delete group.roles[name];
        playerGroups.delete(name);
        if (playerObj && typeof playerObj.removeTag === "function") playerObj.removeTag("in_group");

        if (group.members.length === 0) {
            activeGroups.delete(groupId);
            return "disbanded";
        }

        if (group.leader === name) {
            group.leader = group.members[0];
            if (group.roles) {
                group.roles[group.leader] = "leader";
            }
        }
        return "left";
    },

    getGroupMemberRole(playerName) {
        const groupId = this.getGroupId(playerName);
        if (!groupId) return null;
        const group = activeGroups.get(groupId);
        if (!group || !group.roles) return null;
        return group.roles[playerName] || null;
    },
    hasGroupPermission(playerName, requiredRole) {
        const role = this.getGroupMemberRole(playerName);
        if (!role || !ROLE_WEIGHTS[role] || !ROLE_WEIGHTS[requiredRole]) return false;
        return ROLE_WEIGHTS[role] >= ROLE_WEIGHTS[requiredRole];
    },
    setGroupRole(executorName, targetName, newRole) {
        if (!ROLE_WEIGHTS[newRole]) return false;
        const groupId = this.getGroupId(executorName);
        if (!groupId || groupId !== this.getGroupId(targetName)) return false;
        const group = activeGroups.get(groupId);
        if (!group || !group.roles) return false;

        const executorRole = group.roles[executorName];
        const targetRole = group.roles[targetName];
        if (!executorRole || !targetRole) return false;

        if (executorName === targetName) return false;
        if (targetRole === "leader") return false;

        if (executorRole === "leader") {
            group.roles[targetName] = newRole;
            return true;
        }

        if (executorRole === "coleader" && ["moderator", "member"].includes(newRole)) {
            group.roles[targetName] = newRole;
            return true;
        }

        return false;
    },
    getGroupData(playerOrName) {
        const groupId = this.getGroupId(playerOrName);
        return groupId ? activeGroups.get(groupId) : null;
    },

    // Party-style API (compatibility with older party API)
    getParty(playerName) {
        return playerGroups.get(playerName) || null;
    },

    invite(leaderName, targetName) {
        const leaderParty = playerGroups.get(leaderName);
        if (!leaderParty) return "not_leader";
        const group = activeGroups.get(leaderParty);
        if (!group || group.leader !== leaderName) return "not_leader";
        if (playerGroups.has(targetName)) return "already_in_party";

        partyInvites.set(targetName, leaderParty);
        system.runTimeout(() => {
            if (partyInvites.get(targetName) === leaderParty) partyInvites.delete(targetName);
        }, 1200);

        return "success";
    },

    accept(playerName) {
        const groupId = partyInvites.get(playerName);
        if (!groupId) return false;

        const group = activeGroups.get(groupId);
        if (!group || playerGroups.has(playerName)) return false;

        group.members.push(playerName);
        playerGroups.set(playerName, groupId);
        partyInvites.delete(playerName);
        return groupId;
    },

    leave(playerName) {
        const partyId = playerGroups.get(playerName);
        if (!partyId) return false;

        const group = activeGroups.get(partyId);
        if (!group) return false;

        group.members = group.members.filter(n => n !== playerName);
        playerGroups.delete(playerName);

        if (group.leader === playerName) {
            if (group.members.length === 0) {
                activeGroups.delete(partyId);
                return "disbanded";
            }
            group.leader = group.members[0];
        }

        if (group.members.length === 0) {
            activeGroups.delete(partyId);
            return "disbanded";
        }

        return "left";
    }
};
