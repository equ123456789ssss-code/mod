import { world, system } from "@minecraft/server";
import { safeRunCommand } from "../utils/commandHelper.js";

export class Database {
    static normalizeKey(key) {
        if (key === "nexus_clan_list") return "nexus_clans_list";
        return key;
    }

    static parseValue(value) {
        if (typeof value !== "string") return value;
        try {
            return JSON.parse(value);
        } catch {
            return value;
        }
    }

    static _isTTLRecord(value) {
        return value && typeof value === "object" && value.__ttlVersion === 1 && typeof value.__expiresAt === "number" && Object.prototype.hasOwnProperty.call(value, "value");
    }

    static _wrapValueForTTL(value, ttlMs) {
        return {
            __ttlVersion: 1,
            __expiresAt: Date.now() + Number(ttlMs),
            value
        };
    }

    static load(key, defaultValue = null) {
        const normalized = this.normalizeKey(key);
        const raw = world.getDynamicProperty(normalized);
        if (raw === undefined) return defaultValue;
        const parsed = this.parseValue(raw);
        if (this._isTTLRecord(parsed)) {
            if (Date.now() >= parsed.__expiresAt) {
                this.delete(key);
                return defaultValue;
            }
            return parsed.value === null ? defaultValue : parsed.value;
        }
        return parsed === null ? defaultValue : parsed;
    }

    static save(key, value, options = {}) {
        const normalized = this.normalizeKey(key);
        let payload = value;
        if (options && typeof options.ttlMs === "number" && options.ttlMs > 0) {
            payload = this._wrapValueForTTL(value, options.ttlMs);
        }
        const stored = typeof payload === "object" ? JSON.stringify(payload) : String(payload);
        try {
            // Antes de sobreescribir, guardamos una copia de seguridad rápida
            const prev = world.getDynamicProperty(normalized);
            if (prev !== undefined) {
                try {
                    world.setDynamicProperty(`${normalized}_last_backup`, prev);
                    world.setDynamicProperty(`${normalized}_last_backup_ts`, String(Date.now()));
                } catch (e) {}
            }
        } catch (e) {}

        try {
            world.setDynamicProperty(normalized, stored);
        } catch (e) {
            // Silenciar errores en entornos con permisos limitados
        }
    }

    static delete(key) {
        const normalized = this.normalizeKey(key);
        try {
            // En lugar de borrar definitivamente, guardamos un respaldo con timestamp
            const prev = world.getDynamicProperty(normalized);
            if (prev !== undefined) {
                const ts = Date.now();
                try {
                    world.setDynamicProperty(`${normalized}_deleted_backup_${ts}`, prev);
                    world.setDynamicProperty(`${normalized}_deleted_ts`, String(ts));
                } catch (e) {}
            }
        } catch (e) {}

        // Finalmente marcamos como undefined
        world.setDynamicProperty(normalized, undefined);
    }

    static restoreLastBackup(key) {
        const normalized = this.normalizeKey(key);
        try {
            const bak = world.getDynamicProperty(`${normalized}_last_backup`);
            if (bak === undefined) return false;
            world.setDynamicProperty(normalized, bak);
            return true;
        } catch (e) {
            return false;
        }
    }

    static get(key, defaultValue = null) {
        return this.load(key, defaultValue);
    }

    static set(key, value) {
        this.save(key, value);
    }

    static setWithTTL(key, value, ttlMs) {
        if (!key || typeof ttlMs !== "number" || ttlMs <= 0) return false;
        this.save(key, value, { ttlMs });
        return true;
    }

    static getWithTTL(key, defaultValue = null) {
        return this.load(key, defaultValue);
    }

    static getClanList() {
        return this.load("nexus_clans_list", []);
    }

    static getAllClans() {
        const list = this.getClanList();
        if (!Array.isArray(list)) return [];
        return list.map(item => {
            if (typeof item === "object" && item !== null && item.name) return item.name;
            return String(item);
        });
    }

    static saveClanList(list) {
        this.save("nexus_clans_list", list);
    }

    static createClan(clanName, leaderName) {
        if (!clanName || !leaderName) return false;
        const normalized = clanName.trim();
        if (!normalized) return false;

        const current = this.getClanData(normalized);
        if (current) return false;

        const clans = this.getClanList();
        const duplicate = clans.some(item => {
            const name = typeof item === "object" && item !== null && item.name ? item.name : item;
            return String(name).toLowerCase() === normalized.toLowerCase();
        });

        if (duplicate) return false;

        const clan = {
            name: normalized,
            leader: leaderName,
            // Usamos objeto para miembros para soportar roles: { playerName: { role, joinedAt } }
            members: { [leaderName]: { role: "leader", joinedAt: Date.now() } },
            createdAt: new Date().toLocaleString(),
            base: null
        };

        this.saveClanData(normalized, clan);
        clans.push(normalized);
        this.saveClanList(clans);
        return true;
    }

    static deleteClan(clanName) {
        if (!clanName) return false;
        this.deleteClanData(clanName);
        const filtered = this.getClanList().filter(item => {
            const name = typeof item === "object" && item !== null && item.name ? item.name : item;
            return String(name).toLowerCase() !== clanName.toLowerCase();
        });
        this.saveClanList(filtered);
        return true;
    }

    static kickMember(clanName, memberName) {
        if (!clanName || !memberName) return false;
        const clan = this.getClanData(clanName);
        if (!clan || !clan.members) return false;

        // Si members es array (formato antiguo), mantenemos compatibilidad
        if (Array.isArray(clan.members)) {
            const newMembers = clan.members.filter(name => name !== memberName);
            if (newMembers.length === clan.members.length) return false;
            clan.members = newMembers;
            if (clan.leader === memberName) {
                clan.leader = newMembers[0] || null;
            }
            this.saveClanData(clanName, clan);
            return true;
        }

        // Si members es objeto (nuevo formato)
        if (typeof clan.members === "object") {
            if (!clan.members[memberName]) return false;
            delete clan.members[memberName];
            // Si era líder, reasignar
            if (clan.leader === memberName) {
                const remaining = Object.keys(clan.members);
                clan.leader = remaining[0] || null;
            }
            this.saveClanData(clanName, clan);
            return true;
        }

        return false;
    }

    static getClanData(clanName) {
        if (!clanName) return null;
        return this.load(`nexus_clan_${clanName.toUpperCase()}`, null);
    }

    static saveClanData(clanName, data) {
        if (!clanName) return;
        this.save(`nexus_clan_${clanName.toUpperCase()}`, data);
    }

    static deleteClanData(clanName) {
        if (!clanName) return;
        this.delete(`nexus_clan_${clanName.toUpperCase()}`);
    }

    static getBookmarks(player) {
        if (!player || !player.name) return [];
        return this.load(`nexus_bookmarks_${player.name}`, []);
    }

    static addBookmark(player, bookmark) {
        if (!player || !player.name) return false;
        const key = `nexus_bookmarks_${player.name}`;
        const list = this.load(key, []);
        list.push(bookmark);
        this.save(key, list);
        return true;
    }

    static getInbox(playerName) {
        return this.load(`nexus_inbox_${playerName}`, []);
    }

    static addMessageToInbox(playerName, sender, text, type = "message", metadata = {}) {
        if (!playerName) return false;
        const inbox = this.getInbox(playerName);
        const msg = {
            sender: sender || "Sistema",
            text: text || "",
            type: type || "message",
            metadata: typeof metadata === "object" && metadata !== null ? metadata : {},
            date: new Date().toLocaleString(),
            ts: Date.now(),
            read: false
        };

        inbox.unshift(msg);
        this.save(`nexus_inbox_${playerName}`, inbox);

        // Guardar en historial del receptor
        try {
            this.appendHistory(playerName, {
                type: msg.type,
                direction: "in",
                sender: msg.sender,
                target: playerName,
                text: msg.text,
                metadata: msg.metadata,
                date: new Date().toISOString()
            });
        } catch (e) {
            // no crítico
        }

        // Notificación de invitación centralizada según preferencias
        if (msg.type === "clan_invite" || msg.type === "group_invite") {
            import("../ui/notificationHelper.js").then(helper => {
                if (helper && helper.notifyInvite) {
                    const player = world.getPlayers().find(p => p.name === playerName);
                    if (player) helper.notifyInvite(player, msg);
                }
            }).catch(() => {});
        }

        // Notificaciones rápidas para solicitudes y eventos importantes
        if (["war_request", "ally_request", "ally_accepted", "war_started", "request_rejected", "request_canceled"].includes(msg.type)) {
            import("../ui/notificationHelper.js").then(helper => {
                if (helper && helper.notifyNotification) {
                    const player = world.getPlayers().find(p => p.name === playerName);
                    if (player) helper.notifyNotification(player, msg);
                }
            }).catch(() => {});
        }

        // Programar expiración automática para invitaciones
        try {
            if (msg.type === "clan_invite" || msg.type === "group_invite") {
                const inviteMsg = msg; // capture
                system.runTimeout(() => {
                    try {
                        const inboxNow = this.getInbox(playerName);
                        const idx = inboxNow.findIndex(m => m && m.type === inviteMsg.type && m.date === inviteMsg.date && JSON.stringify(m.metadata) === JSON.stringify(inviteMsg.metadata));
                        if (idx !== -1) {
                            this.deleteMessage(playerName, idx);
                        }
                    } catch (e) {
                        // Silenciar errores
                    }
                }, 1200);
            }
        } catch (e) {
            // ignore
        }

        return msg;
    }

    static findInboxMessage(playerName, predicate) {
        const inbox = this.getInbox(playerName);
        for (let index = 0; index < inbox.length; index++) {
            const msg = inbox[index];
            if (msg && predicate(msg)) return { message: msg, index };
        }
        return null;
    }

    static markMessageAsRead(playerName, index) {
        const inbox = this.getInbox(playerName);
        if (index < 0 || index >= inbox.length) return false;
        inbox[index].read = true;
        this.save(`nexus_inbox_${playerName}`, inbox);
        return true;
    }

    static deleteMessage(playerName, index) {
        const inbox = this.getInbox(playerName);
        if (index < 0 || index >= inbox.length) return false;
        inbox.splice(index, 1);
        this.save(`nexus_inbox_${playerName}`, inbox);
        return true;
    }

    static cleanupInbox(playerName) {
        const inbox = this.getInbox(playerName).filter(msg => msg && typeof msg === "object");
        this.save(`nexus_inbox_${playerName}`, inbox);
        return inbox;
    }

    static getBlockedList(playerName) {
        return this.load(`nexus_blocked_${playerName}`, []);
    }

    static isBlocked(playerName, targetName) {
        const blocked = this.getBlockedList(playerName);
        return blocked.includes(targetName);
    }

    static blockPlayer(playerName, targetName) {
        if (!playerName || !targetName) return false;
        const blocked = this.getBlockedList(playerName);
        if (!blocked.includes(targetName)) {
            blocked.push(targetName);
            this.save(`nexus_blocked_${playerName}`, blocked);
        }
        return true;
    }

    static unblockPlayer(playerName, targetName) {
        if (!playerName || !targetName) return false;
        let blocked = this.getBlockedList(playerName);
        blocked = blocked.filter(name => name !== targetName);
        this.save(`nexus_blocked_${playerName}`, blocked);
        return true;
    }

    static invitePlayerToClan(senderName, targetName, clanName) {
        if (!targetName || !clanName) return false;
        const text = `§l⚔️ INVITACIÓN AL CLAN§r\nJugador: ${senderName}\nClan: ${clanName}`;
        return this.addMessageToInbox(targetName, senderName, text);
    }

    // Migra clanes que estén en el formato antiguo (members: [name, ...])
    // hacia el nuevo formato (members: { name: { role, joinedAt } }).
    // Esta función puede llamarse en el arranque para normalizar datos existentes.
    static migrateClans() {
        const migrated = [];
        try {
            const clans = this.getClanList();
            if (!Array.isArray(clans)) return migrated;
            for (const raw of clans) {
                const clanName = typeof raw === "object" && raw !== null && raw.name ? raw.name : String(raw);
                if (!clanName) continue;
                const data = this.getClanData(clanName);
                if (!data || !data.members) continue;

                // Si members ya es objeto, nada que hacer
                if (typeof data.members === "object" && !Array.isArray(data.members)) continue;

                // Si es array, convertir
                if (Array.isArray(data.members)) {
                    const arr = data.members.slice();
                    const obj = {};
                    for (const m of arr) {
                        const name = String(m);
                        obj[name] = { role: data.leader === name ? "leader" : "member", joinedAt: Date.now() };
                    }
                    data.members = obj;
                    this.saveClanData(clanName, data);
                    migrated.push(clanName);
                }
            }
            return migrated;
        } catch (e) {
            console.warn("[Database] migrateClans error:", e);
            return migrated;
        }
    }

    // Historial global/por jugador: guarda eventos de mensajes, invites, acciones
    static appendHistory(playerName, entry) {
        if (!playerName || !entry) return false;
        try {
            const key = `nexus_history_${playerName}`;
            const hist = this.load(key, []);
            const capped = Array.isArray(hist) ? hist : [];
            const item = Object.assign({}, entry, { createdAt: new Date().toISOString() });
            capped.unshift(item);
            // Mantener último máximo 500 eventos para evitar crecer indefinidamente
            if (capped.length > 500) capped.length = 500;
            this.save(key, capped);
            return true;
        } catch (e) {
            return false;
        }
    }

    static getHistory(playerName, limit = 50) {
        if (!playerName) return [];
        const hist = this.load(`nexus_history_${playerName}`, []);
        if (!Array.isArray(hist)) return [];
        return hist.slice(0, Math.max(0, limit));
    }

    static clearHistory(playerName) {
        if (!playerName) return false;
        this.save(`nexus_history_${playerName}`, []);
        return true;
    }
}
