import { Database } from "./database.js";

export const ClanBaseManager = {
    /**
     * Define la base de un clan.
     * Guarda: { x, y, z, radius }
     */
    setClanBase(clanName, location, radius = 20) {
        if (!clanName || !location) return false;
        const normalizedClan = clanName.toUpperCase();
        const clanData = Database.getClanData(normalizedClan) || {};
        clanData.base = {
            x: Math.floor(location.x),
            y: Math.floor(location.y),
            z: Math.floor(location.z),
            radius: radius
            ,
            dimension: location.dimension ? location.dimension.id || location.dimension : null
        };

        Database.saveClanData(normalizedClan, clanData);
        return true;
    },

    /**
     * Verifica si una posición está dentro de una base protegida
     * Retorna el nombre del clan si está dentro, null si es terreno libre
     */
    getClaimAtPosition(location) {
        const allClans = Database.getAllClans();

        for (const clanName of allClans) {
            const data = Database.getClanData(clanName);
            if (!data || !data.base) continue;

            if (data.base.dimension && data.base.dimension !== location.dimension?.id && data.base.dimension !== location.dimension) continue;

            const dist = Math.sqrt(
                Math.pow(location.x - data.base.x, 2) +
                Math.pow(location.z - data.base.z, 2) // Usamos XZ para evitar problemas de altura (cielo/subsuelo)
            );

            if (dist <= data.base.radius) return clanName;
        }
        return null;
    }
}