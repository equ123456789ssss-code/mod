import { world, system } from "@minecraft/server";
import { showMainHub } from "../ui/mainHub.js";
import { safeRunCommand } from "../utils/commandHelper.js";

const ITEM_ACTIONS = new Map([
    ["minecraft:blaze_rod", showMainHub]
]);

const ACTIONBAR_MESSAGE = "§eAbriendo Nexus Hub...";

function getItemAction(itemStack) {
    if (!itemStack?.typeId) return null;
    return ITEM_ACTIONS.get(itemStack.typeId) || null;
}

function openNexusHub(player, action) {
    if (!player || typeof action !== "function") return;

    safeRunCommand(player, `title @s actionbar ${ACTIONBAR_MESSAGE}`);
    system.runTimeout(() => action(player), 1);
}

world.beforeEvents.itemUse.subscribe((event) => {
    const action = getItemAction(event.itemStack);
    if (!action) return;

    const player = event.source;
    if (!player) return;

    event.cancel = true;
    openNexusHub(player, action);
});