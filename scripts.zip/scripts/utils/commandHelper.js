export async function safeRunCommand(target, command) {
    try {
        if (!target || typeof target.runCommandAsync !== "function") return null;
        return await target.runCommandAsync(command).catch(() => null);
    } catch (e) {
        return null;
    }
}

export default { safeRunCommand };
