/**
 * Sistema de caché para distancias y coordinadas entre jugadores.
 * Evita recálculos innecesarios en cada tick mejorando performance.
 */

const CACHE_TTL_MS = 1000; // TTL en milisegundos (1 segundo)
const MAX_CACHE_ENTRIES = 1000;

class DistanceCache {
    constructor() {
        this.cache = new Map(); // "playerA:playerB" -> { distance, posKeyA, posKeyB, timestamp }
        this.lastCleanup = Date.now();
    }

    /**
     * Genera clave caché única para dos jugadores (orden-independiente).
     */
    getCacheKey(playerA, playerB) {
        if (!playerA || !playerB) return null;
        const names = [playerA, playerB].sort();
        return `${names[0]}:${names[1]}`;
    }

    getPositionKey(location, dimensionId) {
        if (!location || dimensionId === undefined) return null;
        const x = Math.round(location.x * 10);
        const z = Math.round(location.z * 10);
        return `${x}|${z}|${dimensionId}`;
    }

    /**
     * Obtiene distancia en caché si existe y la posición coincide.
     */
    getDistance(playerA, playerB, locA, locB) {
        const key = this.getCacheKey(playerA, playerB);
        if (!key) return null;

        const entry = this.cache.get(key);
        if (!entry) return null;

        if (Date.now() - entry.timestamp > CACHE_TTL_MS) {
            this.cache.delete(key);
            return null;
        }

        const posKeyA = this.getPositionKey(locA, locA?.dimensionId);
        const posKeyB = this.getPositionKey(locB, locB?.dimensionId);
        if (!posKeyA || !posKeyB) {
            this.cache.delete(key);
            return null;
        }

        if (entry.posKeyA !== posKeyA || entry.posKeyB !== posKeyB) {
            this.cache.delete(key);
            return null;
        }

        return entry.distance;
    }

    /**
     * Almacena distancia en caché.
     */
    setDistance(playerA, playerB, distance, locA, locB) {
        const key = this.getCacheKey(playerA, playerB);
        if (!key) return;

        if (this.cache.size > MAX_CACHE_ENTRIES) {
            this.cleanup();
        }

        const posKeyA = this.getPositionKey(locA, locA?.dimensionId);
        const posKeyB = this.getPositionKey(locB, locB?.dimensionId);
        this.cache.set(key, {
            distance,
            posKeyA,
            posKeyB,
            timestamp: Date.now()
        });
    }

    /**
     * Calcula y cachea distancia en una operación.
     */
    calculateAndCache(playerA, playerB, locA, locB) {
        if (!playerA || !playerB || !locA || !locB) return null;

        const dx = locB.x - locA.x;
        const dz = locB.z - locA.z;
        const distance = Math.round(Math.sqrt(dx * dx + dz * dz));

        this.setDistance(playerA, playerB, distance, locA, locB);
        return distance;
    }

    /**
     * Limpia entradas expiradas del caché.
     */
    cleanup() {
        const now = Date.now();
        let removed = 0;

        for (const [key, entry] of this.cache.entries()) {
            if (now - entry.timestamp > CACHE_TTL_MS) {
                this.cache.delete(key);
                removed++;
            }
        }

        // Si aún hay demasiadas, remover las más antiguas
        if (this.cache.size > MAX_CACHE_ENTRIES * 0.8) {
            const sorted = Array.from(this.cache.entries())
                .sort((a, b) => a[1].timestamp - b[1].timestamp);
            
            const toRemove = Math.floor(this.cache.size * 0.3);
            for (let i = 0; i < toRemove; i++) {
                this.cache.delete(sorted[i][0]);
            }
        }

        this.lastCleanup = now;
    }

    /**
     * Limpia todo el caché (por ejemplo, cuando el jugador sale).
     */
    clearPlayerCache(playerName) {
        if (!playerName) return;

        const toDelete = [];
        for (const key of this.cache.keys()) {
            if (key.includes(playerName)) {
                toDelete.push(key);
            }
        }

        for (const key of toDelete) {
            this.cache.delete(key);
        }
    }

    /**
     * Obtiene estadísticas del caché.
     */
    getStats() {
        return {
            entries: this.cache.size,
            maxEntries: MAX_CACHE_ENTRIES,
            ttlMs: CACHE_TTL_MS
        };
    }
}

// Singleton global
export const distanceCache = new DistanceCache();
