import { world, system } from "@minecraft/server";
import { GroupManager } from "../core/groupManager.js";
import { distanceCache } from "./distanceCache.js";

const allyMarkerEnabled = new Set();
const MARKER_INTERVAL_TICKS = 40;
const MAX_MARKER_DISTANCE = 120;

function getAllyType(viewer, other) {
    if (!viewer || !other || viewer.name === other.name) return null;

    const clanA = viewer.getTags().find(tag => tag.startsWith("clan:"));
    const clanB = other.getTags().find(tag => tag.startsWith("clan:"));
    if (clanA && clanB && clanA === clanB) return "clan";

    const partyA = GroupManager.getGroupId(viewer);
    const partyB = GroupManager.getGroupId(other);
    if (partyA && partyB && partyA === partyB) return "party";

    return null;
}

function getDistance(a, b) {
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    return Math.sqrt(dx * dx + dz * dz);
}

function getDirection(from, to) {
    const dx = to.x - from.x;
    const dz = to.z - from.z;
    if (Math.abs(dx) > Math.abs(dz)) {
        return dx > 0 ? "E" : "O";
    }
    return dz > 0 ? "S" : "N";
}

function getNearbyAllies(player) {
    if (!player) return [];
    const origin = player.location;
    const originDimensionId = player.dimension.id;

    return world.getPlayers()
        .filter((other) => other.name !== player.name)
        .map((other) => {
            const type = getAllyType(player, other);
            if (!type) return null;

            // Usar caché para distancia, pero validar la posición actual.
            let distance = distanceCache.getDistance(
                player.name,
                other.name,
                { x: origin.x, z: origin.z, dimensionId: originDimensionId },
                { x: other.location.x, z: other.location.z, dimensionId: other.dimension.id }
            );

            if (distance === null) {
                distance = distanceCache.calculateAndCache(
                    player.name,
                    other.name,
                    { x: origin.x, z: origin.z, dimensionId: originDimensionId },
                    { x: other.location.x, z: other.location.z, dimensionId: other.dimension.id }
                );
            }

            if (distance > MAX_MARKER_DISTANCE) return null;
            return {
                name: other.name,
                type,
                distance,
                direction: getDirection(origin, other.location),
                location: other.location
            };
        })
        .filter(Boolean)
        .sort((a, b) => a.distance - b.distance);
}

function getParticleType(type) {
    switch (type) {
        case "clan":
            return "minecraft:happy_villager";
        case "party":
            return "minecraft:heart";
        default:
            return "minecraft:end_rod";
    }
}

function spawnMarkerParticles(player, ally) {
    const particle = getParticleType(ally.type);
    const position = {
        x: ally.location.x,
        y: ally.location.y + 1.7,
        z: ally.location.z
    };
    try {
        player.dimension.spawnParticle(particle, position);
    } catch (error) {
        // Ignoramos si la particula no está disponible en esta plataforma.
    }
}

function updateMarkers() {
    for (const playerName of allyMarkerEnabled) {
        const player = world.getPlayers().find((p) => p.name === playerName);
        if (!player) {
            allyMarkerEnabled.delete(playerName);
            distanceCache.clearPlayerCache(playerName);
            continue;
        }

        const allies = getNearbyAllies(player);
        if (allies.length === 0) {
            player.onScreenDisplay.setActionBar("§7No hay aliados cercanos en rango.");
            continue;
        }

        const clanCount = allies.filter((ally) => ally.type === "clan").length;
        const partyCount = allies.filter((ally) => ally.type === "party").length;
        player.onScreenDisplay.setActionBar(`§aClan: ${clanCount} §7| §bParty: ${partyCount}`);

        allies.slice(0, 4).forEach((ally) => spawnMarkerParticles(player, ally));
    }
    
    // Limpiar caché periódicamente
    distanceCache.cleanup();
}

function scheduleMarkerUpdates() {
    if (typeof system.runInterval === "function") {
        system.runInterval(updateMarkers, MARKER_INTERVAL_TICKS);
    } else {
        system.runTimeout(() => {
            updateMarkers();
            scheduleMarkerUpdates();
        }, MARKER_INTERVAL_TICKS);
    }
}

world.afterEvents.playerLeave.subscribe((event) => {
    if (!event || !event.playerName) return;
    distanceCache.clearPlayerCache(event.playerName);
});

export function toggleAllyMarker(player) {
    if (!player) return false;
    if (allyMarkerEnabled.has(player.name)) {
        allyMarkerEnabled.delete(player.name);
        player.onScreenDisplay.setActionBar("§cMarcadores de aliados desactivados.");
        return false;
    }

    allyMarkerEnabled.add(player.name);
    player.onScreenDisplay.setActionBar("§aMarcadores de aliados activados.");
    return true;
}

export function isAllyMarkerEnabled(player) {
    return player ? allyMarkerEnabled.has(player.name) : false;
}

export function getAllyReport(player) {
    const allies = getNearbyAllies(player);
    if (allies.length === 0) {
        return ["No hay aliados cercanos en este rango."];
    }

    return allies.map((ally) => {
        const tag = ally.type === "clan" ? "§aClan" : "§bParty";
        return `${tag} §f${ally.name} §7(${ally.distance}m ${ally.direction})`;
    });
}

scheduleMarkerUpdates();
