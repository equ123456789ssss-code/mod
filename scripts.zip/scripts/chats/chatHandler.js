import { world } from "@minecraft/server";

export function setupChatHandler() {
    // En 1.26, verificamos el evento de forma más estricta
    if (!world.beforeEvents || !world.beforeEvents.chatSend) {
        console.error("❌ [Nexus] El evento chatSend no está disponible. Verifica el manifest.json.");
        return; 
    }

    world.beforeEvents.chatSend.subscribe((eventData) => {
        // En 1.26, esto es vital para evitar conflictos con otros sistemas
        if (eventData.cancel) return;
        
        const message = eventData.message;
        if (!message || message.startsWith("!") || message.startsWith("/")) return;

        const player = eventData.sender;
        const clanTag = player.getTags().find(t => t.startsWith("clan:"));
        const clanName = clanTag ? clanTag.replace("clan:", "") : "Sin Clan";

        const formattedMessage = `§7[§e${clanName}§7] §f${player.name}: §7${message}`;

        // Cancelamos el mensaje original
        eventData.cancel = true;
        
        // Enviamos el mensaje formateado
        world.sendMessage(formattedMessage);
    });
    
    console.warn("✅ [Nexus] Sistema de Chat 1.26 cargado correctamente.");
}