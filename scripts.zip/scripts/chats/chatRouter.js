import { world, system } from "@minecraft/server";
import { AntiSpam } from "./antiSpam.js";
import { ClanInvites } from "../clans/clanInvites.js";
import { ClanManager } from "../clans/clanManager.js";
import { ClanChat } from "./clanChat.js";
import { PrivateChat } from "./privateChat.js";
import { GroupManager } from "../core/groupManager.js";
import { FamiliarManager } from "../familiars/familiarManager.js";
import { showRecruitConfirm } from "../ui/familiarForms.js";
import { Database } from "../core/database.js";
import { Messages } from "../messages.js";
import { showMainClanMenu } from "../ui/clanForms.js";
import { showInboxMenu } from "../ui/inboxMenu.js";
import { showSocialHub } from "../ui/socialHub.js";
import { showWarMenu } from "../ui/warForms.js";
import { WarAdminCommands } from "../war/warAdminCommands.js";

// 1. Detección Universal del Evento de Chat
const chatEvent = (world.beforeEvents && world.beforeEvents.chatSend) 
    ? world.beforeEvents.chatSend 
    : (world.afterEvents && world.afterEvents.chatSend)
        ? world.afterEvents.chatSend
        : (world.events && world.events.beforeChat)
            ? world.events.beforeChat
            : (world.events && world.events.chat)
                ? world.events.chat
                : null;

if (chatEvent) {
    chatEvent.subscribe((event) => {
        // 2. Detección Universal del Jugador (cambia según la versión)
        const player = event.sender || event.player || event.source;
        const message = (event.message || "").trim();

        const prefix = message.charAt(0);
        if (prefix === "!" || prefix === "/") {
            // Solo intentamos cancelar si el evento lo permite
            if (event.cancel !== undefined) {
                event.cancel = true;
            }

            system.run(() => {
                const args = message.substring(1).split(" ");
                const command = args[0].toLowerCase();
                const textArgs = args.slice(1).join(" ");

                // Si no hay argumentos, abrimos el Social Hub para evitar depender de comandos.
                if (!textArgs) {
                    // Comandos que naturalmente abren menús o acciones específicas
                    switch (command) {
                        case "clan":
                            return showMainClanMenu(player);
                        case "inbox":
                        case "aceptar":
                            return showInboxMenu(player);
                        case "help":
                        case "ayuda":
                        case "comando":
                        case "comandos":
                            return showSocialHub(player);
                        case "guerra":
                        case "war":
                            return showWarMenu(player, ClanManager.getPlayerClanTag(player.name));
                        case "reclutar":
                        case "familiar":
                            return showRecruitConfirm(player);
                        case "listar":
                        case "familiares": {
                            const info = FamiliarManager.listFamiliarStatus(player.name);
                            if (!info || !info.familiars || info.familiars.length === 0) return player.sendMessage("§e[Nexus] No tienes familiares registrados.");
                            player.sendMessage(`§a[Nexus] Guard mode: ${info.guardMode ? "activado" : "desactivado"}`);
                            player.sendMessage(`§a[Nexus] Tus familiares registrados (${info.familiars.length}):`);
                            info.familiars.forEach(item => player.sendMessage(` - ${item.entityType || item.entityId} (${item.entityId}) ${item.alive ? "activo" : "no encontrado"}`));
                            return;
                        }
                        case "llamar": {
                            const res = FamiliarManager.callFamiliarsToPlayer(player.name);
                            if (!res.success) return player.sendMessage("§e[Nexus] No se encontraron familiares activos para llamar.");
                            return player.sendMessage(`§a[Nexus] ${res.called} familiar(es) han sido llamados a tu posición.`);
                        }
                        case "modo_guardia":
                        case "guardia": {
                            const mode = FamiliarManager.toggleGuardMode(player.name);
                            return player.sendMessage(`§a[Nexus] Modo guardia ${mode ? "activado" : "desactivado"}.`);
                        }
                        case "soltar": {
                            const ok = FamiliarManager.releaseFamiliarsForPlayer(player.name);
                            if (!ok) return player.sendMessage("§e[Nexus] No tienes familiares registrados para soltar.");
                            return player.sendMessage("§a[Nexus] Todos tus familiares han sido liberados.");
                        }
                        default:
                            return showSocialHub(player);
                    }
                }

                // Si hay argumentos, permitimos comportamiento legacy para compatibilidad
                switch (command) {
                    case "c":
                        ClanChat.sendMessage(player, textArgs);
                        break;
                    case "reclutar":
                    case "familiar":
                        // Mostrar confirmación UI para reclutar
                        try { showRecruitConfirm(player); } catch (e) { try { system.run(() => player.sendMessage("§c[Nexus] Error al abrir el diálogo.")); } catch (ee) {} }
                        break;
                    case "listar":
                    case "familiares": {
                        const list = FamiliarManager.listFamiliarStatus(player.name);
                        if (!list || list.length === 0) return player.sendMessage("§e[Nexus] No tienes familiares registrados.");
                        player.sendMessage(`§a[Nexus] Tus familiares registrados (${list.length}):`);
                        list.forEach(item => player.sendMessage(` - ${item.entityType || item.entityId} (${item.entityId}) ${item.alive ? "activo" : "no encontrado"}`));
                    }
                    break;
                    case "llamar": {
                        const targetId = args[1];
                        if (targetId) {
                            const ok = FamiliarManager.callFamiliarById(targetId, player.name);
                            return player.sendMessage(ok ? `§a[Nexus] Familiar ${targetId} llamado.` : `§e[Nexus] No se encontró ese familiar o no te pertenece.`);
                        }
                        const res = FamiliarManager.callFamiliarsToPlayer(player.name);
                        if (!res.success) return player.sendMessage("§e[Nexus] No se encontraron familiares activos para llamar.");
                        player.sendMessage(`§a[Nexus] ${res.called} familiar(es) han sido llamados a tu posición.`);
                    }
                    break;
                    case "modo_guardia":
                    case "guardia": {
                        const modeArg = args[1] ? args[1].toLowerCase() : null;
                        let mode;
                        if (modeArg === "on" || modeArg === "activar") mode = FamiliarManager.setGuardMode(player.name, true);
                        else if (modeArg === "off" || modeArg === "desactivar") mode = FamiliarManager.setGuardMode(player.name, false);
                        else mode = FamiliarManager.toggleGuardMode(player.name);
                        return player.sendMessage(`§a[Nexus] Modo guardia ${mode ? "activado" : "desactivado"}.`);
                    }
                    break;
                    case "soltar": {
                        const targetId = args[1];
                        if (targetId) {
                            const ok = FamiliarManager.releaseFamiliarByEntityId(targetId, player.name);
                            return player.sendMessage(ok ? `§a[Nexus] Familiar ${targetId} liberado.` : `§e[Nexus] No se encontró ese familiar o no te pertenece.`);
                        }
                        const ok = FamiliarManager.releaseFamiliarsForPlayer(player.name);
                        if (!ok) return player.sendMessage("§e[Nexus] No tienes familiares registrados para soltar.");
                        player.sendMessage("§a[Nexus] Todos tus familiares han sido liberados.");
                    }
                    break;
                    case "g":
                    case "group":
                        const members = GroupManager.getGroupMembers(player);
                        if (members.length === 0) return player.sendMessage(Messages.error("No estás en ningún grupo."));

                        const formattedMsg = `§7[§eGrupo§7] §f${player.name}§7: §f${textArgs}`;
                        members.forEach(memberName => {
                            const member = world.getPlayers().find(p => p.name === memberName);
                            if (member) member.sendMessage(formattedMsg);
                        });
                        break;
                    case "msg":
                        {
                            const targetName = args[1];
                            const privateText = args.slice(2).join(" ");
                            if (!targetName || !privateText) return player.sendMessage(Messages.error("Uso: !msg <jugador> <mensaje> o /msg <jugador> <mensaje>"));
                            PrivateChat.sendMessage(player, targetName, privateText);
                        }
                        break;
                    case "aceptar": {
                        const clanTag = args[1] ? String(args[1]).toUpperCase() : null;
                        const password = args.slice(2).join(" ").trim();
                        if (!clanTag || !password) {
                            player.sendMessage("§eUso: !aceptar <TAG> <contraseña> o /aceptar <TAG> <contraseña>");
                            return;
                        }

                        const clan = ClanManager.getClan(clanTag);
                        if (!clan) return player.sendMessage("§c[Nexus] Clan no encontrado.");
                        if (!clan.password) return player.sendMessage("§c[Nexus] Este clan no requiere contraseña. Usa una invitación.");
                        if (!ClanManager.verifyClanPassword(clanTag, password)) return player.sendMessage("§c[Nexus] Contraseña incorrecta.");

                        if (ClanManager.addMember(player.name, clanTag)) {
                            const p = world.getPlayers().find(p => p.name === player.name);
                            if (p) {
                                p.getTags().filter(t => t.startsWith("clan:")).forEach(t => p.removeTag(t));
                                p.addTag(`clan:${clanTag}`);
                            }
                            return player.sendMessage(`§a[Nexus] Te has unido al clan §b${clanTag}§a.`);
                        }
                        return player.sendMessage("§c[Nexus] No se pudo unir al clan.");
                    }
                    case "clan": {
                        const action = args[1]?.toLowerCase();
                        if (action === "join") {
                            const clanTag = args[2] ? String(args[2]).toUpperCase() : null;
                            const password = args.slice(3).join(" ").trim();
                            if (!clanTag || !password) {
                                player.sendMessage("§eUso: !clan join <TAG> <contraseña> o /clan join <TAG> <contraseña>");
                                return;
                            }

                            const clan = ClanManager.getClan(clanTag);
                            if (!clan) return player.sendMessage("§c[Nexus] Clan no encontrado.");
                            if (!clan.password) return player.sendMessage("§c[Nexus] Este clan no requiere contraseña. Usa una invitación.");
                            if (!ClanManager.verifyClanPassword(clanTag, password)) return player.sendMessage("§c[Nexus] Contraseña incorrecta.");

                            if (ClanManager.addMember(player.name, clanTag)) {
                                const p = world.getPlayers().find(p => p.name === player.name);
                                if (p) {
                                    p.getTags().filter(t => t.startsWith("clan:")).forEach(t => p.removeTag(t));
                                    p.addTag(`clan:${clanTag}`);
                                }
                                return player.sendMessage(`§a[Nexus] Te has unido al clan §b${clanTag}§a.`);
                            }
                            return player.sendMessage("§c[Nexus] No se pudo unir al clan.");
                        }

                        return showMainClanMenu(player);
                    }
                    case "r":
                    case "reply":
                        PrivateChat.replyMessage(player, textArgs);
                        break;
                    case "war-admin":
                    case "admin-guerra": {
                        const subCommand = args[1]?.toLowerCase() || "info";
                        const param1 = args[2];
                        const param2 = args[3];

                        switch (subCommand) {
                            case "info": {
                                const info = WarAdminCommands.getInfo();
                                player.sendMessage(info.formatted);
                                break;
                            }
                            case "list": {
                                player.sendMessage("§l§6OPCIONES CONFIGURABLES:");
                                const options = WarAdminCommands.listOptions();
                                for (const [key, val] of Object.entries(options)) {
                                    const current = `§e${val.current}`;
                                    const range = val.options ? `[${val.options.join(", ")}]` : `[${val.min}-${val.max}]`;
                                    player.sendMessage(`  §a${key}§7: ${val.description}\n    Actual: ${current} ${range}`);
                                }
                                break;
                            }
                            case "set": {
                                if (!param1 || !param2) {
                                    return player.sendMessage("§cUso: !war-admin set <OPCION> <valor>");
                                }
                                const result = WarAdminCommands.setConfig(player.name, param1, param2);
                                player.sendMessage(result.message);
                                if (result.success) {
                                    // Notificar a todos los admins
                                    world.getPlayers().forEach(p => {
                                        if (WarAdminCommands.isAdmin(p.name) || p.name === player.name) {
                                            p.sendMessage(`§6[Nexus Admin] ${player.name} cambió ${param1} = ${param2}`);
                                        }
                                    });
                                }
                                break;
                            }
                            case "reset": {
                                const result = WarAdminCommands.resetConfig(player.name);
                                player.sendMessage(result.message);
                                if (result.success) {
                                    world.getPlayers().forEach(p => {
                                        if (WarAdminCommands.isAdmin(p.name) || p.name === player.name) {
                                            p.sendMessage(`§6[Nexus Admin] ${player.name} reseteó la configuración de guerras`);
                                        }
                                    });
                                }
                                break;
                            }
                            case "status": {
                                const status = WarAdminCommands.getWarStatus();
                                player.sendMessage("§l§6ESTADO DE GUERRAS:");
                                player.sendMessage(status);
                                break;
                            }
                            default:
                                player.sendMessage("§cSub-comandos: info, list, set, reset, status");
                        }
                        break;
                    }
                    default:
                        player.sendMessage(Messages.error("Comando no reconocido. Usa el Social Hub (te abro el menú)."));
                        showSocialHub(player);
                }
            });
        } else {
            if (AntiSpam.isSpamming(player.name)) {
                if (event.cancel !== undefined) event.cancel = true;
                system.run(() => player.sendMessage(Messages.error("¡No hagas spam!")));
            }
        }
    });
} else {
    console.warn("⚠️ [Nexus] ERROR: No se detectó ningún evento de chat compatible en esta versión del servidor.");
}

// 3. Detección Universal para cuando un jugador sale
const leaveEvent = (world.afterEvents && world.afterEvents.playerLeave)
    ? world.afterEvents.playerLeave
    : (world.events && world.events.playerLeave)
        ? world.events.playerLeave
        : null;

if (leaveEvent) {
    leaveEvent.subscribe((event) => {
        const playerName = event.playerName;
        if (playerName) {
            AntiSpam.clearPlayer(playerName);
            PrivateChat.clearCache(playerName);
            ClanInvites.clearInvite(playerName);
        }
    });
}