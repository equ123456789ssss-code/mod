import { Config } from "../config.js";

const lastMessageTime = new Map();
const warnings = new Map();
const mutedUntil = new Map();

export const AntiSpam = {
    isMuted(playerName) {
        const until = mutedUntil.get(playerName) || 0;
        return Date.now() < until;
    },

    getMuteRemaining(playerName) {
        const until = mutedUntil.get(playerName) || 0;
        const remaining = until - Date.now();
        return remaining > 0 ? remaining : 0;
    },

    isSpamming(playerName) {
        const now = Date.now();
        if (this.isMuted(playerName)) return true;

        const last = lastMessageTime.get(playerName) || 0;
        const elapsed = now - last;

        if (elapsed < Config.CHAT_COOLDOWN_MS) {
            const count = (warnings.get(playerName) || 0) + 1;
            warnings.set(playerName, count);
            lastMessageTime.set(playerName, now);

            if (count >= Config.CHAT_WARNING_THRESHOLD) {
                mutedUntil.set(playerName, now + Config.CHAT_MUTE_DURATION_MS);
                warnings.delete(playerName);
            }

            return true;
        }

        lastMessageTime.set(playerName, now);
        warnings.delete(playerName);
        return false;
    },

    clearPlayer(playerName) {
        lastMessageTime.delete(playerName);
        warnings.delete(playerName);
        mutedUntil.delete(playerName);
    }
};
