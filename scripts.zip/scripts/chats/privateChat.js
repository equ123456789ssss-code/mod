import { world, system } from "@minecraft/server";
import { Database } from "../core/database.js";
import { showHistoryMenu } from "../ui/historyMenu.js";

const replyCache = new Map();

export const PrivateChat = {
    sendMessage(sender, targetName, message) {
        system.run(() => {
            const targetPlayer = world.getPlayers().find(p => p.name.toLowerCase() === targetName.toLowerCase());
            if (sender.name.toLowerCase() === targetName.toLowerCase()) return sender.sendMessage("§c[Nexus] §7No puedes enviarte mensajes a ti mismo.");
            if (!targetPlayer) {
                Database.addMessageToInbox(targetName, sender.name, message);
                // Registrar en historial del emisor
                try {
                    Database.appendHistory(sender.name, {
                        type: "private_message",
                        direction: "out",
                        sender: sender.name,
                        target: targetName,
                        text: message
                    });
                } catch (e) {}

                sender.sendMessage(`§a[Nexus] §e${targetName} §7no está conectado. Tu mensaje se guardó en su buzón.`);
                return;
            }

            sender.sendMessage(`§8[§dYo §8-> §d${targetPlayer.name}§8] §f${message}`);
            targetPlayer.sendMessage(`§8[§d${sender.name} §8-> §dMí§8] §f${message}`);

            // Registrar historial para ambos
            try {
                Database.appendHistory(sender.name, {
                    type: "private_message",
                    direction: "out",
                    sender: sender.name,
                    target: targetPlayer.name,
                    text: message
                });
            } catch (e) {}
            try {
                Database.appendHistory(targetPlayer.name, {
                    type: "private_message",
                    direction: "in",
                    sender: sender.name,
                    target: targetPlayer.name,
                    text: message
                });
            } catch (e) {}

            replyCache.set(sender.name, targetPlayer.name);
            replyCache.set(targetPlayer.name, sender.name);
            // Abrir historial para el emisor y receptor (rápido), si están disponibles
            try { showHistoryMenu(sender); } catch (e) {}
            try { showHistoryMenu(targetPlayer); } catch (e) {}
        });
    },
    replyMessage(sender, message) {
        const targetName = replyCache.get(sender.name);
        if (!targetName) return system.run(() => sender.sendMessage("§c[Nexus] §7Nadie a quien responder."));
        this.sendMessage(sender, targetName, message);
    },
    clearCache(playerName) {
        replyCache.delete(playerName);
    }
}