import { world } from "@minecraft/server";

export const ClanChat = {
    sendMessage(sender, message) {
        if (!sender || !message) return;

        const clanTag = sender.getTags().find(tag => tag.startsWith("clan:"));
        if (!clanTag) {
            sender.sendMessage("§c[Nexus] No perteneces a ningún clan.");
            return;
        }

        const formattedMessage = `§7[§eClan§7] §f${sender.name}: §f${message}`;
        const recipients = world.getPlayers().filter(player => player.getTags().some(tag => tag === clanTag));

        if (recipients.length === 0) {
            sender.sendMessage("§c[Nexus] No hay miembros del clan conectados.");
            return;
        }

        recipients.forEach(player => player.sendMessage(formattedMessage));
        if (!recipients.some(player => player.name === sender.name)) {
            sender.sendMessage(formattedMessage);
        }
    }
};
