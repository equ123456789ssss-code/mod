import { world } from "@minecraft/server";
import { GroupManager } from "./core/groupManager.js";
import { ClanManager } from "./clans/clanManager.js";
import { TerritoryManager } from "./territories/territoryManager.js";
import { FamiliarManager } from "./familiars/familiarManager.js";
import { PrivateChat } from "./chats/privateChat.js";
import { Database } from "./core/database.js";
import { setupChatHandler } from "./chats/chatHandler.js";
import { WarDeathSystem } from "./war/warDeathSystem.js";
import "./territories/buildProtection.js";
import "./events/loginNotify.js";
import "./teams/teamDamageSystem.js"; 
import "./ui/teamMenu.js";  
import "./items/itemRouter.js";
import "./chats/chatRouter.js";

// CORRECCIÓN 1: Cuando el jugador se va, su objeto ya no existe. Usamos playerName.
world.afterEvents.playerLeave.subscribe((event) => {
    // Nos aseguramos de pasarle el nombre en lugar de un objeto indefinido
    GroupManager.leaveGroup(event.playerName); 
});

// CORRECCIÓN 2: Usamos playerSpawn para que el mensaje llegue cuando el jugador ya está en el mundo (Línea 19 arreglada)
world.afterEvents.playerSpawn.subscribe((event) => {
    if (event.initialSpawn) {
        event.player.sendMessage("§a[Nexus] Bienvenido. Usa !help o /help para ver comandos rápidos.");
    }
});

world.afterEvents.worldInitialize.subscribe(() => {
    // Normalizar datos antiguos de clanes antes de inicializar cachés
    const migrated = Database.migrateClans();
    if (Array.isArray(migrated) && migrated.length) {
        console.warn(`[Database] Migrated clans: ${migrated.join(', ')}`);
    }
    ClanManager.initCache();
    try { FamiliarManager.init(); } catch (e) {}
    try { WarDeathSystem.init(); } catch (e) {}
    TerritoryManager.initCache();
        try {
    if (typeof setupChatHandler === 'function') {
        setupChatHandler();
    }
} catch (error) {
    console.error("❌ Fallo crítico en el sistema de chat: " + error);
}

    console.warn("[Nexus] Ecosistema UI y sistemas cargados.");
});