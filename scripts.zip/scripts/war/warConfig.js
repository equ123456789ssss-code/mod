import { Database } from "../core/database.js";
import { WarManager } from "./warManager.js";

const CONFIG_KEY = "nexus_war_config_v1";

export const WarConfig = {
    // Valores por defecto
    DEFAULTS: {
        WINNING_POINTS: 10,
        MAX_DURATION_MINUTES: 1440, // 24 horas
        KILL_POINTS: 1,
        ASSIST_POINTS: 0.5,
        STREAK_2_BONUS: 1,
        STREAK_3_BONUS: 2,
        STREAK_4_PLUS_BONUS: 3,
        ENABLED: true
    },

    /**
     * Obtiene la configuración actual de guerras
     */
    getConfig() {
        const config = Database.get(CONFIG_KEY, null);
        if (!config || typeof config !== "object") {
            // Si no existe, crear con valores por defecto
            this.saveConfig(this.DEFAULTS);
            return { ...this.DEFAULTS };
        }
        return config;
    },

    /**
     * Guarda la configuración (solo si no hay guerras activas)
     */
    saveConfig(config) {
        if (!config || typeof config !== "object") {
            return { success: false, error: "Configuración inválida." };
        }

        // Validar que no hay guerras activas
        const activeWars = WarManager.getActiveWars();
        if (Array.isArray(activeWars) && activeWars.length > 0) {
            return {
                success: false,
                error: "No se puede editar la configuración mientras hay guerras activas. Finaliza todas las guerras primero."
            };
        }

        Database.set(CONFIG_KEY, config);
        return { success: true, config };
    },

    /**
     * Actualiza un solo valor de configuración
     */
    updateConfig(key, value) {
        const config = this.getConfig();

        // Validar que no hay guerras activas
        const activeWars = WarManager.getActiveWars();
        if (Array.isArray(activeWars) && activeWars.length > 0) {
            return {
                success: false,
                error: "No se puede editar la configuración mientras hay guerras activas."
            };
        }

        // Validar inputs según el tipo
        if (key === "WINNING_POINTS") {
            const num = Number(value);
            if (isNaN(num) || num < 1 || num > 100) {
                return { success: false, error: "Puntos para ganar debe estar entre 1 y 100." };
            }
            config.WINNING_POINTS = num;
        } else if (key === "MAX_DURATION_MINUTES") {
            const num = Number(value);
            if (isNaN(num) || num < 5 || num > 10080) { // 5 minutos a 7 días
                return { success: false, error: "Duración debe estar entre 5 minutos y 7 días (10080 min)." };
            }
            config.MAX_DURATION_MINUTES = num;
        } else if (key === "KILL_POINTS") {
            const num = Number(value);
            if (isNaN(num) || num < 0.1 || num > 10) {
                return { success: false, error: "Puntos por kill deben estar entre 0.1 y 10." };
            }
            config.KILL_POINTS = num;
        } else if (key === "ASSIST_POINTS") {
            const num = Number(value);
            if (isNaN(num) || num < 0 || num > 5) {
                return { success: false, error: "Puntos de asistencia deben estar entre 0 y 5." };
            }
            config.ASSIST_POINTS = num;
        } else if (key === "STREAK_2_BONUS") {
            const num = Number(value);
            if (isNaN(num) || num < 0 || num > 20) {
                return { success: false, error: "Bonus 2x debe estar entre 0 y 20." };
            }
            config.STREAK_2_BONUS = num;
        } else if (key === "STREAK_3_BONUS") {
            const num = Number(value);
            if (isNaN(num) || num < 0 || num > 20) {
                return { success: false, error: "Bonus 3x debe estar entre 0 y 20." };
            }
            config.STREAK_3_BONUS = num;
        } else if (key === "STREAK_4_PLUS_BONUS") {
            const num = Number(value);
            if (isNaN(num) || num < 0 || num > 20) {
                return { success: false, error: "Bonus 4x+ debe estar entre 0 y 20." };
            }
            config.STREAK_4_PLUS_BONUS = num;
        } else if (key === "ENABLED") {
            config.ENABLED = value === true || value === "true" || value === 1 || value === "1";
        } else {
            return { success: false, error: `Opción desconocida: ${key}` };
        }

        Database.set(CONFIG_KEY, config);
        return { success: true, config, updated: key };
    },

    /**
     * Resetea la configuración a valores por defecto
     */
    resetConfig() {
        // Validar que no hay guerras activas
        const activeWars = WarManager.getActiveWars();
        if (Array.isArray(activeWars) && activeWars.length > 0) {
            return {
                success: false,
                error: "No se puede resetear la configuración mientras hay guerras activas."
            };
        }

        this.saveConfig({ ...this.DEFAULTS });
        return { success: true, config: this.DEFAULTS };
    },

    /**
     * Obtiene descripción formateada de la configuración
     */
    getConfigInfo() {
        const config = this.getConfig();
        const durationHours = Math.floor(config.MAX_DURATION_MINUTES / 60);
        const durationMins = config.MAX_DURATION_MINUTES % 60;
        const durationText = durationHours > 0
            ? `${durationHours}h ${durationMins}m`
            : `${durationMins}m`;

        return {
            status: config.ENABLED ? "§aHabilitado" : "§cDeshabilitado",
            winningPoints: config.WINNING_POINTS,
            maxDuration: durationText,
            maxDurationMinutes: config.MAX_DURATION_MINUTES,
            killPoints: config.KILL_POINTS,
            assistPoints: config.ASSIST_POINTS,
            streak2Bonus: config.STREAK_2_BONUS,
            streak3Bonus: config.STREAK_3_BONUS,
            streak4PlusBonus: config.STREAK_4_PLUS_BONUS,
            formatted: [
                `§l§6CONFIGURACIÓN DE GUERRAS`,
                `Estado: ${config.ENABLED ? "§aHabilitado" : "§cDeshabilitado"}`,
                `Puntos para ganar: §e${config.WINNING_POINTS}`,
                `Duración máxima: §e${durationText}`,
                ``,
                `§l§ePuntos:`,
                `  Kill: §a${config.KILL_POINTS}`,
                `  Asistencia: §a${config.ASSIST_POINTS}`,
                `  Racha 2x: §6+${config.STREAK_2_BONUS}`,
                `  Racha 3x: §6+${config.STREAK_3_BONUS}`,
                `  Racha 4x+: §6+${config.STREAK_4_PLUS_BONUS}`
            ].join("\n")
        };
    }
};
