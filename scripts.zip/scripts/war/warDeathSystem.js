import { world } from "@minecraft/server";
import { WarManager } from "./warManager.js";
import { WarConfig } from "./warConfig.js";
import { ClanManager } from "../clans/clanManager.js";
import { TeamDamageSystem } from "../teams/teamDamageSystem.js";
import { Database } from "../core/database.js";

const KILL_STREAK_KEY = "nexus_kill_streaks_v1";
const LAST_DAMAGERS_KEY = "nexus_last_damagers_v1";

function normalizeClanTag(tag) {
    return String(tag || "").trim().toUpperCase() || null;
}

export const WarDeathSystem = {
    init() {
        world.afterEvents.entityDie.subscribe((event) => {
            this.onPlayerDeath(event.deadEntity);
        });
        world.afterEvents.entityHurt.subscribe((event) => {
            this.recordDamage(event.hurtEntity, event.damageSource);
        });
    },

    getKillStreaks() {
        const streaks = Database.get(KILL_STREAK_KEY, {});
        return typeof streaks === "object" ? streaks : {};
    },

    saveKillStreaks(streaks) {
        Database.set(KILL_STREAK_KEY, streaks);
    },

    getLastDamagers() {
        const damagers = Database.get(LAST_DAMAGERS_KEY, {});
        return typeof damagers === "object" ? damagers : {};
    },

    saveLastDamagers(damagers) {
        Database.set(LAST_DAMAGERS_KEY, damagers);
    },

    recordDamage(damagedEntity, damageSource) {
        if (!damagedEntity || damagedEntity.typeId !== "minecraft:player") return;
        
        const damagers = this.getLastDamagers();
        const key = damagedEntity.id;
        
        if (!Array.isArray(damagers[key])) {
            damagers[key] = [];
        }

        // Resolver quién atacó
        const attacker = TeamDamageSystem.resolveDamager(damageSource);
        if (attacker && attacker.typeId === "minecraft:player") {
            damagers[key].push({
                playerName: attacker.name,
                timestamp: Date.now()
            });

            // Mantener solo últimos 5 segundos
            damagers[key] = damagers[key].filter(d => Date.now() - d.timestamp < 5000);
        }

        this.saveLastDamagers(damagers);
    },

    onPlayerDeath(deadEntity) {
        if (!deadEntity || deadEntity.typeId !== "minecraft:player") return;

        const deadPlayer = deadEntity;
        const deadClan = normalizeClanTag(
            ClanManager.getPlayerClanTag(deadPlayer.name)
        );

        if (!deadClan) return;

        // Resolver atacante principal
        const attacker = TeamDamageSystem.resolveDamager(deadEntity.lastHurtBy || deadEntity);
        if (!attacker || attacker.typeId !== "minecraft:player") return;

        const attackerClan = normalizeClanTag(
            ClanManager.getPlayerClanTag(attacker.name)
        );

        if (!attackerClan) return;

        // No dar puntos si son aliados
        if (TeamDamageSystem.areAllies(deadEntity, attacker)) return;

        // Buscar guerra activa entre los dos clanes
        const war = WarManager.getWarBetween(deadClan, attackerClan);
        if (!war || !war.active) return;

        // OBTENER CONFIGURACIÓN DINÁMICA
        const config = WarConfig.getConfig();

        // === MANEJAR KILL ===
        const killStreaks = this.getKillStreaks();
        const killerKey = attacker.name;
        const currentStreak = killStreaks[killerKey] || 0;
        const newStreak = currentStreak + 1;
        killStreaks[killerKey] = newStreak;
        this.saveKillStreaks(killStreaks);

        let killPoints = config.KILL_POINTS;

        // BONIFICACIÓN POR RACHA
        let streakBonus = 0;
        if (newStreak === 2) {
            streakBonus = config.STREAK_2_BONUS;
            attacker.sendMessage(`§l§6⚡ DOBLE KILL §r§7(+${streakBonus} puntos bonus)`);
        } else if (newStreak === 3) {
            streakBonus = config.STREAK_3_BONUS;
            attacker.sendMessage(`§l§c🔥 TRIPLE KILL §r§7(+${streakBonus} puntos bonus)`);
        } else if (newStreak >= 4) {
            streakBonus = config.STREAK_4_PLUS_BONUS;
            attacker.sendMessage(`§l§4💥 MEGA KILL (${newStreak}x) §r§7(+${streakBonus} puntos bonus)`);
        }

        killPoints += streakBonus;

        // Registrar puntos al clan atacante
        WarManager.recordVictory(war.id, attackerClan, killPoints);

        // Mensaje al atacante
        attacker.sendMessage(
            `§l§6+${killPoints} Punto de Guerra§r\n§7Racha: §b${newStreak}x`
        );

        // === ASISTENCIA ===
        const damagers = this.getLastDamagers();
        const deadEntityKey = deadEntity.id;
        const recentDamagers = (damagers[deadEntityKey] || [])
            .filter(d => d.playerName !== attacker.name);

        if (recentDamagers.length > 0) {
            const assistantName = recentDamagers[recentDamagers.length - 1].playerName;
            const assistantPlayer = world.getPlayers().find(
                p => p.name.toLowerCase() === assistantName.toLowerCase()
            );
            
            if (assistantPlayer) {
                const assistantClan = normalizeClanTag(
                    ClanManager.getPlayerClanTag(assistantName)
                );

                // Dar asistencia solo si está en la misma guerra
                if (assistantClan === attackerClan) {
                    const assistPoints = config.ASSIST_POINTS;
                    WarManager.recordVictory(war.id, assistantClan, assistPoints);
                    
                    assistantPlayer.sendMessage(
                        `§l§e+${assistPoints} Asistencia§r\n§7Ayudaste a matar a ${deadPlayer.name}`
                    );
                }
            }
        }

        // Limpiar racha del muerto
        killStreaks[deadPlayer.name] = 0;
        this.saveKillStreaks(killStreaks);

        // Limpiar registro de damagers
        if (damagers[deadEntityKey]) {
            delete damagers[deadEntityKey];
        }
        this.saveLastDamagers(damagers);

        // Verificar si alguien ganó
        this.checkWarWinner(war, config);
    },

    checkWarWinner(war, config) {
        if (!war || !war.score) return;
        if (!config) config = WarConfig.getConfig();

        for (const [clan, points] of Object.entries(war.score)) {
            if (points >= config.WINNING_POINTS) {
                // ¡GUERRA TERMINADA! Hay un ganador
                const result = WarManager.endWarWithWinner(war.id, clan);
                
                if (result.success) {
                    const winningClanData = ClanManager.getClan(clan);
                    const losingClan = war.clans.find(c => c !== clan);

                    // Notificar a líderes
                    try {
                        const winnerLeader = winningClanData && winningClanData.leader;
                        const loserData = ClanManager.getClan(losingClan);
                        const loserLeader = loserData && loserData.leader;

                        if (winnerLeader) {
                            Database.addMessageToInbox(
                                winnerLeader,
                                "Sistema",
                                `🎉 ¡Victoria en la guerra ${war.id}! Puntuación final: ${points}-${war.score[losingClan]}`,
                                "war_won",
                                { warId: war.id, winner: clan, finalScore: war.score }
                            );
                        }

                        if (loserLeader) {
                            Database.addMessageToInbox(
                                loserLeader,
                                "Sistema",
                                `⚔️ Derrota en la guerra ${war.id}. Puntuación final: ${war.score[losingClan]}-${points}`,
                                "war_lost",
                                { warId: war.id, loser: losingClan, finalScore: war.score }
                            );
                        }
                    } catch (e) {}
                }
            }
        }
    }
};
