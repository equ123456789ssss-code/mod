import { world } from "@minecraft/server";
import { WarConfig } from "./warConfig.js";
import { WarManager } from "./warManager.js";

/**
 * Comandos de administración para configurar las guerras
 * Solo para admins/operadores
 */

export const WarAdminCommands = {
    /**
     * Verifica si el jugador es admin/operador
     */
    isAdmin(playerName) {
        if (!playerName || !world.getPlayers) return false;
        const player = world.getPlayers().find(p => p.name === playerName);
        if (!player || typeof player.getTags !== "function") return false;
        return Array.isArray(player.getTags()) && player.getTags().includes("nexus_admin");
    },

    /**
     * Obtiene información de la configuración actual
     */
    getInfo() {
        return WarConfig.getConfigInfo();
    },

    /**
     * Intenta cambiar un valor de configuración
     * Retorna { success, message, config }
     */
    setConfig(playerName, key, value) {
        if (!this.isAdmin(playerName)) {
            return {
                success: false,
                message: "§c❌ Solo admins pueden cambiar la configuración."
            };
        }

        const result = WarConfig.updateConfig(key, value);
        
        if (!result.success) {
            return {
                success: false,
                message: `§c❌ ${result.error}`
            };
        }

        return {
            success: true,
            message: `§a✓ Configuración actualizada: ${key} = ${value}`,
            config: result.config
        };
    },

    /**
     * Lista todas las opciones configurables
     */
    listOptions() {
        const config = WarConfig.getConfig();
        return {
            "WINNING_POINTS": {
                description: "Puntos requeridos para ganar una guerra",
                current: config.WINNING_POINTS,
                min: 1,
                max: 100
            },
            "MAX_DURATION_MINUTES": {
                description: "Duración máxima de una guerra en minutos",
                current: config.MAX_DURATION_MINUTES,
                min: 5,
                max: 10080
            },
            "KILL_POINTS": {
                description: "Puntos por matar a un enemigo",
                current: config.KILL_POINTS,
                min: 0.1,
                max: 10
            },
            "ASSIST_POINTS": {
                description: "Puntos por asistencia en una muerte",
                current: config.ASSIST_POINTS,
                min: 0,
                max: 5
            },
            "STREAK_2_BONUS": {
                description: "Bonus por doble kill (racha 2x)",
                current: config.STREAK_2_BONUS,
                min: 0,
                max: 20
            },
            "STREAK_3_BONUS": {
                description: "Bonus por triple kill (racha 3x)",
                current: config.STREAK_3_BONUS,
                min: 0,
                max: 20
            },
            "STREAK_4_PLUS_BONUS": {
                description: "Bonus por mega kill (racha 4x+)",
                current: config.STREAK_4_PLUS_BONUS,
                min: 0,
                max: 20
            },
            "ENABLED": {
                description: "Habilitar/deshabilitar sistema de guerras",
                current: config.ENABLED ? "true" : "false",
                options: ["true", "false"]
            }
        };
    },

    /**
     * Resetea la configuración a valores por defecto
     */
    resetConfig(playerName) {
        if (!this.isAdmin(playerName)) {
            return {
                success: false,
                message: "§c❌ Solo admins pueden resetear la configuración."
            };
        }

        const result = WarConfig.resetConfig();
        
        if (!result.success) {
            return {
                success: false,
                message: `§c❌ ${result.error}`
            };
        }

        return {
            success: true,
            message: "§a✓ Configuración reseteada a valores por defecto",
            config: result.config
        };
    },

    /**
     * Obtiene descripción de un parámetro específico
     */
    getOptionInfo(optionName) {
        const options = this.listOptions();
        return options[optionName] || null;
    },

    /**
     * Obtiene estado de guerras activas
     */
    getWarStatus() {
        const activeWars = WarManager.getActiveWars();
        if (!Array.isArray(activeWars) || activeWars.length === 0) {
            return "§eNo hay guerras activas.";
        }

        return activeWars.map((war, idx) => {
            const scoreText = war.clans.map(c => `${c}:${war.score[c] || 0}`).join(" vs ");
            return `§e${idx + 1}. ${war.id} - ${scoreText}`;
        }).join("\n");
    }
};

/**
 * Ejemplo de uso en comandos:
 * 
 * !war-admin info          → Muestra configuración actual
 * !war-admin set WINNING_POINTS 15  → Cambia puntos a 15
 * !war-admin reset         → Resetea a defecto
 * !war-admin list          → Lista todas las opciones
 */
