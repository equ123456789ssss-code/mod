import { Database } from "../core/database.js";
import { ClanManager } from "../clans/clanManager.js";

const REQUEST_KEY = "nexus_war_requests_v1";
const ACTIVE_KEY = "nexus_active_wars_v1";
const FINISHED_KEY = "nexus_finished_wars_v1";
const REQUEST_TTL_MS = 1000 * 60 * 60 * 24; // 24 horas
const FINISHED_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 días

export const WarManager = {
    _normalizeClan(clanTag) {
        if (!clanTag) return null;
        return String(clanTag).toUpperCase();
    },

    _buildWarId(clanA, clanB) {
        const a = this._normalizeClan(clanA);
        const b = this._normalizeClan(clanB);
        if (!a || !b) return null;
        return [a, b].sort().join("::");
    },

    _now() {
        return Date.now();
    },

    getWarRequests() {
        const requests = Database.getWithTTL(REQUEST_KEY, []);
        if (!Array.isArray(requests)) return [];
        return requests;
    },

    saveWarRequests(requests) {
        if (!Array.isArray(requests)) return;
        Database.setWithTTL(REQUEST_KEY, requests, REQUEST_TTL_MS);
    },

    getActiveWars() {
        const wars = Database.get(ACTIVE_KEY, []);
        if (!Array.isArray(wars)) return [];
        return wars;
    },

    saveActiveWars(wars) {
        if (!Array.isArray(wars)) return;
        Database.set(ACTIVE_KEY, wars);
    },

    getPendingRequestsForClan(clanTag) {
        const tag = this._normalizeClan(clanTag);
        if (!tag) return [];
        return this.getWarRequests().filter(req => req.status === "pending" && req.toClan === tag);
    },

    getOutgoingRequestsForClan(clanTag) {
        const tag = this._normalizeClan(clanTag);
        if (!tag) return [];
        return this.getWarRequests().filter(req => req.status === "pending" && req.fromClan === tag);
    },

    getWarRequestById(requestId) {
        if (!requestId) return null;
        return this.getWarRequests().find(req => req.id === requestId) || null;
    },

    _buildRequestId(fromClan, toClan) {
        const from = this._normalizeClan(fromClan);
        const to = this._normalizeClan(toClan);
        if (!from || !to) return null;
        return `${from}->${to}@${this._now()}`;
    },

    _getWarById(warId) {
        if (!warId) return null;
        return this.getActiveWars().find(w => w.id === warId) || null;
    },

    createWarRequest(fromClan, toClan, type = "declare", warId = null) {
        const from = this._normalizeClan(fromClan);
        const to = this._normalizeClan(toClan);
        const requestType = String(type || "").toLowerCase();
        const requestWarId = requestType === "ally" ? String(warId || "").trim() : null;

        if (!from || !to || from === to) return { success: false, error: "Clanes inválidos." };
        if (!["declare", "ally"].includes(requestType)) return { success: false, error: "Tipo de solicitud inválido." };
        if (requestType === "ally" && !requestWarId) return { success: false, error: "ID de guerra inválido para solicitud de ayuda." };

        try {
            const a = ClanManager.getClan(from);
            const b = ClanManager.getClan(to);
            if (!a || !b) return { success: false, error: "Uno o ambos clanes no existen." };
        } catch (e) {
            return { success: false, error: "Error al validar clanes." };
        }

        if (requestType === "declare") {
            const active = this.getWarBetween(from, to);
            if (active) return { success: false, error: "Ya existe una guerra activa entre estos clanes." };
        }

        if (requestType === "ally") {
            const war = this._getWarById(requestWarId);
            if (!war || !war.active) return { success: false, error: "Guerra activa no encontrada." };
            if (!Array.isArray(war.clans) || !war.clans.includes(from)) return { success: false, error: "Solo un clan participante puede solicitar ayuda." };
            if (war.clans.includes(to)) return { success: false, error: "Ese clan ya participa en la guerra." };
            const allies = ClanManager.getAllies(from) || [];
            if (!allies.map(a => String(a).toUpperCase()).includes(to)) return { success: false, error: "El clan objetivo no es aliado." };
        }

        const requests = this.getWarRequests();
        const duplicate = requests.some(req => req.status === "pending" && req.fromClan === from && req.toClan === to && req.type === requestType && req.warId === requestWarId);
        if (duplicate) return { success: false, error: "Ya existe una solicitud de guerra pendiente similar." };

        const id = this._buildRequestId(from, to);
        const request = {
            id,
            fromClan: from,
            toClan: to,
            type: requestType,
            warId: requestType === "ally" ? requestWarId : null,
            status: "pending",
            createdAt: this._now()
        };

        requests.push(request);
        this.saveWarRequests(requests);
        try {
            const targetClan = ClanManager.getClan(to);
            const leader = targetClan && targetClan.leader ? targetClan.leader : null;
            if (leader) {
                const text = request.type === "ally"
                    ? `Clan ${from} solicita ayuda en la guerra ${request.warId}.`
                    : `Clan ${from} te ha declarado la guerra.`;
                Database.addMessageToInbox(leader, from, text, request.type === "ally" ? "ally_request" : "war_request", { requestId: id, warId: request.warId });
            }
        } catch (e) {}
        return { success: true, request };
    },

    acceptWarRequest(requestId) {
        const requests = this.getWarRequests();
        const request = requests.find(req => req.id === requestId && req.status === "pending");
        if (!request) return { success: false, error: "Solicitud inválida." };

        if (request.type === "ally") {
            const war = this._getWarById(request.warId);
            if (!war) return { success: false, error: "Guerra activa no encontrada." };
            if (war.clans.includes(request.toClan)) return { success: false, error: "Ese clan ya participa en la guerra." };
            war.clans.push(request.toClan);
            war.score[request.toClan] = 0;
            war.lastUpdate = this._now();
            this.saveActiveWars(this.getActiveWars());
            const filtered = requests.filter(req => req.id !== requestId);
            this.saveWarRequests(filtered);
            // Notificar al solicitante que su ayuda fue aceptada
            try {
                const fromClanData = ClanManager.getClan(request.fromClan);
                const fromLeader = fromClanData && fromClanData.leader ? fromClanData.leader : null;
                if (fromLeader) {
                    Database.addMessageToInbox(fromLeader, request.toClan, `Tu solicitud de ayuda para la guerra ${request.warId} ha sido aceptada por ${request.toClan}.`, "ally_accepted", { warId: request.warId, requestId: request.id });
                }
            } catch (e) {}
            return { success: true, war };
        }

        const warId = this._buildWarId(request.fromClan, request.toClan);
        const active = this.getActiveWars();
        if (active.some(w => w.id === warId)) return { success: false, error: "Ya existe una guerra activa." };

        const war = {
            id: warId,
            clans: [request.fromClan, request.toClan],
            score: {
                [request.fromClan]: 0,
                [request.toClan]: 0
            },
            startedAt: this._now(),
            lastUpdate: this._now(),
            active: true
        };

        active.push(war);
        this.saveActiveWars(active);
        const filtered = requests.filter(req => req.id !== requestId);
        this.saveWarRequests(filtered);

        // Notificar a los líderes de ambos clanes de la nueva guerra
        try {
            const a = ClanManager.getClan(request.fromClan);
            const b = ClanManager.getClan(request.toClan);
            const la = a && a.leader ? a.leader : null;
            const lb = b && b.leader ? b.leader : null;
            const text = `La guerra ${war.id} ha comenzado entre ${request.fromClan} y ${request.toClan}.`;
            if (la) Database.addMessageToInbox(la, "Sistema", text, "war_started", { warId: war.id });
            if (lb) Database.addMessageToInbox(lb, "Sistema", text, "war_started", { warId: war.id });
        } catch (e) {}

        return { success: true, war };
    },

    rejectWarRequest(requestId) {
        const requests = this.getWarRequests();
        const request = requests.find(req => req.id === requestId && req.status === "pending");
        if (!request) return { success: false, error: "Solicitud inválida." };
        const filtered = requests.filter(req => req.id !== requestId);
        this.saveWarRequests(filtered);
        // Notificar al solicitante que su solicitud fue rechazada
        try {
            const fromClan = ClanManager.getClan(request.fromClan);
            const leader = fromClan && fromClan.leader ? fromClan.leader : null;
            if (leader) {
                Database.addMessageToInbox(leader, request.toClan, `Tu solicitud (${request.type}) fue rechazada por ${request.toClan}.`, "request_rejected", { requestId: request.id, type: request.type, warId: request.warId });
            }
        } catch (e) {}
        return { success: true };
    },

    cancelWarRequest(requestId, clanTag) {
        const requests = this.getWarRequests();
        const request = requests.find(req => req.id === requestId && req.status === "pending");
        if (!request) return { success: false, error: "Solicitud inválida." };
        const normalized = this._normalizeClan(clanTag);
        if (!normalized || request.fromClan !== normalized) return { success: false, error: "Solo el clan solicitante puede cancelar esta solicitud." };

        const filtered = requests.filter(req => req.id !== requestId);
        this.saveWarRequests(filtered);

        try {
            const targetClan = ClanManager.getClan(request.toClan);
            const targetLeader = targetClan && targetClan.leader ? targetClan.leader : null;
            if (targetLeader) {
                Database.addMessageToInbox(targetLeader, request.fromClan, `La solicitud de ${request.type} de ${request.fromClan} ha sido cancelada.`, "request_canceled", { requestId: request.id, type: request.type, warId: request.warId });
            }
        } catch (e) {}

        return { success: true };
    },

    getWarBetween(clanA, clanB) {
        const a = this._normalizeClan(clanA);
        const b = this._normalizeClan(clanB);
        if (!a || !b) return null;
        return this.getActiveWars().find(w => Array.isArray(w.clans) && w.clans.includes(a) && w.clans.includes(b)) || null;
    },

    getFinishedWars() {
        const wars = Database.getWithTTL(FINISHED_KEY, []);
        if (!Array.isArray(wars)) return [];
        return wars;
    },

    saveFinishedWars(wars) {
        if (!Array.isArray(wars)) return;
        Database.setWithTTL(FINISHED_KEY, wars, FINISHED_TTL_MS);
    },

    determineWinner(warId) {
        if (!warId) return null;
        const active = this.getActiveWars();
        const finished = this.getFinishedWars();
        const war = active.find(w => w.id === warId) || finished.find(w => w.id === warId);
        if (!war || !war.score || !Array.isArray(war.clans)) return null;

        const scores = war.clans.map(clan => ({ clan, points: war.score[clan] || 0 }));
        scores.sort((a, b) => b.points - a.points);

        if (scores.length === 0) return null;
        
        const [first, second] = scores;
        return {
            winner: first.clan,
            winnerPoints: first.points,
            finalScore: war.score,
            isTie: second && first.points === second.points,
            allScores: scores
        };
    },

    recordFinishedWar(warId, winner, finalScore) {
        if (!warId || !finalScore) return { success: false };
        
        const active = this.getActiveWars();
        const war = active.find(w => w.id === warId);
        if (!war) return { success: false };

        const finished = this.getFinishedWars();
        const finishedWar = {
            ...war,
            winner: winner ? this._normalizeClan(winner) : null,
            tie: !winner,
            finalScore: finalScore,
            finishedAt: this._now(),
            active: false
        };

        finished.push(finishedWar);
        this.saveFinishedWars(finished);
        return { success: true, finishedWar };
    },

    endWarWithAutoResult(warId) {
        if (!warId) return { success: false, error: "Parámetro inválido." };

        const war = this._getWarById(warId);
        if (!war) return { success: false, error: "Guerra no encontrada." };

        const result = this.determineWinner(warId);
        const winner = result && !result.isTie ? result.winner : null;
        const recordResult = this.recordFinishedWar(warId, winner, war.score);
        if (!recordResult.success) return { success: false, error: "No se pudo registrar la guerra finalizada." };

        const active = this.getActiveWars();
        const index = active.findIndex(w => w.id === warId);
        if (index !== -1) {
            active.splice(index, 1);
            this.saveActiveWars(active);
        }

        return { success: true, winner, finalScore: war.score, tie: !winner };
    },

    getWarHistory(clanTag) {
        const tag = this._normalizeClan(clanTag);
        if (!tag) return [];
        const finished = this.getFinishedWars();
        return finished.filter(w => Array.isArray(w.clans) && w.clans.includes(tag));
    },

    getWarStats(clanTag) {
        const tag = this._normalizeClan(clanTag);
        if (!tag) return { wins: 0, losses: 0, totalWars: 0, winRate: 0 };
        const history = this.getWarHistory(tag);
        const wins = history.filter(w => w.winner === tag).length;
        const losses = history.length - wins;
        const winRate = history.length > 0 ? Math.round((wins / history.length) * 100) : 0;
        return {
            wins,
            losses,
            totalWars: history.length,
            winRate,
            history
        };
    },

    getWarsForClan(clanTag) {
        const tag = this._normalizeClan(clanTag);
        if (!tag) return [];
        return this.getActiveWars().filter(w => Array.isArray(w.clans) && w.clans.includes(tag));
    },

    recordVictory(warId, winningClan, points = 1) {
        if (!warId || !winningClan) return { success: false, error: "Parámetros inválidos." };
        const active = this.getActiveWars();
        const war = active.find(w => w.id === warId && w.active);
        if (!war) return { success: false, error: "Guerra no encontrada." };
        const clan = this._normalizeClan(winningClan);
        if (!war.clans.includes(clan)) return { success: false, error: "Clan no participa en esta guerra." };
        if (!war.score) war.score = {};
        const pointsNum = typeof points === "number" && points > 0 ? points : 1;
        war.score[clan] = (typeof war.score[clan] === "number" ? war.score[clan] : 0) + pointsNum;
        war.lastUpdate = this._now();
        this.saveActiveWars(active);
        return { success: true, war };
    },

    endWar(warId) {
        if (!warId) return { success: false, error: "Parámetro inválido." };
        const active = this.getActiveWars();
        const index = active.findIndex(w => w.id === warId);
        if (index === -1) return { success: false, error: "Guerra no encontrada." };
        const war = active[index];
        active.splice(index, 1);
        this.saveActiveWars(active);
        return { success: true, war };
    },
};
