import { world } from "@minecraft/server";
import { Database } from "../core/database.js";
import { claimCache } from "../territories/territoryManager.js";

export const playerClanCache = new Map();

function updatePlayerClanTag(playerName, clanTag) {
    const player = world.getPlayers().find((p) => p.name === playerName);
    if (!player) return;
    player.getTags().filter((t) => t.startsWith("clan:")).forEach((t) => player.removeTag(t));
    if (clanTag) player.addTag(`clan:${clanTag}`);
}

function clearPlayerClanTag(playerName) {
    updatePlayerClanTag(playerName, null);
}

function normalizeClanData(clan) {
    if (!clan || !clan.members) return clan;
    if (Array.isArray(clan.members)) {
        const membersObj = {};
        for (const playerName of clan.members) {
            membersObj[playerName] = { role: playerName === clan.leader ? "leader" : "member", joinedAt: Date.now() };
        }
        clan.members = membersObj;
    }
    return clan;
}

export const ClanManager = {
    initCache() {
        const clanTags = Database.getAllClans();
        for (const tag of clanTags) {
            const clanData = normalizeClanData(Database.getClanData(tag));
            if (clanData && clanData.members) {
                Database.saveClanData(tag, clanData);
                Object.keys(clanData.members).forEach(playerName => {
                    playerClanCache.set(playerName, tag);
                });
            }
        }
    },
    createClan(tag, name, leaderName, password = null, icon = null) {
        const upperTag = String(tag).toUpperCase();
        const clanTags = Database.getAllClans();

        if (clanTags.includes(upperTag) || playerClanCache.has(leaderName)) return false;

        const newClan = {
            tag: upperTag,
            name: name,
            leader: leaderName,
            creationDate: Date.now(),
            members: {},
            claims: [], // Inicialización limpia de la base de reclamos interna
            claimLimit: 10, // Límite configurable de chunks por clan
            password: password ? String(password) : null,
            icon: icon ? String(icon).trim() : "⚔️"
        };

        newClan.members[leaderName] = { role: "leader", joinedAt: Date.now() };

        clanTags.push(upperTag);
        Database.saveClanList(clanTags);
        Database.saveClanData(upperTag, newClan);
        playerClanCache.set(leaderName, upperTag);
        updatePlayerClanTag(leaderName, upperTag);
        
        return true;
    },

    verifyClanPassword(tag, password) {
        if (!tag) return false;
        const clan = this.getClan(tag);
        if (!clan || !clan.password) return false;
        return String(password || "") === String(clan.password);
    },

    setClanPassword(tag, password) {
        if (!tag) return false;
        const upperTag = String(tag).toUpperCase();
        const clan = this.getClan(upperTag);
        if (!clan) return false;
        clan.password = password ? String(password) : null;
        Database.saveClanData(upperTag, clan);
        return true;
    },

    setClanIcon(tag, icon) {
        if (!tag) return false;
        const upperTag = String(tag).toUpperCase();
        const clan = this.getClan(upperTag);
        if (!clan) return false;
        clan.icon = icon ? String(icon).trim() : "⚔️";
        Database.saveClanData(upperTag, clan);
        return true;
    },

    getClanIcon(tag) {
        const clan = this.getClan(tag);
        return (clan && clan.icon) ? clan.icon : "⚔️";
    },

    setClaimLimit(tag, limit) {
        const upper = String(tag).toUpperCase();
        const clan = this.getClan(upper);
        if (!clan) return false;
        const n = parseInt(limit, 10);
        if (isNaN(n) || n < 0) return false;
        clan.claimLimit = n;
        Database.saveClanData(upper, clan);
        return true;
    },
    getClaimLimit(tag) {
        const clan = this.getClan(tag);
        if (!clan) return 10;
        return clan.claimLimit || 10;
    },
    getClan(tag) {
        if (!tag) return null;
        return Database.getClanData(tag);
    },
    getPlayerClanTag(playerName) {
        return playerClanCache.get(playerName) || null;
    },
    deleteClan(tag) {
        if (!tag) return false;
        const upperTag = tag.toUpperCase();
        const clanTags = Database.getAllClans();
        
        if (!clanTags.includes(upperTag)) return false;

        const clanData = this.getClan(upperTag);
        if (clanData) {
            Object.keys(clanData.members).forEach(member => playerClanCache.delete(member));
            // CORRECCIÓN: Al eliminar el clan, se liberan sus reclamos de la memoria RAM instantáneamente
            if (clanData.claims) {
                clanData.claims.forEach(chunkId => claimCache.delete(chunkId));
            }
        }

        const filtered = clanTags.filter(t => t !== upperTag);
        Database.saveClanList(filtered);
        Database.deleteClanData(upperTag);
        
        return true;
    },
    addMember(playerName, tag) {
        const upperTag = tag.toUpperCase();
        
        // CORRECCIÓN: Evita el exploit quitando al jugador de su clan anterior si ya tenía uno
        if (playerClanCache.has(playerName)) {
            this.removeMember(playerName);
        }

        const clan = this.getClan(upperTag);
        if (!clan || Object.keys(clan.members).length >= 15) return false;

        clan.members[playerName] = { role: "member", joinedAt: Date.now() };
        Database.saveClanData(upperTag, clan);
        playerClanCache.set(playerName, upperTag);        updatePlayerClanTag(playerName, upperTag);        
        return true;
    },
    removeMember(playerName) {
        const tag = this.getPlayerClanTag(playerName);
        if (!tag) return false;

        const clan = this.getClan(tag);
        if (!clan) return false;

        if (clan.members[playerName].role === "leader" && Object.keys(clan.members).length > 1) {
            return "is_leader";
        }

        delete clan.members[playerName];

        if (Object.keys(clan.members).length === 0) {
            this.deleteClan(tag);
        } else {
            Database.saveClanData(tag, clan);
        }

        playerClanCache.delete(playerName);
        clearPlayerClanTag(playerName);
        return true;
    }
    ,
    // Devuelve la lista de aliados (tags) de un clan
    getAllies(tag) {
        const clan = this.getClan(tag);
        if (!clan) return [];
        return Array.isArray(clan.allies) ? clan.allies.slice() : [];
    },
    // Añade una alianza mutua entre dos clanes
    addAlliance(clanA, clanB) {
        if (!clanA || !clanB) return false;
        const aTag = String(clanA).toUpperCase();
        const bTag = String(clanB).toUpperCase();
        if (aTag === bTag) return false;

        const a = this.getClan(aTag);
        const b = this.getClan(bTag);
        if (!a || !b) return false;

        if (!Array.isArray(a.allies)) a.allies = [];
        if (!Array.isArray(b.allies)) b.allies = [];

        if (!a.allies.includes(bTag)) a.allies.push(bTag);
        if (!b.allies.includes(aTag)) b.allies.push(aTag);

        Database.saveClanData(aTag, a);
        Database.saveClanData(bTag, b);
        return true;
    },
    // Remueve una alianza mutua entre dos clanes
    removeAlliance(clanA, clanB) {
        if (!clanA || !clanB) return false;
        const aTag = String(clanA).toUpperCase();
        const bTag = String(clanB).toUpperCase();
        if (aTag === bTag) return false;

        const a = this.getClan(aTag);
        const b = this.getClan(bTag);
        if (!a || !b) return false;

        if (Array.isArray(a.allies)) a.allies = a.allies.filter(x => x !== bTag);
        if (Array.isArray(b.allies)) b.allies = b.allies.filter(x => x !== aTag);

        Database.saveClanData(aTag, a);
        Database.saveClanData(bTag, b);
        return true;
    }
}